import sqlite3
from sqlalchemy import create_engine
from flet import *
from controls import add_to_control_reference, return_controle_reference
from modify_form import ModifyForm
from btn import algo_traitement_data, dialog_erreur
import pandas as pd
control_map = return_controle_reference()

class AppDataTableCaisse(UserControl):
    def __init__(self, flux_caisse,color_icon,date1,date2):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.flux_caisse= flux_caisse
        self.color_icon=color_icon
        self.date1=date1
        self.date2=date2

    def app_data_table_instance(self):
        add_to_control_reference(f'AppDataTableCaisse{self.flux_caisse}', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()
        
    def fetch_data(self):
        if self.flux_caisse == 'encaissement':
            req=f"SELECT id, date,nom_otm, types_mvt, montant FROM jounalierTb WHERE types_mvt in('Transfère','Credit','Ajouter') and (date BETWEEN '{self.date1}' and '{self.date2}') ORDER BY id DESC"
        else:
            req=f"SELECT id, date,nom_otm, types_mvt, montant FROM jounalierTb  WHERE  types_mvt in ('Retrait','Enlever') and (date BETWEEN '{self.date1}' and '{self.date2}') ORDER BY id DESC"
            
        self.cursor.execute(req)
        return self.cursor.fetchall()


    def refresh_data(self):
        data = self.fetch_data()
        data1 = self.fetch_data1()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        
        self.controls[0].content.controls[0].rows = rows
        self.update()

 
                
    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ]
            ) for row in data
        ]
        
        return Container(
            
            width=1100,
            content=Row(
                expand=True,
                controls=[
                    DataTable(
                        expand=True,
                        border_radius=8,
                        border=border.all(2, '#ebebeb'),
                        horizontal_lines=border.BorderSide(1, '#ebebeb'),
                        columns=[
                            
                            DataColumn(Container(Text('Date', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Libellé', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Types', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Montant', size=12, color='black', weight='bold'))),
                        ],
                        rows=rows,
                    )
                ]
            )
        )
        

    
class AppDataTableCaisseParJour(UserControl):
    def __init__(self, date3,date4):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.date3= date3
        self.date4=date4

    def app_data_table_instance(self):
        add_to_control_reference(f'AppDataTableCaisseParJour', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()
        

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        
        self.controls[0].content.controls[0].rows = rows
        self.update()

    def create_summary_table(self):
        # Connecter à la base de données SQLite
        engine = create_engine('sqlite:///BDD/database.db')

        # Lire les données de la table 'jounalierTb' dans un DataFrame
        df = pd.read_sql('SELECT * FROM jounalierTb', engine)
        df=df[(df['date'] >= self.date3) & (df['date'] <= self.date4)].copy()

        # Identifier l'enregistrement avec l'ID le plus élevé pour chaque date
        df_max_id = df.loc[df.groupby('date')['id'].idxmax()]

        # Grouper par date pour calculer encaissé et décaissé
        grouped = df.groupby('date').agg(
            encaissé=('montant', lambda x: x[df['types_mvt'].isin(['Transfère', 'Credit', 'Ajouter'])].sum()),
            décaissé=('montant', lambda x: x[df['types_mvt'].isin(['Retrait', 'Enlever'])].sum())
        )

        # Ajouter le solde_final basé sur la caisse de l'enregistrement avec l'ID le plus élevé
        grouped['solde_final'] = df_max_id.set_index('date')['caisse']

        # Calculer le solde_initial
        grouped['solde_initial'] = grouped['solde_final'] - grouped['encaissé'] + grouped['décaissé']

        # Réorganiser les colonnes
        grouped = grouped[['solde_initial', 'encaissé', 'décaissé', 'solde_final']]
        return grouped.reset_index()

    
        
    
    
    
    
    
             
    def build(self):
        self.app_data_table_instance()
        # Appeler la fonction
        summary_table = self.create_summary_table().sort_values(by='date',ascending=False)
        print(summary_table)
        
        rows=[DataRow(cells=[DataCell(Text(str(cell))) for cell in row]) for row in summary_table.values]
        
        return Container(
            
            width=600,
            content=Row(
                controls=[
                    DataTable(
                        expand=True,
                        border_radius=8,
                        border=border.all(2, '#ebebeb'),
                        horizontal_lines=border.BorderSide(1, '#ebebeb'),
                        
                        columns=[
                            
                            DataColumn(Container(content=Row(spacing=1,controls=[Icon(name=icons.DATE_RANGE,color=colors.BLACK,size=12),Text('Date', size=12, color='black', weight='bold'),]))),
                            DataColumn(Container(content=Row(spacing=1,controls=[Icon(name=icons.MONEY,color=colors.BLACK,size=12),Text('S.I', size=12, color='black', weight='bold'),]))),
                            DataColumn(Container(content=Row(spacing=1,controls=[Icon(name=icons.MONETIZATION_ON,color=colors.BLACK,size=12),Text('E.C', size=12, color='black', weight='bold'),]))),
                            DataColumn(Container(content=Row(spacing=1,controls=[Icon(name=icons.MONEY_OFF_CSRED_OUTLINED,color=colors.BLACK,size=12),Text('D.C', size=12, color='black', weight='bold'),]))),
                            DataColumn(Container(content=Row(spacing=1,controls=[Icon(name=icons.MONEY_OUTLINED,color=colors.BLACK,size=12),Text('S.F', size=12, color='black', weight='bold'),]))),
                        ],
                        rows=rows,
                    )
                ]
            )
        )
        

class AppDataTableMvtCaisse(UserControl):
    def __init__(self, date3,date4):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.date3= date3
        self.date4=date4

    def app_data_table_instance(self):
        add_to_control_reference(f'AppDataTableMvtCaisse', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()
        

    def fetch_data(self):
        req=f"SELECT id, date,montant,mvt_caisse,  caisse,motif FROM jounalierTb WHERE mvt_caisse in('Ajouter','Enlever') ORDER BY id DESC"
        self.cursor.execute(req)
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        
        self.controls[0].content.controls[0].rows = rows
        self.update()
             
    def build(self):
        self.app_data_table_instance()
        # Appeler la fonction
        data = self.fetch_data()
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        total_rows = cur.execute(f"select COUNT(*) FROM jounalierTb WHERE mvt_caisse in('Ajouter','Enlever')").fetchone()
        print(total_rows)
        conn.close()
        rows=[
            DataRow(
                cells=[
                    DataCell(Text(str(cell), style=TextStyle(size=10))) for cell in row[1:]
                    
                ],
            ) for row in data
            ]

        return Container(
            
            width=600,
            content=Row(
                
                controls=[
                    DataTable(
                        
                        expand=True,
                        border_radius=8,
                        border=border.all(2, '#ebebeb'),
                        horizontal_lines=border.BorderSide(1, '#ebebeb'),
                        
                        columns=[
                            DataColumn(Container(Text('Date', size=10, color='black', weight='bold'),width=20)),
                            DataColumn(Container(Text('Montant', size=10, color='black', weight='bold'),width=20)),
                            DataColumn(Container(Text('Types', size=10, color='black', weight='bold'),width=20)),
                            DataColumn(Container(Text('CaisseDispo', size=10, color='black', weight='bold'),width=20)),
                            DataColumn(Container(Text('Motif', size=10, color='black', weight='bold'),width=20)),
                            ],
                        rows=rows,
                    )
                ]
            )
        )
        

"""
        for i in range (total_rows):
            rows_color=colors.GREY_200 if i % 2==0 else colors.WHITE
            rows.append(
                DataRow(
                    cells=[
                        DataCell(Text(str(cell), style=TextStyle(size=10))) for cell in row[1:]
                        
                    ],
                    color=rows_color,
                ) for row in data
                
        
            )
"""