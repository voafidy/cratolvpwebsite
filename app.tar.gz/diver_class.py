from flet import *
from datetime import datetime
from flet_timer.flet_timer import Timer


class ClockTimer (UserControl):
    def __init__(self):
        super().__init__()
        self.timenow=Text(value='None', size=20, weight='blod')
        self.timer=Timer(name='Youtime1',
                        interval_s=1,
                        #and make function fror refresh
                        callback=self.myrefresh
                        
                        )
    def myrefresh(self):
        self.timenow.value=datetime.now().strftime("%H:%M:%S")
        self.update()
    def build(self):
        return Container(
            content=Column(
                [
                self.timenow,
                self.timer
                ]
            )
        )