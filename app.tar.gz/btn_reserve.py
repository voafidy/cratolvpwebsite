import sqlite3
from flet import *
from controls import return_controle_reference
from form_helper import FormHelper


control_map = return_controle_reference()

ratio_bonus_user = 2/100
ratio_bonus_otm = 2.5/100
solde_initial = 20000
nom_user='voafidy'

def set_vide_text():
    for key, value in control_map.items():
        if key=='AppForm':
            for user_input in value.controls[0].content.controls[0].controls[:]:
                # Réinitialiser le champ de texte
                user_input.content.controls[1].value = ""
                user_input.content.controls[1].update()
            for user_input in value.controls[0].content.controls[1].controls[:]:
                # Réinitialiser le champ de texte
                user_input.content.controls[1].value = ""
                user_input.content.controls[1].update()
                
def get_input_data(e):
    for key, value in control_map.items():
        if key=='AppForm':
            data = []
            for user_input in value.controls[0].content.controls[0].controls[:]:
                #data.append(user_input.content.controls[1].value)
                #print(user_input.content.controls[1].value)
                print('')
            for user_input in value.controls[0].content.controls[1].controls[:]:
                data.append(user_input.content.controls[1].value)

                #print(user_input.content.controls[1].value)
            print('print data')            
            print(value.controls[0].content.controls[1].controls[:])
            #=['Telma', 'depot', '200000', 'ref1']
            try:
                bonus_otm=float(data[2])*ratio_bonus_otm
                bonus_user=float(data[2])*ratio_bonus_user
                solde = solde_initial+ bonus_otm
                solde_net_bs_user = solde - bonus_user
                print(data)
            

                conn = sqlite3.connect('BDD/database.db')
                # Créer un curseur pour exécuter les commandes SQL
                cur = conn.cursor()

                # Créer une table
                """
                cur.execute('''
                    CREATE TABLE IF NOT EXISTS jounalierTb (
                        id                INTEGER PRIMARY KEY,
                        nom_otm           VARCHAR,
                        user              VARCHAR,
                        types_mvt         VARCHAR,
                        montant           DOUBLE,
                        bonus_otm         DOUBLE,
                        bonus_user        DOUBLE,
                        solde             DOUBLE,
                        solde_net_bs_user DOUBLE
                            
                    ''')
                """

                # Insérer des données d'exemple
                cur.execute("""INSERT INTO jounalierTb (nom_otm, user, types_mvt, montant, bonus_otm,bonus_user, solde,solde_net_bs_user)
                VALUES (?, ?, ?, ?, ?, ?, ?,?)""",
                (data[0], nom_user, data[1], float(data[2]), float(bonus_otm),float(bonus_user), float(solde), float(solde_net_bs_user)))
                conn.commit()
                conn.close()
            except KeyError as e:
                print(e)
            finally:
                conn.commit()
                conn.close()
                pass
            
            
        if key == 'AppDataTable':
            value.controls[0].controls[0].rows.append(data)
            value.controls[0].controls[0].update()
    set_vide_text()
def retur_form_button():
    return Container(
        alignment=alignment.center,
        content = ElevatedButton(
            on_click=lambda e: get_input_data(e),
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.ADD_ROUNDED,
                        size=12,
                    ),
                    Text(
                        'Add Input Field To Table',
                        size=11,
                        weight='bold',


                    )
                ]
            
            ),
            style=ButtonStyle(
                shape={
                    "":RoundedRectangleBorder(radius=6),
                },
                color={
                    "":"white",
                },
            ),
            height=42,
            width=220,

        )
    )