import flet
from flet import *
from form_cyber import AppCyber
from form_setting import AppSetting
from header import AppHeader
from form import AppForm
from data_table import AppDataTable
from caisse_form import CaisseForm
from login_form import LoginForm  # Import the LoginForm
from screeninfo import get_monitors

from stat_form import StatForm

def main(page: Page):
    page.title = "Performance Plus-CSI"
    page.bgcolor = '#fdfdfd'
    page.padding = 8
    page.window.bgcolor = colors.TRANSPARENT
    page.bgcolor =colors.TRANSPARENT
    #page.window.title_bar_hidden = True
    #page.window.frameless = True
    page.window_maximized = True
    # Recalculate the center position

    content_column = Column(expand=True)
    from datetime import datetime
    current_date = datetime.now().strftime("%Y-%m-%d")
    
    def on_login_success(username, nom, statut):
        page.controls.clear()
        content_column.controls.clear()
        content_column.controls.append(
            Column(
                expand=True,
                controls=[
                    
                    AppCyber(page,username)
                    #StatForm(page,username)
                    #AppSetting(page),
                    #CaisseForm(page,username),
                    
                    
                ]
            )
        )
        page.add(
            Column(
                expand=True,
                controls=[
                    AppHeader(page, content_column, username, nom, statut, on_logout),
                    Divider(height=2, color="transparent"),
                    content_column
                ]
            )
        )
        page.window_maximized = True
        page.bgcolor ='#fdfdfd'
        page.window.title_bar_hidden = False
        page.window.frameless = False
        page.update()

    def on_logout():
        page.controls.clear()
        login_form = LoginForm(on_login_success)
        page.add(login_form)
        page.window_maximized = True
        page.window.bgcolor = colors.TRANSPARENT
        page.bgcolor =colors.TRANSPARENT
        page.window.title_bar_hidden = True
        page.window.frameless = True
        page.update()

    login_form = LoginForm(on_login_success)
    page.add(login_form)
    
    page.update()

if __name__ == "__main__":
    flet.app(target=main)
    #flet.app(target=main, view=AppView.WEB_BROWSER,host="127.0.0.1",port=5050)
    
#flet main.py -d
'''AppForm(username),
                    Column(
                        scroll='auto',
                        expand=True,
                        controls=[
                            AppDataTable(username,current_date,current_date)
                        ]
                    )'''
                    
                    
                    