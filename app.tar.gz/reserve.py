import locale
import sqlite3
from flet import *
from btn import algo_traitement_data, retur_form_button
from controls import add_to_control_reference, return_controle_reference
from data_table import AppDataTable
from data_table_stat import AppDataTableStat, AppDataTableStatEnTete

control_map = return_controle_reference()
from datetime import datetime, timedelta
current_date = datetime.now().strftime("%Y-%m-%d")

class StatForm(UserControl):
    def __init__(self,page,username):
        super().__init__()
        self.page = page
        self.username=username
        self.selected_date1 = datetime.today().strftime('%Y-%m-%d')
        self.selected_date2 = datetime.today().strftime('%Y-%m-%d')
        self.yr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').year
        self.ms2=datetime.strptime(self.selected_date1,'%Y-%m-%d').month
        self.jr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').day
        
        # Obtenez la date d'aujourd'hui
        self.aujourdhui = datetime.now()
        self. m_0 = self.aujourdhui
        self.m_1 = self.aujourdhui - timedelta(days=self.aujourdhui.day-1)
        self.m_2 = self.m_1 - timedelta(days=self.m_1.day)
        self.m_3 = self.m_2 - timedelta(days=self.m_2.day)
        self.m_4 = self.m_3 - timedelta(days=self.m_3.day)
        # Définir la locale en français
        locale.setlocale(locale.LC_TIME, 'fr_FR')
        self.date_obj_mois_0 = self.m_0.strftime('%B').upper()
        self.date_obj_mois_1 = self.m_1.strftime('%B').upper()
        self.date_obj_mois_2 = self.m_2.strftime('%B').upper()
        self.date_obj_mois_3 = self.m_3.strftime('%B').upper()
        #print(mois_3,mois_2,mois_1)

        #aujourdhui = self.datetime.today().strftime('%Y-%m-%d')#
        self.mois_0 = self. m_0.strftime('%Y-%m-%d')
        self.mois_1 = self. m_1.strftime('%Y-%m-%d')
        self.mois_2 = self.m_2.strftime('%Y-%m-%d')
        self.mois_3 = self.m_3.strftime('%Y-%m-%d')
        self.mois_4 = self.m_4.strftime('%Y-%m-%d')
        self.selected_date3 = self.mois_1
        self.selected_date4 = self.mois_0
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
        

        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        date_min = cur.execute(f"select min(date) as date_min from jounalierTb").fetchone()[0]
        print(date_min)
        if date_min:
            min_date_obj=datetime.strptime(date_min,'%Y-%m-%d')+timedelta(days=1)
            yr=min_date_obj.year
            ms=min_date_obj.month
            jr=min_date_obj.day
        
        conn.close()    
        
        self.button_date1=ElevatedButton(
            f"{self.selected_date1} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date2=ElevatedButton(
            f"{self.selected_date2} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr2, month=self.ms2, day=self.jr2),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change2,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date3=ElevatedButton(
            f"{self.selected_date3} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change3,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date4=ElevatedButton(
            f"{self.selected_date4} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr4, month=self.ms4, day=self.jr4),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change4,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.drawer = NavigationDrawer(
            on_dismiss=self.handle_dismissal_start,
            on_change=self.handle_change_start,
            controls=[
                Container(height=12),
                NavigationDrawerDestination(
                    label="Item 1",
                    icon=icons.PASSWORD,
                    selected_icon_content=Icon(icons.PASSWORD_OUTLINED),
                ),
                Divider(thickness=2),
                NavigationDrawerDestination(
                    icon_content=Icon(icons.PASSWORD_SHARP),
                    label="Item 2",
                    selected_icon=icons.PASSWORD_ROUNDED,
                ),
                NavigationDrawerDestination(
                    icon_content=Icon(icons.CHANGE_CIRCLE_ROUNDED),
                    label="Item 3",
                    selected_icon=icons.PHONE,
                ),
            ],
        )
        self.end_drawer = NavigationDrawer(
        position=NavigationDrawerPosition.END,
        on_dismiss=self.handle_dismissal_end,
        on_change=self.handle_change_end,
        controls=[
            NavigationDrawerDestination(icon=icons.ADD_TO_HOME_SCREEN_SHARP, label="Item 1"),
            NavigationDrawerDestination(icon=icons.ADD_COMMENT, label="Item 2"),
        ],
     )
        self.resultat_column=Column()
        self.content_column_fitre_data=Column()

        
    def handle_change3(self, e,types):
        # Update the button label when a new date is selected
        self.selected_date3 = e.control.value.strftime('%Y-%m-%d')
        self.button_date3.text = f"{self.selected_date3} Debut"
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
        self.button_date3.update()
        self.def_fitre_data(self.selected_date3,self.selected_date4,types )
        self.content_column_fitre_data.update()
    def handle_change4(self, e,types):
        # Update the button label when a new date is selected
        self.selected_date4 = e.control.value.strftime('%Y-%m-%d')
        self.button_date4.text = f"{self.selected_date4} Fin"
        self.button_date4.update()
        self.def_fitre_data(self.selected_date3,self.selected_date4,types )
        self.content_column_fitre_data.update()
        

    def handle_change1(self, e):
        # Update the button label when a new date is selected
        self.selected_date1 = e.control.value.strftime('%Y-%m-%d')
        self.button_date1.text = f"{self.selected_date1} Debut"
        self.yr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').year
        self.ms2=datetime.strptime(self.selected_date1,'%Y-%m-%d').month
        self.jr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').day
        self.button_date1.update()
        self.recherche_btn(self.selected_date1,self.selected_date2)
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))
    def handle_change2(self, e):
        # Update the button label when a new date is selected
        self.selected_date2 = e.control.value.strftime('%Y-%m-%d')
        self.button_date2.text = f"{self.selected_date2} Fin"
        self.button_date2.update()
        self.recherche_btn(self.selected_date1,self.selected_date2)
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))
    def handle_dismissal(self,e):
        (Text(f"DatePicker dismissed"))
        pass
    def app_form_input_instance(self):
        add_to_control_reference('StatForm', self)

    def handle_dismissal_start(self,e):
        print('Text("Drawer dismissed")')
        #self.page.add(Text("Drawer dismissed"))
        
    def def_fitre_data(self,date3,date4,types):
        self.content_column_fitre_data.controls.clear()
        self.content_column_fitre_data.controls.append(
            Column(
                expand=True,
                spacing=0,
                controls=[
                   
                        Container(
                            height=50,
                            bgcolor=colors.YELLOW,
                            border=border.all(1, "#ebebeb"),
                            border_radius=4,
                            padding=4,
                            content=Row(
                                expand=True,
                                alignment=MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    #Text(f"Selected Index changed _start: {types.control.selected_index}"),
                                    Container(

                                        #bgcolor=colors.GREEN_100,
                                        content=Row(
                                            alignment=MainAxisAlignment.START,
                                            controls=[
                                                self.button_date3,
                                                self.button_date4,
                                                
                                            ]
                                        )
                                    ),
                                ]
                            )
                      
                ),
                    Container(
                        height=50,
                        width=1400,
                        bgcolor=colors.GREY_200,
                        border=border.all(1, "#ebebeb"),
                        border_radius=4,
                        padding=4,
                        content=Column(
                            controls=[
                                AppDataTableStatEnTete()
                            ]
                        )
                    ),
                    Container(
                        height=445,
                        width=1400,
                        bgcolor=colors.GREY_200,
                        border=border.all(1, "#ebebeb"),
                        border_radius=4,
                        padding=4,
                        content=Column(
                            scroll='auto',
                            controls=[
                                AppDataTableStat(self.username,date3,date4)
                            ]
                        )
                    )
                ]
            )
        )
        #self.content_column_fitre_data.update()
    def handle_change_start(self,e):
        print('  page.close(drawer)')
        types=e.control.selected_index
        self.resultat_column.controls.clear()
        self.resultat_column.controls.append(
            Column(
            expand=True,
            controls=[
                
                Column(
                    expand=True,
                    controls=[
                        self.content_column_fitre_data,
                    ]
                )
        
            ]
        )
        )
        self.resultat_column.update()
        self.page.update()
        self.page.close(self.drawer)

    def handle_dismissal_end(self,e):
        #self.page.add(Text("End drawer dismissed"))
        pass

    def handle_change_end(self,e):
        print('  page.close(drawer)')
        
        self.resultat_column.controls.clear()
        self.resultat_column.controls.append(
            Column(
            expand=True,
            controls=[
                Row(
                    expand=True,
                    alignment=MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        Text(f"Selected Index changed _end: {e.control.selected_index}"),
                        Container(
                            height=50,
                            width=415,
                            #bgcolor=colors.GREEN_100,
                            content=Row(
                                alignment=MainAxisAlignment.START,
                                controls=[
                                    self.button_date1,
                                    self.button_date2,
                                    TextButton(
                                        on_click=lambda e: self.recherche_btn(self.selected_date1,self.selected_date2),
                                        icon= icons.SEARCH
                                    ),
                                    
                                ]
                            )
                        ),
                    ]
                ),
                
                Column(
                    scroll='auto',
                    expand=True,
                    controls=[
                        AppDataTable(self.username,current_date,current_date)
                    ]
                )
            ]
        )
        )
        self.resultat_column.update()
        self.page.update()
        self.page.close(self.end_drawer)
        # self.page.close(end_drawer)

    


    def show_data(self):
        from datetime import datetime
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        print(current_date)
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        nb_op = cur.execute(f"select COUNT(*) from jounalierTb WHERE (date between '{self.mois_1}' and '{self.mois_0}') and types_mvt in ('Transfère', 'Credit', 'Retrait')").fetchone()[0]
        conn.close()
         # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        sum_date = cur.execute(f"""select sum(montant),sum(caisse),sum(solde),sum(solde_net_bs_user),
                               sum(bonus_otm),sum( bonus_user),sum( bonus_proprietaire),sum(frais_payer_client),
                               sum( frais_retirer_otm) from jounalierTb WHERE (date between '{self.mois_1}' and '{self.mois_0}') and types_mvt in ('Transfère', 'Credit', 'Retrait')""").fetchone()
        conn.close()
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        caisse_dispo = cur.execute(f"select caisse from jounalierTb WHERE (date between '{self.mois_1}' and '{self.mois_0}') and id = (select max(id) from jounalierTb)").fetchone()[0]
        conn.close()
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        solde_dispo_orange = cur.execute(f"select solde from jounalierTb WHERE id = (select max(id) from jounalierTb WHERE nom_otm ='Orange') ").fetchone()[0]
        conn.close()
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        solde_dispo_Telma = cur.execute(f"select solde from jounalierTb WHERE  id = (select max(id) from jounalierTb WHERE nom_otm ='Telma')").fetchone()[0]
        conn.close()
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        solde_dispo_Airtel = cur.execute(f"select solde from jounalierTb WHERE  id = (select max(id) from jounalierTb WHERE nom_otm ='Airtel') ").fetchone()[0]
        conn.close()
        solde_dispo=solde_dispo_Airtel+solde_dispo_orange+solde_dispo_Telma
        surplus=sum_date[7]-sum_date[8]
        return Container(
                    height=50,
                    width=1100,
                    bgcolor=colors.GREY_200,
                    border=border.all(1, "#ebebeb"),
                    border_radius=8,
                    padding=0,
                    content=Row(
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            Container(
                                height=50,
                                width=90,
                               
                                bgcolor=colors.CYAN_100,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text(f"{nb_op}", size=20, color='black', weight='bold'),
                                        Text(f"Operations", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=200,
                               
                                bgcolor=colors.CYAN_200,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        
                                        Text("{:,}".format(sum_date[0]+sum_date[7]).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Montant Traité", size=10),
                                    ]
                                )
                            ),
                            Container(
                                height=50,
                                width=170,
                               
                                bgcolor=colors.CYAN_300,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(solde_dispo+caisse_dispo+surplus).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Chiffre d'Affaire", size=10),
                                    ]
                                )
                            ),        
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_400,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(sum_date[4]).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Bénéfice", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_300,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(surplus).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Surplus", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_200,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(solde_dispo).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Solde Dispo", size=10),
                                    ]
                                )
                            ),
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_100,
                                content=Column(
                                    expand=True,
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(caisse_dispo).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Caisse Dispo", size=10),
                                    ]
                                )
                            ),
                            
                        ]
                    )
                )
    #self.page.add(ElevatedButton("Show drawer", icon= icons.MENU,on_click=lambda e: self.page.open(drawer)))

    def build(self):
        self.app_form_input_instance()
        self.def_fitre_data(self.selected_date3,self.selected_date4,"home" )
        self.drawer_start=TextButton(icon=icons.MENU, on_click=lambda e: self.page.open(self.drawer))
        self.drawer_end=TextButton(icon=icons.MORE_VERT, on_click=lambda e: self.page.open(self.end_drawer))
       
        return Container(
            
            height=610,
            width=1500,
            bgcolor=colors.GREY_100,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=10,
            content=Column(
            controls=[
                Container(
                    
                    height=50,
                    width=1500,
                    bgcolor=colors.GREY_200,
                    border=border.all(1, "#ebebeb"),
                    border_radius=8,
                    padding=0,
                    content=Row(
                        expand=True,
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            self.drawer_start,
                            self.show_data(),                            
                            self.drawer_end
                        ]
                    )
                ),
                Container(
                    height=520,
                    width=1500,
                    bgcolor=colors.GREEN_100,
                    border=border.all(1, "#ebebeb"),
                    border_radius=8,
                    padding=8,
                    content=Column(
                        controls=[
                            self.resultat_column,
                           
                        ]
                    )
                ),
            ]
            )
        )

        
        
"""        return Container(
            expand=True,
            height=600,
            width=800,
            bgcolor=colors.GREY,#"white10",
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=15,
            content=Column(
                controls=[
                    ElevatedButton( "0",icon=icons.MENU, on_click=self.show_drawer),#"Show drawer",
                ]
            )
        )"""


"""    controls=[
                    Row(
                        controls=[],
                    ),
                    Row(
                        controls=[
                            Text("Caisse Form", size=20, weight="bold"),
                            ElevatedButton(
                                text="Achat",
                                on_click=self.dialog_modif
                            ),
                            ElevatedButton(
                                text="Vente",
                                on_click=self.dialog_modif
                            )
                        ],
                    ),
                    
                    
                ]
            """
            
