import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from modify_form import ModifyForm
from btn import algo_traitement_data, dialog_erreur
control_map = return_controle_reference()

class AppDataTableTarif(UserControl):
    def __init__(self,otm,color_icon):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.otm = otm
        self.color_icon=color_icon


    def app_data_table_instance(self):
        add_to_control_reference(f'AppDataTableTarif_{self.otm}', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute(f"SELECT id_trf_{self.otm},montant_min,montant_max,dep_avec_tel,dep_sans_tel,retrait,total_frais FROM tarif_frais_{self.otm} ORDER BY montant_min asc")
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_tarif(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete_tarif(e, id),
                                    bgcolor=self.color_icon,
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        
        self.controls[0].content.controls[0].rows = rows
        self.update()


    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()



    def save_edit_tarif(self, e, id):
        # Récupérez les valeurs des composants
        montant_min=self.page.dialog.content.controls[0].value
        montant_max=self.page.dialog.content.controls[1].value
        dep_avec_tel=self.page.dialog.content.controls[2].value
        dep_sans_tel=self.page.dialog.content.controls[3].value
        retrait=self.page.dialog.content.controls[4].value
        total=self.page.dialog.content.controls[5].value
        
        if montant_min and montant_max and dep_avec_tel and dep_sans_tel and retrait and total:
            
            try :
                testFlozt= float(montant_min)+float(montant_max)+float(dep_avec_tel)+float(dep_sans_tel)+float(retrait)+float(total)
                if float(montant_min) < float(montant_max):
                    try:

                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()

                        cur.execute(f"""UPDATE tarif_frais_{self.otm} SET montant_min=?,montant_max=?, dep_avec_tel=?, dep_sans_tel=?, retrait=?, total_frais=? WHERE id_trf_{self.otm} = ?""",
                        (montant_min,montant_max,dep_avec_tel,dep_sans_tel,retrait,total,id)
                        )
                        
                        
                        conn.commit()
                        conn.close()

                        # Fermer le popup et rafraîchir la table après la mise à jour
                        self.close_dialog_modif(e)
                        self.page.update()
                        if f'AppDataTableTarif_{self.otm}' in control_map:
                            control_map[f'AppDataTableTarif_{self.otm}'].refresh_data()
                        

                    except ValueError:
                                
                        #dialog_erreur(self, ValueError)
                        
                        print(ValueError)
                        
                    finally:
                        pass
                    return
                else:
                    #dialog_erreur(self, "Oops! Le montant min doit etre strictement inferieur au montant max!")
                    self.error_message_tarif.color = colors.RED
                    self.error_message_tarif.value = "Oops! Le montant min doit être strictement inferieur au montant max!"
                    self.error_message_tarif.update()
                    return
            
            except ValueError :
                print(ValueError) 
                self.error_message_tarif.color = colors.RED
                self.error_message_tarif.value = "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît."
                self.error_message_tarif.update()
                #dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message_tarif.color = colors.RED
            self.error_message_tarif.value = "Il faut remplir tous les champ!"
            self.error_message_tarif.update()
            #dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
            return



    def confirm_delete_tarif(self, e, id):
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Confirmer la suppression"),
            content=Text("Voulez-vous vraiment supprimer ce Tarif ?"),
            actions=[
                TextButton("Oui", on_click=lambda e: self.delete_data(e, id)),
                TextButton("Non", on_click=self.close_dialog_modif)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def delete_data(self, e, id):
        print(f"print id : {id}")
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute(f"DELETE FROM tarif_frais_{self.otm} WHERE id_trf_{self.otm} = ?", (id,))
            conn.commit()
            conn.close()
            
            # Rafraîchir la table après la suppression
            self.refresh_data()

            # Fermer le dialogue
            self.close_dialog_modif(e)
        except Exception as ex:
            print(f"Erreur lors de la suppression : {ex}")


    def load_data(self, id):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT montant_min,montant_max, dep_avec_tel, dep_sans_tel, retrait, total_frais FROM tarif_frais_{self.otm} WHERE id_trf_{self.otm} = ?", (id,))
        self.data = cur.fetchone()
        conn.close()
        
 

    def dialog_modif_tarif(self, e, id):
        self.load_data(id)
        self.montant_minTextField = TextField(value=str(self.data[0]),label="Montant Min",)
        self.montant_maxTextField = TextField(value=str(self.data[1]),label="Montant Max",)
        self.dep_avec_telTextField = TextField(value=str(self.data[2]),label="Frais avec Tel",)
        self.dep_sans_telTextField = TextField(value=str(self.data[3]),label="Frais Sans Tel",)
        self.retraitTextField = TextField(value=str(self.data[4]),label="Frais Rétrait",)
        self.totalTextField = TextField(value=str(self.data[5]),label="Total",)
        self.error_message_tarif = Text("", color=colors.RED,size=13,weight='bold',)
        
        
        
        # Créez une ligne pour les boutons Modifier et Annuler
        self.action_buttons = Row(
            controls=[
                TextButton("Modifier", on_click=lambda e: self.save_edit_tarif(e, id)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        self.dialog = AlertDialog(
            modal=True,
            title=Text(f"Modifier le Tarif de {self.otm}"),
            content=Column(
                width=150,
                height=500,
                controls=[
                    self.montant_minTextField,
                    self.montant_maxTextField,
                    self.dep_avec_telTextField,
                    self.dep_sans_telTextField,
                    self.retraitTextField,
                    self.totalTextField,
                    self.error_message_tarif,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
        
                
    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_tarif(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete_tarif(e, id),
                                    bgcolor=self.color_icon,
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        return Container(
            
            width=1100,
            content=Row(
                expand=True,
                controls=[
                    DataTable(
                        expand=True,
                        border_radius=8,
                        border=border.all(2, '#ebebeb'),
                        horizontal_lines=border.BorderSide(1, '#ebebeb'),
                        columns=[
                            DataColumn(Container(Text('Montant Min', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Montant Max', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Dépot avec Tel', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Dépot sans Tel', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Rétrait', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Total', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Action', size=12, color='black', weight='bold'))),
                        ],
                        rows=rows,
                    )
                ]
            )
        )
        

    
          
