import sqlite3
from flet import *
import pandas as pd
from sqlalchemy import create_engine
from controls import return_controle_reference

control_map = return_controle_reference()


def set_vide_text(self):
    self.type_operation_dropdown.disabled = True
    self.type_transfere_dropdown.disabled=True
    self.montant_field.read_only = True
    self.montant_field.opacity = 1.0
    for key, value in control_map.items():
        if key == 'AppForm':
            for user_input in value.controls[0].content.controls[0].controls[:]:
                if isinstance(user_input, Container):
                    if hasattr(user_input.content, 'controls') and len(user_input.content.controls) > 1 and isinstance(user_input.content.controls[1], TextField):
                        user_input.content.controls[1].value = ""
                        user_input.content.controls[1].update()
                        
                elif isinstance(user_input, Dropdown):
                    user_input.value = None
                    user_input.update()

    # Accéder au solde final de Airtel
    airtel_final_text = self.show_solde.content.controls[3].content.controls[1].content.controls[1].content.controls[1]
    airtel_final_text.value = "{:,}".format(self.def_solde_initial_final('sf','Airtel')).replace(",", " ")+' Ar'
    airtel_final_text.update()

    # Accéder au solde final de Orange
    orange_final_text = self.show_solde.content.controls[1].content.controls[1].content.controls[1].content.controls[1]
    orange_final_text.value ="{:,}".format(self.def_solde_initial_final('sf','Orange')).replace(",", " ")+' Ar'
    orange_final_text.update()

    # Accéder au solde final de Telma
    telma_final_text = self.show_solde.content.controls[2].content.controls[1].content.controls[1].content.controls[1]
    telma_final_text.value = "{:,}".format(self.def_solde_initial_final('sf','Telma')).replace(",", " ")+' Ar'
    telma_final_text.update()

    # Accéder au solde final de Telma
    Operation_text = self.show_solde.content.controls[4].content.controls[0].content.controls[1]
    Operation_text.value = "{:,}".format(self.def_nombre_op()).replace(",", " ")+' Operation'
    Operation_text.update()
    
    Operation_text = self.show_solde.content.controls[4].content.controls[1].content.controls[1]
    Operation_text.value ="{:,}".format(self.CaisseDisponible()).replace(",", " ")+' Ar'
    Operation_text.update()
    
    # Actualiser la vue globale
    self.show_solde.update()


def save_add_solde(self,e,otm):
    # Récupérez les valeurs des composants
    montant=(self.page.dialog.content.controls[0].value)
    motif=self.page.dialog.content.controls[1].value
    
    if montant and  motif:
        
        try :
            montant= float(montant)
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            self.data_id = cur.execute(f"select * from jounalierTb where nom_otm='{otm}' ORDER BY id DESC LIMIT 1").fetchone()
            conn.close()
            # Charger les données existantes pour l'enregistrement à modifier

            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            caissedispo =float(cur.execute(f"SELECT caisse FROM jounalierTb WHERE id = (select max(id) from jounalierTb )").fetchone()[0])
            conn.close()
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            soldedispo =float(cur.execute(f"SELECT solde FROM jounalierTb WHERE id = ?", (self.data_id[0],)).fetchone()[0])
            conn.close()
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            solde_net_bs_user =float(cur.execute(f"SELECT solde_net_bs_user FROM jounalierTb WHERE id = ?", (self.data_id[0],)).fetchone()[0])
            conn.close()
            
            
            solde=(soldedispo) + (montant)

            try:
                from datetime import datetime
                current_date = datetime.now().strftime("%Y-%m-%d")  # Formater la date comme 'YYYY-MM-DD'
                current_time = datetime.now().strftime("%H:%M:%S")  # Formater l'heure comme 'HH:MM:SS'
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                cur.execute("""INSERT INTO jounalierTb (date, time, montant,caisse,motif,mvt_caisse,solde,
                            solde_net_bs_user,user,nom_otm,types_mvt,bonus_otm, bonus_user, bonus_proprietaire,
                            frais_payer_client, frais_retirer_otm) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                (current_date, current_time,montant, caissedispo,motif, otm,solde,solde_net_bs_user,self.username,otm,"Augmentation de solde",0,0,0,0,0 )
                    )
                
                conn.commit()
                conn.close()
                self.error_message_caisse.color = colors.GREEN
                self.error_message_caisse.value = f"Ajout solde {otm} avec succés"
                self.error_message_caisse.update()
                # Fermer le popup et rafraîchir la table après la mise à jour
                self.content_column_setting.update()
                self.close_dialog_modif(e)
                if 'AppDataTable' in control_map:
                    control_map['AppDataTable'].refresh_data()
                self.page.update()  

            except ValueError:
                print(ValueError)
                
            finally:
                pass
            return
            
        except ValueError :
            print(ValueError) 
            self.error_message_caisse.color = colors.RED
            self.error_message_caisse.value = "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît."
            self.error_message_caisse.update()
            #dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
            return
            
    else :
        print("Il faut remplir tous les champ!")
        self.error_message_caisse.color = colors.RED
        self.error_message_caisse.value = "Il faut remplir tous les champ!"
        self.error_message_caisse.update()
        #dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
        return
    
def calculBonusOtm(montant, nom_otm, types_mvt, types_transfert):
    if nom_otm == "Orange":
        mobile_money = 'om'
    elif nom_otm == "Telma":
        mobile_money = 'mvola'
    elif nom_otm == "Airtel":
        mobile_money = 'am'
    else:
        return 0  # ou lever une exception selon votre logique
    conn = sqlite3.connect('BDD/database.db')
    cur = conn.cursor()
    mode_bonus=cur.execute("SELECT pourcentage, appliquer FROM mode_bonus WHERE id = (select max(id) from mode_bonus)").fetchone()
    print(mode_bonus)
    mode_bonus_pr =mode_bonus[0]
    chk_bonus = mode_bonus[1]
    conn.close()
    
    def calculeBonusTranche ():
        # Connecter à la base de données SQLite
        engine = create_engine('sqlite:///BDD/database.db')
        # Lire les données de la table 'tarif_frais_{mobile_money}' dans un DataFrame
        df = pd.read_sql(f"SELECT * FROM tranche_bonus_{mobile_money}", engine)
        # Parcourir chaque ligne du DataFrame pour trouver la ligne correspondant à l'intervalle du montant
        for index, row in df.iterrows():
            if float(row['montant_min']) <= float(montant) <= float(row['montant_max']):
                return row['bonus']
        # Si aucune ligne ne correspond à l'intervalle du montant
        return 0

    def calculeBonusPercent ():
        bonus =float(montant) * (mode_bonus_pr/100)
        return bonus
    
    if chk_bonus == "Tarif":
        return calculeBonusTranche()
    elif chk_bonus == "Pourcentage":
        return calculeBonusPercent ()
    else:
        return 0

def calculFraisOperation(montant, nom_otm, types_mvt, types_transfert):
    if nom_otm == "Orange":
        mobile_money = 'om'
    elif nom_otm == "Telma":
        mobile_money = 'mvola'
    elif nom_otm == "Airtel":
        mobile_money = 'am'
    else:
        return 0  # ou lever une exception selon votre logique

    # Connecter à la base de données SQLite
    engine = create_engine('sqlite:///BDD/database.db')

    # Lire les données de la table 'tarif_frais_{mobile_money}' dans un DataFrame
    df = pd.read_sql(f"SELECT * FROM tarif_frais_{mobile_money}", engine)
    def calculeFrais1 ():
        # Parcourir chaque ligne du DataFrame pour trouver la ligne correspondant à l'intervalle du montant
        for index, row in df.iterrows():
            if float(row['montant_min']) <= float(montant) <= float(row['montant_max']):
                if types_mvt == 'Transfère':
                    if types_transfert == 'Transfère avec Frais de rétrait':
                        return float(row['dep_sans_tel'])+float(row["retrait"])
                    elif types_transfert == 'Transfère sans Frais de rétrait':
                        return row['dep_sans_tel']
                    elif types_transfert == 'Dépôt avec Telephone':
                        return row['dep_avec_tel']
                elif types_mvt == "Retrait":
                    return row['retrait']
                else:
                    return 0

        # Si aucune ligne ne correspond à l'intervalle du montant
        return 0
    total_montant_transferer=calculeFrais1()+montant
    for index, row in df.iterrows():
        if float(row['montant_min']) <= float(total_montant_transferer) <= float(row['montant_max']):
            if types_mvt == 'Transfère':
                if types_transfert == 'Transfère avec Frais de rétrait':
                    return row['total_frais'],float(row['dep_sans_tel'])+float(row["retrait"])
                elif types_transfert == 'Transfère sans Frais de rétrait':
                    return row['dep_sans_tel'],row['dep_sans_tel']
                elif types_transfert == 'Dépôt avec Telephone':
                    return row['dep_avec_tel'],row['dep_avec_tel']
            elif types_mvt == "Retrait":
                return row['retrait'],row['retrait']

    # Si aucune ligne ne correspond à l'intervalle du montant
    return 0


def calculBonusCredit(montant, nom_otm, types_mvt, types_transfert):
    if nom_otm == "Orange":
        otm_crd = 'crd_orange'
    elif nom_otm == "Telma":
        otm_crd = 'crd_telma'
    elif nom_otm == "Airtel":
        otm_crd = 'crd_airtel'
    else:
        return 0  # ou lever une exception selon votre logique
    conn = sqlite3.connect('BDD/database.db')
    cur = conn.cursor()
    mode_bonus=cur.execute("SELECT pourcentage, appliquer FROM mode_bonus_crd WHERE id = (select max(id) from mode_bonus_crd)").fetchone()
    print(mode_bonus)
    mode_bonus_pr =mode_bonus[0]
    chk_bonus = mode_bonus[1]
    conn.close()
    
    def calculeBonusTranche ():
        # Connecter à la base de données SQLite
        engine = create_engine('sqlite:///BDD/database.db')
        # Lire les données de la table 'tarif_frais_{mobile_money}' dans un DataFrame
        df = pd.read_sql(f"SELECT * FROM tranche_bonus_{otm_crd}", engine)
        # Parcourir chaque ligne du DataFrame pour trouver la ligne correspondant à l'intervalle du montant
        for index, row in df.iterrows():
            if float(row['montant_min']) <= float(montant) <= float(row['montant_max']):
                print(f"f***************************{row['bonus']}")
                return row['bonus']
        # Si aucune ligne ne correspond à l'intervalle du montant
        return 0

    def calculeBonusPercent ():
        bonus =float(montant) * (mode_bonus_pr/100)
        return bonus
    
    if chk_bonus == "Tarif":
        return calculeBonusTranche()
    elif chk_bonus == "Pourcentage":
        return calculeBonusPercent ()
    else:
        return 0                                
    
def algo_traitement_data(username,nom_otm,types_mvt,types_transfert,montant,commentaire,x):

    
    from datetime import datetime
    # Obtenir la date et l'heure actuelles
    now = datetime.now()
    # Séparer la date et l'heure
    current_date = now.date()
    current_time = now.time()
    # Formater la date et l'heure
    current_date = now.strftime("%Y-%m-%d")  # Formater la date comme 'YYYY-MM-DD'
    current_time = now.strftime("%H:%M:%S")  # Formater l'heure comme 'HH:MM:SS'
    """if types_mvt=='retrait':
        montant= float(montant)
    else:
        montant=(-1)*float(montant)"""
    from datetime import datetime
    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d")
    print(current_date)
    if x == 'add':

        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT caisse FROM jounalierTb WHERE id = (select MAX(id) from jounalierTb)")
        data = cur.fetchone()
        conn.close()
        caisse_initial = float(data[0])
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE nom_otm = '{nom_otm}')")
        data = cur.fetchone()
        conn.close()
        print(nom_otm)
        print(data[0])
        solde_initial = float(data[0])
    else:

        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT caisse FROM jounalierTb WHERE id = (select MAX(id) from jounalierTb where  id < '{x}')")
        data = cur.fetchone()
        conn.close()
        caisse_initial = float(data[0])

        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT solde FROM jounalierTb WHERE id = (select max(id) from jounalierTb where id < '{x}' and  nom_otm = '{nom_otm}')")
        
        data = cur.fetchone()
        conn.close()
        print(nom_otm)
        print(data[0])
        solde_initial = float(data[0])
    
    conn = sqlite3.connect('BDD/database.db')
    cur = conn.cursor()
    cur.execute(f"SELECT pourcentage FROM mode_partage_bonus WHERE id = (select MAX(id) from mode_partage_bonus)")
    ratio_partage_bonus = cur.fetchone()[0]/ 100
    conn.close()
    
    print(f'+++++++++++++++++++++++++++++++++++++{ratio_partage_bonus}+++++++++++++++++++++++++++++++++++++++++++++++')
       

    nom_user=username
    
    montant= float(montant)
    
    
    
    if types_mvt=='Credit':
        caisse = caisse_initial+montant
        bonus_otm = calculBonusCredit(montant, nom_otm, types_mvt, types_transfert)
        solde = solde_initial + bonus_otm-montant
        frais_retirer_otm =  0
        frais_payer_client = 0
    else:
        frais_retirer_otm =  calculFraisOperation(montant,nom_otm,types_mvt,types_transfert)[1]
        bonus_otm = calculBonusOtm(montant+frais_retirer_otm, nom_otm, types_mvt, types_transfert)
        frais_payer_client = calculFraisOperation(montant,nom_otm,types_mvt,types_transfert)[0]
        
        if types_mvt=='Retrait':
            caisse = caisse_initial-montant
            solde = solde_initial + bonus_otm+montant
        elif types_mvt=='Transfère':
            caisse = caisse_initial+montant+frais_payer_client
            solde = solde_initial + bonus_otm-montant-frais_retirer_otm
        
        
    bonus_user = bonus_otm * ratio_partage_bonus
    bonus_proprietaire = bonus_otm - bonus_user
    solde_net_bs_user = solde - bonus_user
    # Arrondir à 2 décimales
    bonus_otm = round(bonus_otm, 2)
    bonus_user = round(bonus_user, 2)
    bonus_proprietaire = round(bonus_proprietaire, 2)
    solde = round(solde, 2)
    solde_net_bs_user = round(solde_net_bs_user, 2)
    
    print(f'solde_initial : {solde_initial} et caisse : {solde}')
    print(f'caisse_initial : {caisse_initial} et caisse : {caisse}')
    

    return {
        "nom_otm":nom_otm,
        "types_mvt":types_mvt,
        "types_transfert":types_transfert,
        "montant":montant,
        "current_date": current_date,
        "current_time": current_time,
        "nom_user": nom_user,
        "frais_payer_client": frais_payer_client,
        "frais_retirer_otm": frais_retirer_otm,
        "bonus_otm": bonus_otm,
        "bonus_user": bonus_user,
        "bonus_proprietaire": bonus_proprietaire,
        "solde": solde,
        "solde_net_bs_user": solde_net_bs_user,
        "commentaire":commentaire,
        "caisse": caisse,
        "data": "data"
    }


def close_dialog_erreur(self):
    if hasattr(self, 'dialog'):
        #set_vide_text(self)
        self.dialog.open = False
        self.page.update()
        
def dialog_erreur(self, err_ext):
    self.dialog = AlertDialog(
        modal=True,
        title=Text("Erreur survenue : "),
        content=Text(err_ext),
        actions=[
            
            TextButton("OK", on_click=lambda e: close_dialog_erreur(self)),
            
            #TextButton("Non", on_click=self.close_dialog_erreur)
        ],
        actions_alignment=MainAxisAlignment.END
        
    )
    

    self.page.dialog = self.dialog
    self.dialog.open = True
    self.page.update()
    
def get_input_data(self,e,username):
    for key, value in control_map.items():
        if key == 'AppForm':
            data = []
            
            for user_input in value.controls[0].content.controls[0].controls[:]:
                if isinstance(user_input, Dropdown):
                    data.append(user_input.value)
                elif isinstance(user_input, Container) and hasattr(user_input.content, 'controls') and len(user_input.content.controls) > 1:
                    data.append(user_input.content.controls[1].value)

            print('print data')
            print(data)
            # Validation de data[3]
            try:
                montant = float(data[3])
                if data[0] == "Orange":
                    otm_crd = 'crd_orange'
                    otm_mm='om'
                elif data[0] == "Telma":
                    otm_crd = 'crd_telma'
                    otm_mm='mvola'
                elif data[0] == "Airtel":
                    otm_crd = 'crd_airtel'
                    otm_mm='am'
                else:
                    return 0
                
                if data[1] == "Credit":
                    # Charger les données existantes pour l'enregistrement à modifier
                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()
                    data_tarif_crd = cur.execute(f"select min(montant_min),max(montant_max) from tranche_bonus_{otm_crd}").fetchone()
                    data_tarif_crd_max=data_tarif_crd[1]
                    data_tarif_crd_min=data_tarif_crd[0]
                    conn.close()
                    check_montant=data_tarif_crd_min <= montant <= data_tarif_crd_max
                else :
                    # Charger les données existantes pour l'enregistrement à modifier
                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()
                    data_tarif_tranche_bonus_ = cur.execute(f"select min(montant_min),max(montant_max) from tranche_bonus_{otm_mm}").fetchone()
                    data_tarif_tranche_bonus_max=data_tarif_tranche_bonus_[1]
                    data_tarif_tranche_bonus_min=data_tarif_tranche_bonus_[0]
                    conn.close()
                    # Charger les données existantes pour l'enregistrement à modifier
                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()
                    data_tarif_mm = cur.execute(f"select min(montant_min),max(montant_max) from tarif_frais_{otm_mm}").fetchone()
                    data_tarif_mm_max=data_tarif_mm[1]
                    data_tarif_mm_min=data_tarif_mm[0]
                    conn.close()
                    check_montant=data_tarif_tranche_bonus_min <= montant <= data_tarif_tranche_bonus_max and data_tarif_mm_min <= montant <= data_tarif_mm_max 
                if check_montant == True  :
                    
                    if montant > 0:
                        result = algo_traitement_data(username,data[0], data[1], data[2], montant,None,'add')
                        
                        if float(result["caisse"])>=0:
                            if float(result["solde"])>=0:
                                try:
                                    for key, value in result.items():
                                        print(f"{key} : {value}")

                                    print(result["frais_payer_client"])
                                    print(data)

                                    conn = sqlite3.connect('BDD/database.db')
                                    cur = conn.cursor()

                                    cur.execute("""INSERT INTO jounalierTb (date, time, nom_otm, user, types_mvt, types_transfert, montant,
                                                bonus_otm, bonus_user,
                                                bonus_proprietaire, frais_payer_client, frais_retirer_otm, solde, solde_net_bs_user,date_modification,heure_modification,
                                                caisse)
                                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                                (result["current_date"], result["current_time"], result["nom_otm"], result["nom_user"], result["types_mvt"], 
                                                result["types_transfert"], float(result["montant"]),
                                                float(result["bonus_otm"]), float(result["bonus_user"]),
                                                float(result["bonus_proprietaire"]), float(result["frais_payer_client"]), float(result["frais_retirer_otm"]),
                                                float(result["solde"]), float(result["solde_net_bs_user"]),result["current_date"], result["current_time"],float(result["caisse"]))
                                    )
                                    conn.commit()
                                    conn.close()

                                    # Réinitialiser les champs après l'insertion des données
                                    set_vide_text(self)
                                    
                                    # Rafraîchir la table après l'enregistrement
                                    if 'AppDataTable' in control_map:
                                        control_map['AppDataTable'].refresh_data()

                                except KeyError as e:
                                    print(e)
                                finally:
                                    pass
                                return
                            else:
                                dialog_erreur(self, "Solde insuffisante. S'il vous plaît, Veuillez Ravitailler votre solde!")
                        else:
                            dialog_erreur(self, "Espèce insuffisante. S'il vous plaît, Veuillez Ravitailler votre caisse!")
                    else:
                        print("Le montant doit être un nombre positif.")
                        dialog_erreur(self, "Le montant doit être un nombre positif. Veuillez réessayer, s'il vous plaît.")
                        return
                else:
                    dialog_erreur(self, f"Le montant saisi doit être un nombre compris entre le montant min et max du tarif. Veuillez réessayer, s'il vous plaît.")
                    return
            except ValueError:
                
                    print("Le montant doit être un nombre.")
                    
                    dialog_erreur(self, "Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                    return



def retur_form_button(self,username):
    return Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: get_input_data(self,e,username),
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.ADD_ROUNDED,
                        size=14,
                    ),
                    Text(
                        'Enregistrer',
                        size=13,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=42,
            width=150,
        )
    )
    
def return_edit_button(self):
    return Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: get_input_data(e),  # Remplacez `get_input_data` par votre fonction de gestion d'événements
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.EDIT,  # Icône de modification
                        size=14,
                    ),
                    Text(
                        'Modifier',  # Texte du bouton
                        size=13,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=42,
            width=150,
        )
    )
       