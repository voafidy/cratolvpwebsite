import datetime
import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from btn import retur_form_button, save_add_solde
from datetime import datetime

from diver_class import ClockTimer
control_map = return_controle_reference()
class AppForm(UserControl):
    def __init__(self,username):
        super().__init__()
        self.operateur_dropdown = None
        self.type_operation_dropdown = None
        self.type_transfere_dropdown = None
        self.montant_field = None
        self.show_solde=None
        self.username=username

    def app_form_input_instance(self):
        add_to_control_reference('AppForm', self)

    def app_form_input_field(self, name: str, expand: int):
        self.montant_field = TextField(
            border_color="transparent",
            height=20,
            text_size=13,
            content_padding=0,
            cursor_color='black',
            cursor_width=1,
            cursor_height=18,
            color='black',
            read_only=True,  # Initially read-only
            opacity=0.5  # Make it look disabled
        )
        return Container(
            expand=expand,
            height=45,
            bgcolor="#ebebeb",
            border_radius=6,
            padding=8,
            content=Column(
                spacing=1,
                controls=[
                    Text(value=name, size=9, color='black', weight='bold'),
                    self.montant_field
                ]
            )
        )

    def on_operateur_change(self, e):
        self.type_operation_dropdown.disabled = False
        self.update()

    def on_type_operation_change(self, e):
        if self.type_operation_dropdown.value == 'Transfère':
            self.type_transfere_dropdown.disabled = False
            self.update()
        else:
            self.type_transfere_dropdown.disabled = True
            #self.update()
            if self.operateur_dropdown.value and self.type_operation_dropdown.value:
                self.montant_field.read_only = False
                self.montant_field.opacity = 1.0
                self.update()
            
        

    def on_type_transfere_change(self, e):
        if self.operateur_dropdown.value and self.type_operation_dropdown.value and self.type_transfere_dropdown.value:
            self.montant_field.read_only = False
            self.montant_field.opacity = 1.0
        self.update()
    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
    def def_solde_initial_final(self,type_solde, op):
        from datetime import datetime
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        print(current_date)
        print(op)
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        if type_solde=='si':
            self.data_id = cur.execute(f"select * from jounalierTb WHERE date < '{current_date}' and nom_otm ='{op}' ORDER BY id DESC LIMIT 1").fetchone()
        else:
            self.data_id = cur.execute(f"select * from jounalierTb WHERE nom_otm ='{op}' ORDER BY id DESC LIMIT 1").fetchone()
            
        conn.close()
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT solde FROM jounalierTb WHERE id = ?", (self.data_id[0],))
        self.data = cur.fetchone()
        conn.close()
        
        return self.data[0]
    
    def def_nombre_op(self):
        from datetime import datetime
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        print(current_date)
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        self.nb_op = cur.execute(f"select COUNT(*) from jounalierTb WHERE date = '{current_date}' and types_mvt in ('Transfère', 'Credit', 'Retrait')").fetchone()
            
        conn.close()

        
        return self.nb_op[0]
    def CaisseDisponible(self):
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        caissedispo = cur.execute(f"select caisse from jounalierTb WHERE  id = (select max(id) from jounalierTb)").fetchone()[0]
        conn.close()
        return caissedispo
    def build(self):
        self.app_form_input_instance()
        self.operateur_dropdown = Dropdown(
            key="operateur",
            label="Nom d'opérateur",
            hint_text="Sélectionnez l'Opérateur",
            options=[
                dropdown.Option("Orange"),
                dropdown.Option("Telma"),
                dropdown.Option("Airtel")
            ],
            on_change=self.on_operateur_change,
            autofocus=True,
        )

        self.type_operation_dropdown = Dropdown(
            key="type_operation",
            label="Type d'opération",
            hint_text="Sélectionnez le Type d'opération",
            options=[
                dropdown.Option("Transfère"),
                dropdown.Option("Retrait"),
                dropdown.Option("Credit")
            ],
            on_change=self.on_type_operation_change,
            autofocus=True,
            disabled=True,  # Initially disabled
        )

        self.type_transfere_dropdown = Dropdown(
            key="type_transfere",
            label="Type de transfère",
            hint_text="Sélectionnez le type de transfère",
            options=[
                dropdown.Option("Transfère avec Frais de rétrait"),
                dropdown.Option("Transfère sans Frais de rétrait"),
                dropdown.Option("Dépôt avec Telephone"),
            ],
            on_change=self.on_type_transfere_change,
            autofocus=True,
            disabled=True,  # Initially disabled
        )
        self.show_solde=Container(
                                expand=True,
                                height=115,
                                bgcolor=colors.GREEN_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=2,
                                content =Row(
                                    controls=[
                                        
                                        Container(
                                            width=120,
                                            height=100,
                                            bgcolor=colors.GREY_100,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=4,
                                            content=Column(
                                                alignment=MainAxisAlignment.CENTER,
                                                spacing=2,
                                               controls=[
                                                   
                                                    Text("Data du Jour", size=15, weight=FontWeight.W_900, selectable=True),
                                                    Text(value=datetime.now().strftime("%Y-%m-%d"), size=20),
                                                    ClockTimer()
                                                    #Text(value=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), size=20),
                                                    #Text("Comment mettre le date et heur-mn-seconde dynamique ici", size=15, weight=FontWeight.W_900, selectable=True)
                                                ])
                                        ),
                                        Container(
                                            expand=True,
                                            height=100,
                                            bgcolor=colors.ORANGE_100,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            content=Column(
                                                controls=[
                                                    Container(
                                                        
                                                        content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                            
                                                            controls=[
                                                                
                                                                Text("Orange", size=15, weight=FontWeight.W_900, selectable=True),
                                                            ]
                                                        )
                                                    ),
                                                    Container(
                                                        content=Row(
                                                            #alignment=MainAxisAlignment.CENTER,
                                                            controls=[
                                                                Container(
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Initiale", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('si','Orange')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    )
                                                                ),
                                                                Container(
                                                                    
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Final", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('sf','Orange')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    ),
                                                                ),
                                                            ]
                                                        )
                                                    ),
                                                    
                                                
                                                ]
                                            )
                                        ),
                                        Container(
                                            expand=True,
                                            height=100,
                                            bgcolor=colors.YELLOW_100,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            content=Column(
                                                controls=[
                                                    Container(
                                                        
                                                        content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                            
                                                            controls=[
                                                                Text("Telma", size=15, weight=FontWeight.W_900, selectable=True),
                                                            ]
                                                        )
                                                    ),
                                                    Container(
                                                        content=Row(
                                                            #alignment=MainAxisAlignment.CENTER,
                                                            controls=[
                                                                Container(
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Initiale", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('si','Telma')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    )
                                                                ),
                                                                Container(
                                                                    
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Final", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('sf','Telma')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    ),
                                                                ),
                                                            ]
                                                        )
                                                    ),
                                                    
                                                
                                                ]
                                            )
                                        ),
                                        Container(
                                            expand=True,
                                            height=100,
                                            bgcolor=colors.RED_100,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            content=Column(
                                                controls=[
                                                    Container(
                                                        
                                                        content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                            
                                                            controls=[
                                                                Text("Airtel", size=15, weight=FontWeight.W_900, selectable=True),
                                                            ]
                                                        )
                                                    ),
                                                    Container(
                                                        content=Row(
                                                            #alignment=MainAxisAlignment.CENTER,
                                                            controls=[
                                                                Container(
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Initiale", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('si','Airtel')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    )
                                                                ),
                                                                Container(
                                                                    
                                                                    width=170,
                                                                    content=Column(
                                                                        controls = [
                                                                            Text("Solde Final", size=15, weight=FontWeight.W_900, selectable=True),
                                                                            Text("{:,}".format(self.def_solde_initial_final('sf','Airtel')).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                                        ]
                                                                    ),
                                                                ),
                                                            ]
                                                        )
                                                    ),
                                                    
                                                
                                                ]
                                            )
                                        ),
                                        Container(
                                            height=100,
                                            width=140,
                                            bgcolor=colors.TRANSPARENT,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=2,
                                            
                                            content=Column(
                                                alignment=MainAxisAlignment.CENTER,
                                                spacing=1,
                                                controls=[
                                                    Container(
                                                        padding=0,
                                                        content=Column(
                                                            
                                                            controls=[
                                                                Text("Nombres Operations", size=11, weight=FontWeight.W_900, selectable=True),
                                                                Text("{:,}".format(self.def_nombre_op()).replace(",", " "), size=15, weight=FontWeight.W_900, selectable=True)
                                                            ]
                                                        )
                                                    ),
                                                    Container(
                                                        padding=0,
                                                        content=Column(
                                                            
                                                            controls=[
                                                                Text("Caisse Disponible", size=11, weight=FontWeight.W_900, selectable=True),
                                                                Text("{:,}".format(self.CaisseDisponible()).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True)
                                                            ]
                                                        )
                                                    ),
                                                    
                                                
                                                ]
                                            )
                                        ),
                                        
                                        
                                    
                                    ]
                                )
                            )
                      

        return Container(
            expand=True,
            height=190,
            bgcolor="#b0f2b6",
            #bgcolor=colors.GREEN_200,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=8,
            content=Column(
                expand=True,
                controls=[
                    
                    Row(
                        controls=[
                            self.operateur_dropdown,
                            self.type_operation_dropdown,
                            self.type_transfere_dropdown,
                            self.app_form_input_field('Montant*', 1),
                            retur_form_button(self,self.username),
                        ],
                    ),
                    
                    Row(
                        #alignment=MainAxisAlignment.END,
                        controls=[
                            self.show_solde,
                          ]
                    ),
                ]
            )
        )
