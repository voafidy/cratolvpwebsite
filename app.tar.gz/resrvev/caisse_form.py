import datetime
import sqlite3
from flet import *

from controls import add_to_control_reference
from data_table_caisse import AppDataTableCaisse, AppDataTableCaisseParJour
from data_table_login import AppDataTableLogin

class CaisseForm(UserControl):
    def __init__(self,page):
        super().__init__()
        self.page=page
        self.selected_date1 = datetime.datetime.today().strftime('%Y-%m-%d')
        self.selected_date2 = datetime.datetime.today().strftime('%Y-%m-%d')
        self.content_column_setting = Column(expand=True)
        self.ctn_pg=Container(
            key='ctn_pg',height=580,width=850,bgcolor=colors.GREY_200,border=border.all(1, "#ebebeb"),border_radius=8,padding=4,
            content=Column(
                #scroll='auto',
                controls=[
                    self.content_column_setting,
                ],
            ),
        )
        self.button_date1=ElevatedButton(
            f"{self.selected_date1} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime.datetime(year=2024, month=7, day=28),
                    last_date=datetime.datetime(year=datetime.datetime.today().year, month=datetime.datetime.today().month, day=datetime.datetime.today().day),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date2=ElevatedButton(
            f"{self.selected_date2} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime.datetime(year=2024, month=7, day=28),
                    last_date=datetime.datetime(year=datetime.datetime.today().year, month=datetime.datetime.today().month, day=datetime.datetime.today().day),
                    on_change=self.handle_change2,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )

    def app_form_input_instance(self):
        add_to_control_reference('CaisseForm', self)
    """
    def def_ctn_pg(self):
        # Ensure the container is ad
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
        
        Column(expand=True,
        controls=[
                self.formulaire_etat_caisse()
                ])
        )
   """
   
    def def_solde_initial_final(self,type_solde, op,date_debut,date_fin):
        from datetime import datetime
        now = datetime.now()
        self.current_date = now.strftime("%Y-%m-%d")
        print(self.current_date)
        print(op)
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        if type_solde=='si':
            self.data_id = cur.execute(f"select * from jounalierTb WHERE date < '{date_debut}'  ORDER BY id DESC LIMIT 1").fetchone()
        else:
            self.data_id = cur.execute(f"select * from jounalierTb   ORDER BY id DESC LIMIT 1").fetchone()
            
        conn.close()
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        if type_solde=='si' or type_solde=='sf':
            cur.execute(f"SELECT solde FROM jounalierTb WHERE id = ?", (self.data_id[0],))
            self.data = cur.fetchone()[0]
        elif type_solde=='dc':
            self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt == 'Retrait' and date BETWEEN '{date_debut}' and '{date_fin}' ").fetchone()[0]
            
        elif type_solde=='ec':
            self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt in('Transfère','Credit') and date BETWEEN '{date_debut}' and '{date_fin}'").fetchone()[0]


        conn.close()
        if  None==self.data:
                self.data =0.0
        print(self.data)
        print('ec   self.data')
        return self.data
    
    
    def def_ctn_pg(self,date_debut,date_fin):
        print('date_debut',date_debut,'date_fin',date_fin)
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Row(
                        controls=[
                            Container(
                                height=130,
                                width=350,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=4,
                                content=Column(
                                    #expand=True,
                                    spacing=1,
                                    controls=[
                                        
                                        Container(
                                            content=Column(
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Row(
                                                        
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("Solde Initiale : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=200,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[Text("{:,}".format(self.def_solde_initial_final('si','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                            
                                                            
                                                        ]
                                                    ),
                                                    Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(+) Encaissement  : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=200,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[Text("{:,}".format(self.def_solde_initial_final('ec','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                        
                                                        ]
                                                    ),
                                                    Row(
                                                        
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(-) Decaissement : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=200,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[Text("{:,}".format(self.def_solde_initial_final('dc','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                        ]
                                                    ),
                                                    Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("Solde Final : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=200,
                                                                
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[Text("{:,}".format(self.def_solde_initial_final('sf','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                        ]
                                                    ),
                                                    
                                                ]
                                            )
                                        ),
                                        ]
                                )
                            ),
                            Container(
                                height=130,
                                width=500,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=4,
                                content=Column(
                                    #expand=True,
                                    spacing=1,
                                    controls=[
                                        
                                        Container(
                                            content=Column(
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Container(
                                                        #width=200,
                                                        bgcolor=colors.GREEN_300,
                                                        content=Row(
                                                            alignment=MainAxisAlignment.END,
                                                            controls=[Text("{:,}".format(self.def_solde_initial_final('sf','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                        )
                                                    ),
                                                    Container(
                                                        #width=200,
                                                        bgcolor=colors.GREEN_300,
                                                        content=Row(
                                                            alignment=MainAxisAlignment.END,
                                                            controls=[Text("{:,}".format(self.def_solde_initial_final('sf','Telma',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),]
                                                        )
                                                    ),
                                                    
                                                ]
                                            )
                                        ),
                                        ]
                                )
                            ),
                        ]
                    ),
                    Row(
                        
                        scroll='auto',
                        controls=[
                            
                            Container(
                                
                                height=460,
                                width=850,
                                bgcolor=colors.GREY_200,
                              
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=0,
                                content=Column(
                                    #expand=True,
                                    
                                    controls=[
                                        
                                        Container(
                                            expand=True,
                                            content=Row(
                                            spacing=1,
                                            controls=[
                                                Container(
                                                    
                                                    height=460,
                                                    width=425,
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.GREEN_100,
                                                    content=Column(
                                                        controls=[
                                                            Container(
                                                            bgcolor=colors.GREEN_200,
                                                            padding=0,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.CENTER,
                                                                    controls=[Text("ENCAISSEMENTS", size=16,weight='bold'),]
                                                                ),
                                                            ),
                                                            Container(
                                                                expand=True,
                                                                content=Column(
                                                                scroll='auto',
                                                                controls=[AppDataTableCaisse('encaissement','colors.GREY',date_debut,date_fin),]
                                                                )
                                                            )
                                                        ]
                                                    )
                                                ),
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.RED_100,
                                                    height=460,
                                                    width=425,
                                                    content=Column(
                                                        controls=[
                                                            Container(
                                                            bgcolor=colors.RED_200,
                                                            padding=0,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.CENTER,
                                                                    controls=[Text("DECAISSEMENTS", size=16,weight='bold'),]
                                                                ),
                                                            ),
                                                        
                                                            Container(
                                                                expand=True,
                                                                content=Column(
                                                                scroll='auto',
                                                                controls=[AppDataTableCaisse('decaissements','colors.GREY',date_debut,date_fin),]
                                                                )
                                                            )
                                                        ]
                                                    )
                                                )
                                                ,
                                        ]
                                    )
                                ),
                                        
                                    ]
                                )
                            ),
                        ]
                    )
                ]
            )
        )

    def handle_change1(self, e):
        # Update the button label when a new date is selected
        self.selected_date1 = e.control.value.strftime('%Y-%m-%d')
        self.button_date1.text = f"{self.selected_date1} Debut"
        self.button_date1.update()
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))
    def handle_change2(self, e):
        # Update the button label when a new date is selected
        self.selected_date2 = e.control.value.strftime('%Y-%m-%d')
        self.button_date2.text = f"{self.selected_date2} Fin"
        self.button_date2.update()
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))

    def handle_dismissal(self,e):
        (Text(f"DatePicker dismissed"))
        pass
    
    def recherche_btn(self,date_debut,date_fin):
        self.def_ctn_pg(date_debut,date_fin)
        self.ctn_pg.update()
        return
   
    def build(self):
        self.app_form_input_instance()
        
        self.def_ctn_pg(self.selected_date1,self.selected_date1)
        return Container(
            expand=True,
            bgcolor= colors.BROWN,
            height=610,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=0,
            content=Column(
                controls=[
                    Row(
                        spacing=0,
                        controls=[
                            Container(
                                height=660,
                                content=Column(
                                    spacing=0,
                                    controls=[
                                        Container(
                                            height=50,
                                            width=850,
                                            bgcolor=colors.GREY_200,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=2,
                                            content=Column(
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Container(
                                                        height=50,
                                                        width=500,
                                                        bgcolor=colors.GREEN_100,
                                                        content=Row(
                                                            alignment=MainAxisAlignment.START,
                                                            controls=[
                                                                self.button_date1,
                                                                self.button_date2,
                                                                TextButton(
                                                                    on_click=lambda e: self.recherche_btn(self.selected_date1,self.selected_date1),
                                                                    icon= icons.SEARCH
                                                                ),
                                                            ]
                                                        )
                                                    ),
                                                ]
                                            )
                                        ),
                                        self.ctn_pg,
                                    ]
                                )
                            ),
                            Container(
                                height=610,
                                width=500,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=2,
                                content=Column(
                                    scroll='auto',
                                    alignment=MainAxisAlignment.CENTER,
                                    controls=[
                                        
                                        Text("Etat de Caisse par Jour", size=15, weight=FontWeight.W_900, selectable=True),

                                        Container(
                                            height=570,
                                            width=500,
                                            content=Column(
                                                scroll='auto',
                                                controls=[
                                                    AppDataTableCaisseParJour('flux_caisse','color_icon')
                                                ]
                                            )
                                        )
                                    ]
                                )
                            )
                        ]
                    )
                ]
            )
        
        )
    
    

    def on_achat_click(self, e):
        print("Achat button clicked")

    def on_vente_click(self, e):
        print("Vente button clicked")




        """
            return Column(
            controls=[
                Text("Caisse Form", size=20, weight="bold"),
                ElevatedButton(
                    text="Achat",
                    on_click=self.on_achat_click
                ),
                ElevatedButton(
                    text="Vente",
                    on_click=self.on_vente_click
                ),
                ElevatedButton(
            "Pick date",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime.datetime(year=2023, month=10, day=1),
                    last_date=datetime.datetime(year=2024, month=10, day=1),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
                
            ]
        )
        """
        