from msilib import Dialog
import sqlite3
from flet import *
from btn import algo_traitement_data, close_dialog_erreur, retur_form_button
from controls import add_to_control_reference, return_controle_reference
from data_table import AppDataTable
from data_table import *
from data_table_login import AppDataTableLogin
control_map = return_controle_reference()

class AppSetting(UserControl):
    def __init__(self):
        super().__init__()
        self.operateur_dropdown = None
        self.type_operation_dropdown = None
        self.type_transfere_dropdown = None
        self.montant_field = None

    def app_form_input_instance(self):
        add_to_control_reference('AppSetting', self)

    def app_form_input_field(self, name: str, expand: int):
        self.montant_field = TextField(
            border_color="transparent",
            height=20,
            text_size=13,
            content_padding=0,
            cursor_color='black',
            cursor_width=1,
            cursor_height=18,
            color='black',
            read_only=True,  # Initially read-only
            opacity=0.5  # Make it look disabled
        )
        return Container(
            expand=expand,
            height=45,
            bgcolor="#ebebeb",
            border_radius=6,
            padding=8,
            content=Column(
                spacing=1,
                controls=[
                    Text(value=name, size=9, color='black', weight='bold'),
                    self.montant_field
                ]
            )
        )

    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
            
    def dialog_modif(self, e):
        
        # Créez des conteneurs pour chaque champ avec une marge
        operator_dropdown = Container(
            content=AppDataTableLogin(),

            margin=10
        )
        
        # Créez une ligne pour les boutons Modifier et Annuler
        action_buttons = Row(
            controls=[
                #TextButton("Modifier", on_click=lambda e: self.save_data(e, id)),
                TextButton("Fermer", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Modifier l'enregistrement"),
            content=Column(
                controls=[
                    operator_dropdown,
                ]
            ),
            actions=[action_buttons],
            actions_alignment=MainAxisAlignment.END
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
        
        
        
    def set_vide_text_login(self):
        self.identifiant_textfield = ""
        self.mdp_textfield = ""
        self.nom_textfield = ""
        self.statut_dropdown = ""    

    
    
    def save_data_new_compte(self, e):
        # Accédez aux composants individuels par clé
        identifiant_textfield = self.page.dialog.content.controls[0].content
        mdp_textfield = self.page.dialog.content.controls[1].content
        mdp_textfield1 = self.page.dialog.content.controls[2].content
        nom_textfield = self.page.dialog.content.controls[3].content
        statut_dropdown = self.page.dialog.content.controls[4].content

        # Récupérez les valeurs des composants
        identifiant = identifiant_textfield.value
        mdp = mdp_textfield.value
        mdp1 = mdp_textfield1.value
        nom = nom_textfield.value
        statut = statut_dropdown.value
        print(statut)
        if mdp==mdp1:
            montant = float(-3)
            if montant > 0:
                try:

                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()

                    cur.execute("""INSERT INTO loginTb (identifiant,mdp, nom, statut)
                                VALUES (?,?,?,?)""", (identifiant,mdp,nom,statut)
                    )
                    conn.commit()
                    conn.close()

                    # Réinitialiser les champs après l'insertion des données
                    self.close_dialog_modif
                    

                except KeyError as err:
                    dialog_erreur(self, err)
                    
                    print(err)
                    
                finally:
                    pass
                return
            else:
                print("Le montant doit être un nombre positif.")
                dialog_erreur(self, "Il faut remplir tous les champ!")
                return
        else :
            dialog_erreur(self, "Oops!Mot de passe incorrecte...")
    
        
        
        
    def dialog_creat_compte(self, e):
        
        #self.load_data(id)
        
        # Créez des conteneurs pour chaque champ avec une marge
        identifiant_textfield = Container(
            content=TextField( label="Identifiant"),
            margin=10
        )
        mdp_textfield = Container(
            content=TextField(label="Mot-de-passe", password=True),
            margin=10
        )
        mdp_textfield1 = Container(
            content=TextField(label="Mot-de-passe", password=True),
            margin=10
        )
        nom_textfield = Container(
            content=TextField( label="Nom et Prénom"),
            margin=10
        )
        statut_dropdown = Container(
            content=Dropdown(
                key="Statut",
                label="Statut",
                hint_text="Sélectionnez le Statut",
                options=[
                    dropdown.Option("Admin"),
                    dropdown.Option("Staff"),
                ],
                autofocus=True,
            ),
            margin=10
        )
        

        # Créez une ligne pour les boutons Modifier et Annuler
        action_buttons = Row(
            controls=[
                TextButton("Creér", on_click=lambda e: self.save_data_new_compte(e)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Creér un Compte"),
            content=Column(
                controls=[
                    
                    identifiant_textfield,
                    mdp_textfield,
                    mdp_textfield1,
                    nom_textfield,
                    statut_dropdown,
                ]
            ),
            actions=[action_buttons],
            actions_alignment=MainAxisAlignment.END
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def option_btn(self):
        return Container(
            width=240,  # Augmenté pour un meilleur espacement
            padding=10,  # Ajout de padding pour une meilleure apparence
            content=Column(
                alignment=MainAxisAlignment.START,
                expand=True,
                controls=[
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.MONEY_SHARP, color='#081d33', size=24),
                                Text("Tarif des Opérations", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Orange", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif),
                            PopupMenuItem(text="Telma", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif),
                            PopupMenuItem(text="Airtel", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif)
                        ],
                    ),
                    Divider(),  # Ajout d'un séparateur pour une meilleure distinction visuelle
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.GROUP_ADD, color='#081d33', size=24),
                                Text("Personnel", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Liste de Personnel", icon=icons.LIST_ALT, on_click=self.dialog_modif),
                            PopupMenuItem(text="Créer un Compte", icon=icons.GROUP_ADD_OUTLINED, on_click=self.dialog_creat_compte),
                        ],
                    ),
                    Divider(),  # Ajout d'un séparateur pour une meilleure distinction visuelle
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.PRICE_CHANGE, color='#081d33', size=24),
                                Text("Reglage Bonus", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Orange", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif),
                            PopupMenuItem(text="Telma", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif),
                            PopupMenuItem(text="Airtel", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif)
                        ],
                    ),
                ]
            )
        )

 
       
    '''   
    def creation_compte(self,statut):
        type_operation_dropdown = Container(
            content=Dropdown(
                key="type_operation",
                label="Type d'opération",
                hint_text="Sélectionnez le Type d'opération",
                options=[
                    dropdown.Option("Transfère"),
                    dropdown.Option("Retrait"),
                    dropdown.Option("Credit")
                ],
            ),
            margin=10
        )
        
        type_transfere_dropdown = Container(
            content=Dropdown(
                key="type_transfere",
                label="Type de transfère",
                hint_text="Sélectionnez le type de transfère",
                options=[
                    dropdown.Option("Sans Telephone"),
                    dropdown.Option("Avec Telephone"),
                ],
            ),
            margin=10
        )
        
        montant_textfield = Container(
            content=TextField( label="Montant"),
            margin=10
        )
        commentaire_textfield = Container(
            content=TextField( label="Commentaire"),
            margin=10
        )
        # Créez une ligne pour les boutons Modifier et Annuler
        action_buttons = Row(
            controls=[
                TextButton("Modifier", on_click=lambda e: self.save_data(e, id)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Modifier l'enregistrement"),
            content=Column(
                controls=[
                    type_operation_dropdown,
                    type_transfere_dropdown,
                    montant_textfield,
                    commentaire_textfield
                ]
            ),
            actions=[action_buttons],
            actions_alignment=MainAxisAlignment.END
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
      '''  
    """    
    def action_Creation_login(self):
        return Container(
            width=220,
            content=Row(
                expand=True,
                controls=[
                    
                    Text("Créer un Compte", size=16,color='#081d33', weight="bold"),  # Label
                    PopupMenuButton(
                        
                        items=[
                            PopupMenuItem(text="Admin", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif("Admin")),
                            PopupMenuItem(text="Staff", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=self.dialog_modif("Staff")),
                        ],
                        icon=icons.ADD_BOX
                        
                    ),
                    
                    
                ]
            )
            
        )
    """
        
    def build(self):
        self.app_form_input_instance()
        
        return Container(
            expand=True,
            height=600,
            #width=220,
            #bgcolor=colors.GREY,  # "white10",
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=15,
            content=Column(
                #expand=True,
                
                controls=[
                    
                    Row(
                        spacing=0,
                        controls=[
                            
                            Container(
                                height=600,
                                width=270,
                                bgcolor=colors.GREY_200, # "white10",
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=15,
                                #expand=True,
                                #bgcolor=colors.BLUE,
                                content=Column(
                                    expand=True,
                                    controls=[
                                        Row(
                                            controls=[
                                                self.option_btn(),
                                            ],
                                        ),
                                        Row(
                                            controls=[
                                                AppDataTableLogin(),
                                                #self.action_Creation_login(),
                                            ],
                                        ),
                                        
                                    ]
                                )
                            ),
                            Container(
                                #expand=True,
                                height=600,
                                width=1040,
                                bgcolor=colors.GREY_100,  # "white10",
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=15,
                                #bgcolor=colors.GREEN,
                                #content=Text("Conteneur Droit")
                                content=Column(
                                    controls=[
                                        Container(
                                            content=AppDataTableLogin(),

                                            margin=10
                                        ),
                                    ]
                                ),
                            )
                        ]
                    )
                ]
            )
        )


"""    
    return Container(
        expand=True,
        height=600,
        #width=220,
        #bgcolor=colors.GREY,  # "white10",
        border=border.all(1, "#ebebeb"),
        border_radius=8,
        padding=15,
        content=Column(
            #expand=True,
            
            controls=[
                
                Row(
                    spacing=0,
                    controls=[
                        
                        Container(
                            height=600,
                            width=220,
                            bgcolor=colors.GREY,  # "white10",
                            border=border.all(1, "#ebebeb"),
                            border_radius=8,
                            padding=15,
                            #expand=True,
                            #bgcolor=colors.BLUE,
                            content=Column(
                                expand=True,
                                controls=[
                                    Row(
                                        controls=[
                                            self.option_btn(),
                                        ],
                                    ),
                                    Row(
                                        controls=[
                                            self.option_btn(),
                                        ],
                                    ),
                                    Row(
                                        controls=[
                                            ElevatedButton(
                                                text="Achat",
                                                on_click=self.dialog_modif
                                            ),
                                            ElevatedButton(
                                                text="Vente",
                                                on_click=self.dialog_modif
                                            )
                                        ],
                                    ),
                                ]
                            )
                        ),
                        Container(
                            #expand=True,
                            height=600,
                            width=1090,
                            #bgcolor=colors.GREY,  # "white10",
                            border=border.all(1, "#ebebeb"),
                            border_radius=8,
                            padding=15,
                            bgcolor=colors.GREEN,
                            content=Text("Conteneur Droit")
                        )
                    ]
                )
            ]
        )
    )
"""