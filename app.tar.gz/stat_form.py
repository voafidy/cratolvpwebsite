import locale
import sqlite3
from flet import *
from btn import algo_traitement_data, retur_form_button
from controls import add_to_control_reference, return_controle_reference
from data_table import AppDataTable
from data_table_caisse import AppDataTableCaisse
from data_table_stat import AppDataTableStat, AppDataTableStatEnTete

control_map = return_controle_reference()
from datetime import datetime, timedelta
current_date = datetime.now().strftime("%Y-%m-%d")

class StatForm(UserControl):
    def __init__(self,page,username):
        super().__init__()
        self.page = page
        self.username=username
        
        self.drawer = NavigationDrawer(
            on_dismiss=self.handle_dismissal_start,
            on_change=self.handle_change_start,
            controls=[
                Container(height=12),
                NavigationDrawerDestination(
                    label="Item 1",
                    icon=icons.PASSWORD,
                    selected_icon_content=Icon(icons.PASSWORD_OUTLINED),
                ),
                Divider(thickness=2),
                NavigationDrawerDestination(
                    icon_content=Icon(icons.PASSWORD_SHARP),
                    label="Item 2",
                    selected_icon=icons.PASSWORD_ROUNDED,
                ),
                NavigationDrawerDestination(
                    icon_content=Icon(icons.CHANGE_CIRCLE_ROUNDED),
                    label="Item 3",
                    selected_icon=icons.PHONE,
                ),
            ],
        )
        self.end_drawer = NavigationDrawer(
        position=NavigationDrawerPosition.END,
        on_dismiss=self.handle_dismissal_end,
        on_change=self.handle_change_end,
        controls=[
            NavigationDrawerDestination(icon=icons.ADD_TO_HOME_SCREEN_SHARP, label="Item 1"),
            NavigationDrawerDestination(icon=icons.ADD_COMMENT, label="Item 2"),
        ],
     )
        self.selected_date1 = datetime.today().strftime('%Y-%m-%d')
        self.selected_date2 = datetime.today().strftime('%Y-%m-%d')
        self.yr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').year
        self.ms2=datetime.strptime(self.selected_date1,'%Y-%m-%d').month
        self.jr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').day
        
        # Obtenez la date d'aujourd'hui
        self.aujourdhui = datetime.now()
        self. m_0 = self.aujourdhui
        self.m_1 = self.aujourdhui - timedelta(days=self.aujourdhui.day-1)
        self.m_2 = self.m_1 - timedelta(days=self.m_1.day)
        self.m_3 = self.m_2 - timedelta(days=self.m_2.day)
        self.m_4 = self.m_3 - timedelta(days=self.m_3.day)
        # Définir la locale en français
        locale.setlocale(locale.LC_TIME, 'fr_FR')
        self.date_obj_mois_0 = self.m_0.strftime('%B').upper()
        self.date_obj_mois_1 = self.m_1.strftime('%B').upper()
        self.date_obj_mois_2 = self.m_2.strftime('%B').upper()
        self.date_obj_mois_3 = self.m_3.strftime('%B').upper()
        #print(mois_3,mois_2,mois_1)

        #aujourdhui = self.datetime.today().strftime('%Y-%m-%d')#
        self.mois_0 = self. m_0.strftime('%Y-%m-%d')
        self.mois_1 = self. m_1.strftime('%Y-%m-%d')
        self.mois_2 = self.m_2.strftime('%Y-%m-%d')
        self.mois_3 = self.m_3.strftime('%Y-%m-%d')
        self.mois_4 = self.m_4.strftime('%Y-%m-%d')
        self.selected_date3 = self.mois_1
        self.selected_date4 = self.mois_0
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
         
        self.text_bs_otm=Text(size=15, color='black', weight='bold')
        self.text_bs_pro=Text(size=15, color='black', weight='bold')
        self.text_bs_sal=Text(size=15, color='black', weight='bold')
        self.content_column_show_data=Column()
        self.content_column_table = Column(expand=True)
        self.content_column_stat = Column(expand=True)
        self.ctn_pg=Container(
            key='ctn_pg',height=520,width=1500,bgcolor=colors.RED_200,border=border.all(1, "#ebebeb"),border_radius=8,padding=0,
            content=Column(
                #scroll='auto',
                controls=[
                    self.content_column_stat,
                ],
            ),
        )
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        date_min = cur.execute(f"select min(date) as date_min from jounalierTb").fetchone()[0]
        print(date_min)
        if date_min:
            min_date_obj=datetime.strptime(date_min,'%Y-%m-%d')+timedelta(days=1)
            yr=min_date_obj.year
            ms=min_date_obj.month
            jr=min_date_obj.day
        
        conn.close()    
        
        self.button_date1=ElevatedButton(
            f"{self.selected_date1} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date2=ElevatedButton(
            f"{self.selected_date2} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr2, month=self.ms2, day=self.jr2),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change2,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        
        self.button_date3=ElevatedButton(
            f"{self.selected_date3} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change3,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date4=ElevatedButton(
            f"{self.selected_date4} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr4, month=self.ms4, day=self.jr4),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change4,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        

    def app_form_input_instance(self):
        add_to_control_reference('StatForm', self)


    def handle_change3(self, e):
        # Update the button label when a new date is selected
        self.selected_date3 = e.control.value.strftime('%Y-%m-%d')
        self.button_date3.text = f"{self.selected_date3} Debut"
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
        self.button_date3.update()
        self.filtre_data_date(self.selected_date3,self.selected_date4 )
        self.text_bs_otm.value=f"Partage Bonus : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[0]}"
        self.text_bs_pro.value=f"Bonus de la Proprietaire : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[1]}"
        self.text_bs_sal.value=f"Bonus de la Salarié : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[2]}"
        self.text_bs_otm.update()
        self.text_bs_pro.update()
        self.text_bs_sal.update()
        self.show_data(self.selected_date3,self.selected_date4)
        self.content_column_show_data.update()
        self.content_column_table.update()
    def handle_change4(self, e):
        # Update the button label when a new date is selected
        self.selected_date4 = e.control.value.strftime('%Y-%m-%d')
        self.button_date4.text = f"{self.selected_date4} Fin"
        self.button_date4.update()
        self.filtre_data_date(self.selected_date3,self.selected_date4 )
        self.text_bs_otm.value=f"Partage Bonus : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[0]}"
        self.text_bs_pro.value=f"Bonus de la Proprietaire : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[1]}"
        self.text_bs_sal.value=f"Bonus de la Salarié : {self.calcul_sum_bonus(self.selected_date3,self.selected_date4)[2]}"
        self.text_bs_otm.update()
        self.text_bs_pro.update()
        self.text_bs_sal.update()
        self.show_data(self.selected_date3,self.selected_date4)
        self.content_column_show_data.update()
        self.content_column_table.update()
    def handle_dismissal(self,e):
        (Text(f"DatePicker dismissed"))
        pass
    def handle_dismissal_start(self,e):
        print('Text("Drawer dismissed")')
        #self.page.add(Text("Drawer dismissed"))
    def handle_change_start(self,e):
        print('  page.close(drawer)')
        self.def_ctn_pg(self.selected_date1,self.selected_date1)
        self.page.update()
        self.page.close(self.drawer)

    def handle_dismissal_end(self,e):
        #self.page.add(Text("End drawer dismissed"))
        pass

    def handle_change_end(self,e):
        print('  page.close(drawer)')
        self.def_ctn_pg(self.selected_date1,self.selected_date1)
        self.page.update()
        self.page.close(self.end_drawer)
        # self.page.close(end_drawer)
    def recherche_btn(self,date_debut,date_fin):
        self.def_ctn_pg(date_debut,date_fin)
        self.ctn_pg.update()
        return
    def calcul_sum_bonus(self,date_debut,date_fin):
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        sum_bonus = cur.execute(f"""select sum(bonus_otm),sum( bonus_proprietaire),sum( bonus_user) from jounalierTb
            WHERE (date between '{date_debut}' and '{date_fin}') and types_mvt in ('Transfère', 'Credit', 'Retrait')""").fetchone()
        conn.close()
        return sum_bonus
                           
    def def_ctn_pg(self,date_debut,date_fin):
        self.text_bs_otm.value=f"Partage Bonus : {self.calcul_sum_bonus(date_debut,date_fin)[0]}"
        self.text_bs_pro.value=f"Bonus de la Proprietaire : {self.calcul_sum_bonus(date_debut,date_fin)[1]}"
        self.text_bs_sal.value=f"Bonus de la Salarié : {self.calcul_sum_bonus(date_debut,date_fin)[2]}"
        
        print('date_debut',date_debut,'date_fin',date_fin)
        self.content_column_stat.controls.clear()
        self.content_column_stat.controls.append(
           Column(
                expand=True,
                spacing=0,
                controls=[
                   
                    Container(
                        height=50,
                        bgcolor=colors.GREY,
                        border=border.all(1, "#ebebeb"),
                        border_radius=4,
                        padding=4,
                        content=Row(
                            expand=True,
                            alignment=MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                self.text_bs_otm,
                                self.text_bs_pro,
                                self.text_bs_sal,
                                Container(
                                    
                                    #bgcolor=colors.GREEN_100,
                                    content=Row(
                                        alignment=MainAxisAlignment.END,
                                        controls=[
                                            self.button_date3,
                                            self.button_date4,
                                            
                                        ]
                                    )
                                ),
                            ]
                        )
                    
                    ),
                    Container(
                         height=500,
                        width=1500,
                        content=Row(
                            spacing=1,
                            controls=[
                                
                                Container(
                                    height=500,
                                    width=1500,
                                    bgcolor=colors.GREEN_100,
                                    content=Column(
                                        alignment=MainAxisAlignment.START,
                                        controls=[
                                            self.content_column_table,
                                        ]
                                    )
                                ),
                                Container(
                                    height=0,
                                    width=0,
                                    bgcolor=colors.GREY,
                                    content=Column(
                                        #alignment=MainAxisAlignment.END,
                                        controls=[
                                            Text(f"Bilan Generale :",size=20, color='black', weight='bold'),
                                        ]
                                    )
                                ),
                                
                            ]
                        )
                    )
                ]
            )
        
        )
    def filtre_data_date(self,date_debut,date_fin):
        wd=1335
        self.content_column_table.controls.clear()
        self.content_column_table.controls.append(
           Column(
                expand=True,
                spacing=0,
                controls=[
                   Container(
                    height=50,
                    width=wd,
                    bgcolor=colors.GREY_300,
                    border=border.all(1, "#ebebeb"),
                    border_radius=4,
                    padding=4,
                    content=Column(
                        controls=[
                            AppDataTableStatEnTete()
                        ]
                    )
                    ),
                    Container(
                        height=415,
                        width=wd,
                        bgcolor=colors.GREY_200,
                        border=border.all(1, "#ebebeb"),
                        border_radius=4,
                        padding=4,
                        content=Column(
                            scroll='auto',
                            controls=[
                                AppDataTableStat(self.username,date_debut,date_fin)
                            ]
                        )
                    )
                ]
            )
        )
            

    def show_data(self, date_debut,date_fin):
        from datetime import datetime
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        print(current_date)
        try:
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            nb_op = cur.execute(f"select COUNT(*) from jounalierTb WHERE (date between '{date_debut}' and '{date_fin}') and types_mvt in ('Transfère', 'Credit', 'Retrait')").fetchone()[0]
            conn.close()
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            sum_date = cur.execute(f"""select sum(montant),sum(caisse),sum(solde),sum(solde_net_bs_user),
                                sum(bonus_otm),sum( bonus_user),sum( bonus_proprietaire),sum(frais_payer_client),
                                sum( frais_retirer_otm) from jounalierTb WHERE (date between '{date_debut}' and '{date_fin}') and types_mvt in ('Transfère', 'Credit', 'Retrait')""").fetchone()
            conn.close()
            surplus=sum_date[7]+sum_date[8]
            ca=solde_dispo+caisse_dispo+surplus
            montant_traite=sum_date[0]+sum_date[7]
            profit=sum_date[4]
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            caisse_dispo = cur.execute(f"select caisse from jounalierTb WHERE  id = (select max(id) from jounalierTb where (date between '{date_debut}' and '{date_fin}'))").fetchone()[0]
            conn.close()
        except:
            caisse_dispo = 0
            ca=0
            montant_traite=0
            surplus=0
            profit=0
        
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            solde_dispo_orange = cur.execute(f"select solde from jounalierTb WHERE id = (select max(id) from jounalierTb WHERE nom_otm ='Orange' and (date between '{date_debut}' and '{date_fin}')) ").fetchone()[0]
            conn.close()
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            solde_dispo_Telma = cur.execute(f"select solde from jounalierTb WHERE  id = (select max(id) from jounalierTb WHERE nom_otm ='Telma' and (date between '{date_debut}' and '{date_fin}'))").fetchone()[0]
            conn.close()
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            solde_dispo_Airtel = cur.execute(f"select solde from jounalierTb WHERE  id = (select max(id) from jounalierTb WHERE nom_otm ='Airtel' and (date between '{date_debut}' and '{date_fin}')) ").fetchone()[0]
            conn.close()
        except:
            solde_dispo_Telma =0
            solde_dispo_orange =0
            solde_dispo_Airtel =0
        # Charger les données existantes pour l'enregistrement à modifier
        
        solde_dispo=solde_dispo_Airtel+solde_dispo_orange+solde_dispo_Telma

            
        self.content_column_show_data.controls.clear()
        self.content_column_show_data.controls.append(
            Container(
                    height=50,
                    width=1160,
                    bgcolor=colors.GREY_200,
                    border=border.all(1, "#ebebeb"),
                    border_radius=8,
                    padding=0,
                    content=Row(
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            Container(
                                height=50,
                                width=90,
                               
                                bgcolor=colors.CYAN_100,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text(f"{nb_op}", size=20, color='black', weight='bold'),
                                        Text(f"Operations", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=200,
                               
                                bgcolor=colors.CYAN_200,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        
                                        Text("{:,}".format(montant_traite).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Montant Traité", size=10),
                                    ]
                                )
                            ),
                            Container(
                                height=50,
                                width=170,
                               
                                bgcolor=colors.CYAN_300,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(ca).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Chiffre d'Affaire", size=10),
                                    ]
                                )
                            ),        
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_400,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(profit).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Bénéfice", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=160,
                               
                                bgcolor=colors.CYAN_300,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(surplus).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Surplus", size=10),
                                    ]
                                )
                            ),
                            
                            Container(
                                height=50,
                                width=190,
                               
                                bgcolor=colors.CYAN_200,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(solde_dispo).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Solde Dispo", size=10),
                                    ]
                                )
                            ),
                            Container(
                                height=50,
                                width=190,
                               
                                bgcolor=colors.CYAN_100,
                                content=Column(
                                    expand=True,
                                    scroll='auto',
                                    horizontal_alignment="center",
                                    spacing=0,
                                    controls=[
                                        Text("{:,}".format(caisse_dispo).replace(",", " ")+' Ar', size=20, color='black', weight='bold'),
                                        Text(f"Caisse Dispo", size=10),
                                    ]
                                )
                            ),
                            
                        ]
                    )
                )
        )


    #self.page.add(ElevatedButton("Show drawer", icon= icons.MENU,on_click=lambda e: self.page.open(drawer)))

    def build(self):
        self.app_form_input_instance()
        self.drawer_start=TextButton(icon=icons.MENU, on_click=lambda e: self.page.open(self.drawer))
        self.drawer_end=TextButton(icon=icons.MORE_VERT, on_click=lambda e: self.page.open(self.end_drawer))
        self.def_ctn_pg(self.selected_date3,self.selected_date4)
        self.filtre_data_date(self.selected_date3,self.selected_date4)
        self.show_data(self.selected_date3,self.selected_date4)
        
        return Container(
            
            height=600,
            width=1500,
            bgcolor=colors.GREY_100,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=8,
            content=Column(
            controls=[
                Container(
                    
                    height=60,
                    width=1500,
                    bgcolor=colors.GREY_200,
                    border=border.all(1, "#ebebeb"),
                    border_radius=4,
                    padding=4,
                    content=Row(
                        expand=True,
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            self.drawer_start,
                           
                            self.content_column_show_data,
                            self.drawer_end
                        ]
                    )
                ),
                Container(
                    height=540,
                    width=1500,
                    bgcolor=colors.GREEN_100,
                    border=border.all(1, "#ebebeb"),
                    border_radius=8,
                    padding=0,
                    content=Column(
                        controls=[
                            self.ctn_pg,
                           
                        ]
                    )
                ),
            ]
            )
        )

        
        
"""        return Container(
            expand=True,
            height=600,
            width=800,
            bgcolor=colors.GREY,#"white10",
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=15,
            content=Column(
                controls=[
                    ElevatedButton( "0",icon=icons.MENU, on_click=self.show_drawer),#"Show drawer",
                ]
            )
        )"""


"""    controls=[
                    Row(
                        controls=[],
                    ),
                    Row(
                        controls=[
                            Text("Caisse Form", size=20, weight="bold"),
                            ElevatedButton(
                                text="Achat",
                                on_click=self.dialog_modif
                            ),
                            ElevatedButton(
                                text="Vente",
                                on_click=self.dialog_modif
                            )
                        ],
                    ),
                    
                    
                ]
            """
            
