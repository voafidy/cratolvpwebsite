from msilib import Dialog
import sqlite3
from flet import *
from btn import algo_traitement_data
from controls import return_controle_reference
control_map = return_controle_reference()

class ModifyForm(UserControl):
    def __init__(self, id, **kwargs):
        super().__init__(**kwargs)
        self.id = id
        self.data = None

    def load_data(self):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute("SELECT nom_otm, types_mvt,types_transfert, montant FROM jounalierTb WHERE id = ?", (self.id,))
        self.data = cur.fetchone()
        conn.close()

    def save_data(self, e):
        result = algo_traitement_data(self.operateur.value,self.type_mouvement.value,self.type_transfere.value,self.montant.value)
        # Enregistrez les modifications dans la base de données
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute("""UPDATE jounalierTb SET date =?, time =?, nom_otm =?, user =?, types_mvt =?, types_transfert =?, montant =?,
                            bonus_otm =?, bonus_user =?,
                            bonus_proprietaire =?, frais_payer_client =?, frais_retirer_otm =?, solde =?, solde_net_bs_user =?
                        WHERE id = ?""",
                    (result["current_date"], result["current_time"], result["nom_otm"], result["nom_user"], result["types_mvt"], 
                             result["types_transfert"], float(result["montant"]),
                             float(result["bonus_otm"]), float(result["bonus_user"]),
                             float(result["bonus_proprietaire"]), float(result["frais_payer_client"]), float(result["frais_retirer_otm"]),
                             float(result["solde"]), float(result["solde_net_bs_user"]), self.id))
        conn.commit()
        conn.close()

        # Fermer le popup et rafraîchir la table après la mise à jour
        self.page.overlay.remove(self)
        self.page.update()

        if 'AppDataTable' in control_map:
            control_map['AppDataTable'].refresh_data()

    def build(self):
        self.load_data()
        self.operateur=Dropdown(
                                key="operateur",
                                label="Nom d'opérateur",
                                hint_text="Sélectionnez l'Opérateur",
                                options=[
                                    dropdown.Option("Orange"),
                                    dropdown.Option("Telma"),
                                    dropdown.Option("Airtel")
                                ],
                                autofocus=True,
                                value=self.data[0],
                            )
        #cur.execute("SELECT nom_otm, types_mvt,types_transfert, montant FROM jounalierTb WHERE id = ?", (self.id,))
        
        self.type_mouvement = Dropdown(
                                key="type_operation",
                                label="Type d'opération",
                                hint_text="Sélectionnez le Type d'opération",
                                options=[
                                    dropdown.Option("Transfère"),
                                    dropdown.Option("Retrait"),
                                    dropdown.Option("Credit")
                                ],
                                #autofocus=True,
                                value=self.data[1],
                            )
        self.type_transfere = Dropdown(
                                key="type_transfere",
                                label="Type de transfère",
                                hint_text="Sélectionnez le type de transfère",
                                options=[
                                    dropdown.Option("Sans Telephone"),
                                    dropdown.Option("Avec Telephone"),
                                ],
                                #autofocus=True,
                                value=self.data[2],
                            )

        self.montant = TextField(value=str(self.data[3]), label="Montant")
        

        return Container(
            content=Column(
                controls=[
                    self.operateur,
                    self.type_mouvement,
                    self.type_transfere,
                    self.montant,
                    ElevatedButton(
                        text="Enregistrer",
                        on_click=self.save_data
                    )
                ]
            ),
            padding=20,
            border_radius=10,
            bgcolor='white',
            alignment=alignment.center
        )

    def open(self, page):
        self.page = page
        page.overlay.append(self)
        page.update()

