from flet import *
from controls import add_to_control_reference
import sqlite3


class DataBase(UserControl):
    def __init__(self):
        super().__init__()
        self.conn = None
        self.cursor = None
    def app_data_table_instance(self):
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()
        # Create table if it does not exist
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS jounalierTb (
                id INTEGER PRIMARY KEY,
                ref VARCHAR,
                user VARCHAR,
                types_mvt VARCHAR,
                montant DOUBLE,
                bonus DOUBLE,
                solde DOUBLE,
                nom_otm VARCHAR
            )
        """)
        self.conn.commit()
        
    def app_database_instance(self):
        add_to_control_reference('DataBase',self)
        
    def build(self):
        return super().build()