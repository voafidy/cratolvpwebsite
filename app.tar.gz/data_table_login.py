import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from modify_form import ModifyForm
from btn import algo_traitement_data, dialog_erreur

control_map = return_controle_reference()

class AppDataTableLogin(UserControl):
    def __init__(self,color_icon):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.color_icon=color_icon

    def app_data_table_instance(self):
        add_to_control_reference('AppDataTableLogin', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute("SELECT id_login, identifiant, nom, statut,actif FROM loginTb ORDER BY id_login DESC")
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_login(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=6),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete(e, id),
                                    bgcolor=self.color_icon,
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=6),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        self.controls[0].controls[0].rows = rows
        self.update()



    def close_dialog(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()




    
    def confirm_delete(self, e, id):
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Confirmer la suppression"),
            content=Text("Voulez-vous vraiment supprimer cet Compte ?"),
            actions=[
                TextButton("Oui", on_click=lambda e: self.delete_data(e, id)),
                TextButton("Non", on_click=self.close_dialog)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def delete_data(self, e, id):
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("DELETE FROM loginTb WHERE id_login = ?", (id,))
            conn.commit()
            conn.close()
            
            # Rafraîchir la table après la suppression
            self.refresh_data()

            # Fermer le dialogue
            self.close_dialog(e)
        except Exception as ex:
            print(f"Erreur lors de la suppression : {ex}")




        
    def save_data_edit_compte(self, e,id):
        # Récupérez les valeurs des composants
        actif = self.page.dialog.content.controls[0].value
        statut = self.page.dialog.content.controls[1].value

        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("""UPDATE loginTb SET actif = ?, statut = ? WHERE id_login = ?""",
                        (actif,statut,id))
            conn.commit()
            conn.close()

            # Fermer le popup et rafraîchir la table après la mise à jour
            self.close_dialog(e)
            self.page.update()
            if 'AppDataTableLogin' in control_map:
                control_map['AppDataTableLogin'].refresh_data()
            

        except KeyError as err:
                    
            self.error_message.value = err
            self.error_message.update()
            
            print(err)
            
        finally:
            pass
        return

    def load_data(self, id):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute("SELECT id_login, identifiant, nom, statut,actif FROM loginTb WHERE id_login = ?", (id,))
        self.data = cur.fetchone()
        conn.close()

    def dialog_modif_login(self, e, id):
        self.load_data(id)
        self.actif_dropdown = Dropdown(
                key="actif",
                label="actif",
                hint_text="Actif",
                options=[
                    dropdown.Option("oui"),
                    dropdown.Option("non"),
                ],
                value=self.data[4],
                autofocus=True,
            )
        self.statut_dropdown = Dropdown(
                key="Statut",
                label="Statut",
                hint_text="Sélectionnez le Statut",
                options=[
                    dropdown.Option("Admin"),
                    dropdown.Option("Staff"),
                ],
                value=self.data[3],
                autofocus=True,
            )
        self.error_message = Text("", color=colors.RED,size=13,weight='bold',)
        
                

        self.action_buttons = Row(
            controls=[
                TextButton("Modifier", on_click=lambda e: self.save_data_edit_compte(e,id)),
                TextButton("Annuler", on_click=self.close_dialog)
            ],
            alignment=MainAxisAlignment.END,
            
            spacing=40
        )

        self.dialog = AlertDialog(
            
            modal=True,
            title=Text("Modifier l'enregistrement de Login"),
            content=Column(
                width=400,
                height=160,
                controls=[
                    self.actif_dropdown,
                    self.statut_dropdown,
                    self.error_message,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
        
             
    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_login(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=6),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete(e, id),
                                    bgcolor=self.color_icon,
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=6),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        return Row(
            expand=True,
            controls=[
                DataTable(
                    expand=True,
                    border_radius=8,
                    border=border.all(2, '#ebebeb'),
                    horizontal_lines=border.BorderSide(1, '#ebebeb'),
                    columns=[
                        DataColumn(Container(Text('IDENTIFIANT', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('NOM', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('STATUT', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('ACTIF', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('ACTION', size=12, color='black', weight='bold'))),
                    ],
                    
                    rows=rows,
                )
            ]
        )
    


  
          
