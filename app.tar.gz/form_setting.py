from msilib import Dialog
import sqlite3
from flet import *
from btn import algo_traitement_data, close_dialog_erreur, retur_form_button
from controls import add_to_control_reference, return_controle_reference
from data_table import AppDataTable
from data_table import *
from data_table_bonus import  AppDataTableBonus
from data_table_login import *
from data_table_tarif import AppDataTableTarif
control_map = return_controle_reference()

class AppSetting(UserControl):
    def __init__(self,page):
        super().__init__()
        self.page = page
        self.content_column_setting = Column(expand=True)
        self.ctn_pg=Container(
                                key='ctn_pg',
                                height=600,
                                width=1055,
                                bgcolor=colors.GREY_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=10,
                                content=Column(
                                    #scroll='auto',
                                    
                                    controls=[
                                        self.content_column_setting,
                                        
                                        
                                    ],
                                ),
                                
                        )
        
    
    
    

    
    
    def app_form_input_instance(self):
        add_to_control_reference('AppSetting', self)

    def app_form_input_field(self, name: str, expand: int):
        self.montant_field = TextField(
            border_color="transparent",
            height=20,
            text_size=13,
            content_padding=0,
            cursor_color='black',
            cursor_width=1,
            cursor_height=18,
            color='black',
            read_only=True,  # Initially read-only
            opacity=0.5  # Make it look disabled
        )
        return Container(
            expand=expand,
            height=45,
            bgcolor="#ebebeb",
            border_radius=6,
            padding=8,
            content=Column(
                spacing=1,
                controls=[
                    Text(value=name, size=9, color='black', weight='bold'),
                    self.montant_field
                ]
            )
        )

    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
            
   
        
    def set_vide_text_login(self):
        self.identifiant_textfield.value = ""
        self.identifiant_textfield.update()
        self.mdp_textfield.value = ""
        self.mdp_textfield.update()
        self.mdp_textfield1.value = ""
        self.mdp_textfield1.update()
        self.nom_textfield.value = ""
        self.nom_textfield.update()
        self.statut_dropdown.value = None
        self.statut_dropdown.update()
    def set_vide_text_Tarif(self):
        self.montant_minTextField.value = ""
        self.montant_minTextField.update()
        self.montant_maxTextField.value = ""
        self.montant_maxTextField.update()
        self.dep_avec_telTextField.value = ""
        self.dep_avec_telTextField.update()
        self.dep_sans_telTextField.value = ""
        self.dep_sans_telTextField.update()
        self.retraitTextField.value = ''
        self.retraitTextField.update()
        self.totalTextField.value = ''
        self.totalTextField.update()
        

    def add_new_tarif(self,e,otm):
        montant_min=self.montant_minTextField.value
        montant_max=self.montant_maxTextField.value
        dep_avec_tel=self.dep_avec_telTextField.value
        dep_sans_tel=self.dep_sans_telTextField.value
        retrait=self.retraitTextField.value
        total=self.totalTextField.value
        
        if montant_min and montant_max and dep_avec_tel and dep_sans_tel and retrait and total:
            
            try :
                testFlozt= float(montant_min)+float(montant_max)+float(dep_avec_tel)+float(dep_sans_tel)+float(retrait)+float(total)
                if float(montant_min) < float(montant_max):
                    try:

                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()

                        cur.execute(f"""INSERT INTO tarif_frais_{otm} (montant_min,montant_max, dep_avec_tel, dep_sans_tel, retrait, total_frais)
                                    VALUES (?,?,?,?,?,?)""", (montant_min,montant_max,dep_avec_tel,dep_sans_tel,retrait,total)
                        )
                        conn.commit()
                        conn.close()

                        dialog_erreur(self, "Le nouveau tarif à éte bien enregistrer...")
                        self.set_vide_text_Tarif()
                        self.error_message_tarif.update()
                        if f'AppDataTableTarif_{otm}' in control_map:
                            control_map[f'AppDataTableTarif_{otm}'].refresh_data()
                        

                    except ValueError:
                                
                        dialog_erreur(self, ValueError)
                        
                        print(ValueError)
                        
                    finally:
                        pass
                    return
                else:
                    #dialog_erreur(self, "Oops!Mot de passe incorrecte...")
                    dialog_erreur(self, "Oops! Le montant min doit etre strictement inferieur au montant max!")
                    
                    return
            
            except ValueError :
                print(ValueError) 
                dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return
                
        else :
            print("Il faut remplir tous les champ!")
            dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
            return
        
    def formulaire_tarif(self,e,otm):
        self.montant_minTextField = TextField(label="Montant Min", width=250,height=50)
        self.montant_maxTextField = TextField(label="Montant Max", width=250,height=50)
        self.dep_avec_telTextField = TextField(label="Frais avec Tel", width=250,height=50)
        self.dep_sans_telTextField = TextField(label="Frais Sans Tel", width=250,height=50)
        self.retraitTextField = TextField(label="Frais Rétrait", width=250,height=50)
        self.totalTextField = TextField(label="Total", width=250,height=50)
        self.bouttonAjouteTarif=TextButton("Ajouter", on_click=lambda e: self.add_new_tarif(e,otm), icon= icons.ADD)
        self.error_message_tarif = Text("", color=colors.RED,size=13,weight='bold',)
        
        if otm == 'om':
            op='Orange'
            couleur=colors.ORANGE
        elif otm=='mvola':
            op='Telma'
            couleur=colors.YELLOW
        elif otm=='am':
            couleur=colors.RED
            op='Airtel'
        else:
            op='non identifier'
                
        
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Row(
                        controls=[
                            Container(
                                height=165,
                                width=1030,
                                bgcolor=couleur,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=8,
                                content=Column(
                                    #expand=True,
                                    spacing=1,
                                    controls=[
                                        Text(f"Ajouter un nouveau Tarif {op}",size=16,weight='bold'),
                                        Container(
                                            height=150,
                                            width=1020,
                                            bgcolor=colors.GREY_300,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            expand=True,
                                            
                                            content=Row(
                                                spacing=5,
                                                controls=[
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.montant_minTextField ,
                                                        self.montant_maxTextField ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.dep_avec_telTextField ,
                                                    self.dep_sans_telTextField ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.retraitTextField ,
                                                        self.totalTextField ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.bouttonAjouteTarif,
                                                        self.error_message_tarif
                                                        ]
                                                    ),
                                            ]
                                        ))
                                    ]
                                )
                            )]
                    ),
                    Row(
                        controls=[
                            
                            Container(
                                bgcolor=couleur,
                                height=400,
                                width=1030,
                                #bgcolor=colors.GREY_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=8,
                                content=Column(
                                    expand=True,
                                    
                                    controls=[
                                        Container(
                                            content=Column(
                                            controls=[Text(f"Tarif {op}", size=16,weight='bold'),]
                                        )),
                                        Container(
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            bgcolor=colors.GREY_200,
                                            expand=True,
                                            content=Column(
                                            scroll='auto',
                                            controls=[
                                                AppDataTableTarif(otm,colors.GREY_200),
                                                ]
                                        ))
                                        
                                ]
                            )
                        ),]
                    )
                    
                    
                ]
            )
        )
        print("self.page")
        self.ctn_pg.update()
        self.page.update()
        print(self.content_column_setting)
        #      key='ctn_pg')
        
    def formulaire_creat_compte(self, e):
        self.identifiant_textfield = TextField(label="Identifiant")
        self.mdp_textfield = TextField(label="Mot-de-passe",can_reveal_password=True, password=True)
        self.mdp_textfield1 = TextField(label="Confimer-le-Mot-de-passe",can_reveal_password=True, password=True)
        self.nom_textfield = TextField(label="Nom et Prénom")
        self.statut_dropdown = Dropdown(
                key="Statut",
                label="Statut",
                hint_text="Sélectionnez le Statut",
                options=[
                    dropdown.Option("Admin"),
                    dropdown.Option("Staff"),
                ],
                autofocus=True,
            )
        self.error_message = Text("", color=colors.RED,size=13,weight='bold',)
        
                

        self.action_buttons = Row(
            controls=[
                TextButton("Créer", on_click=self.save_data_new_compte),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            
            spacing=40
        )

        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Row(
                expand=True,
                controls=[
                    Column(
                        controls=[
                            Container(
                                
                                height=570,
                                width=300,
                                bgcolor=colors.GREY_300,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=5,
                                content=Column(
                                    #expand=True,
                                    spacing=20,
                                    controls=[
                                        Text("Création du Compte Utilisateur",size=16,weight='bold'),
                                        self.identifiant_textfield,
                                        self.mdp_textfield,
                                        self.mdp_textfield1,
                                        self.nom_textfield,
                                        self.statut_dropdown,
                                        self.error_message,
                                        self.action_buttons,
                                    ]
                                )
                            )]
                    ),
                    Column(
                        controls=[
                            Container(
                                
                                height=570,
                                width=720,
                                bgcolor=colors.GREY_300,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=5,
                                content=Column(
                                    controls=[
                                        Container(
                                            
                                            content=Column(
                                                controls=[Text("Liste des Utilisateurs", size=16,weight='bold'),]
                                            ),
                                        ),
                                        Container(
                                            height=520,
                                            width=710,
                                            bgcolor=colors.GREY_200,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            content=Column(
                                                expand=True,
                                                scroll='auto',
                                                controls=[
                                                    AppDataTableLogin(colors.GREY_200)],
                                            )
                                        )
                                    ]
                            )
                        ),]
                    )
                    
                    
                ]
            )
        )
        print("self.page")
        self.ctn_pg.update()
        self.page.update()
        print(self.content_column_setting)
        #      key='ctn_pg')
    
    def update_mode_calcule_bonus(self,e,x):
        try:
            print("update_mode_calcule_bonus")
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()

            cur.execute(f"""INSERT INTO mode_bonus{x} (pourcentage,appliquer) VALUES (?,?)""",
                        (self.pourcentage_textfield.value,self.statut_dropdown.value))
            
            conn.commit()
            conn.close()
            self.dialogue_message_tarif(e)
            # Fermer le popup et rafraîchir la table après la mise à jour
            self.page.update()

        except ValueError:
                    
            #dialog_erreur(self, ValueError)
            
            print(ValueError)
            
        finally:
            pass
        return
    def update_ratio_partage_bonus(self,e):
        try:
            from datetime import datetime
            now = datetime.now()
            current_date = now.strftime("%Y-%m-%d")
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute(f"""INSERT INTO mode_partage_bonus (pourcentage,date) VALUES (?,?)""",
                        (self.pourcentage_textfield.value,current_date))
            
            conn.commit()
            conn.close()
            self.content_column_setting.update()
            self.dialogue_message_tarif(e)
            # Fermer le popup et rafraîchir la table après la mise à jour
            self.page.update()

        except ValueError:
                    
            #dialog_erreur(self, ValueError)
            
            print(ValueError)
            
        finally:
            pass
        return
    def dialogue_message_tarif(self,e):
        self.dialog = AlertDialog(
            modal=True,
            #title=Text("Confirmer la suppression"),
            content=Text("Votre choix a été bien appliquer."),
            actions=[
                TextButton("Merci", on_click=self.close_dialog_modif)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()        
    
    def add_tranche_bonus(self,e,otm):
        # Récupérez les valeurs des composants
        montant_min=self.page.dialog.content.controls[0].value
        montant_max=self.page.dialog.content.controls[1].value
        bonus=self.page.dialog.content.controls[2].value
        
        if montant_min and montant_max and bonus:
            
            try :
                testFlozt= float(montant_min)+float(montant_max)+float(bonus)
                if float(montant_min) < float(montant_max):
                    try:
                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()
                        cur.execute(f"""insert into tranche_bonus_{otm}  (montant_min,montant_max, bonus) VALUES (?,?,?)""",
                        (montant_min,montant_max,bonus)
                        )
                        conn.commit()
                        conn.close()

                        # Fermer le popup et rafraîchir la table après la mise à jour
                        self.close_dialog_modif(e)
                        self.page.update()
                        if f'AppDataTableBonus_{otm}' in control_map:
                            control_map[f'AppDataTableBonus_{otm}'].refresh_data()
                        

                    except ValueError:
                                
                        #dialog_erreur(self, ValueError)
                        
                        print(ValueError)
                        
                    finally:
                        pass
                    return
                else:
                    #dialog_erreur(self, "Oops! Le montant min doit etre strictement inferieur au montant max!")
                    self.error_message_bonus.color = colors.RED
                    self.error_message_bonus.value = "Oops! Le montant min doit être strictement inferieur au montant max!"
                    self.error_message_bonus.update()
                    return
            
            except ValueError :
                print(ValueError) 
                self.error_message_bonus.color = colors.RED
                self.error_message_bonus.value = "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît."
                self.error_message_bonus.update()
                #dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message_bonus.color = colors.RED
            self.error_message_bonus.value = "Il faut remplir tous les champ!"
            self.error_message_bonus.update()
            #dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
            return

    def dialog_ajoute_bonus(self, e, otm):
        self.montant_minTextField = TextField(label="Montant Min",)
        self.montant_maxTextField = TextField(label="Montant Max",)
        self.dep_avec_telTextField = TextField(label="Bonus",)
        self.error_message_bonus = Text("", color=colors.RED,size=13,weight='bold',)
        
        
        # Créez une ligne pour les boutons Modifier et Annuler
        self.action_buttons = Row(
            controls=[
                TextButton("Ajouter", on_click=lambda e: self.add_tranche_bonus(e, otm)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Modifier le Tarif"),
            content=Column(
                width=150,
                height=500,
                controls=[
                    self.montant_minTextField,
                    self.montant_maxTextField,
                    self.dep_avec_telTextField,
                    self.error_message_bonus,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
     
    def ajouteTarif_buttons(self, otm,coleur) :
        return Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: self.dialog_ajoute_bonus(e,otm),
            bgcolor=coleur,
            color='black',
            content=Row(
                controls=[
                    Icon(
                        name=icons.ADD,
                        size=20,
                    ),
                    Text(
                        'Ajouter',
                        size=15,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=38,
            width=130,
        )
    )    
                
    def formulaire_bonus(self, e):

        print("update_mode_calcule_bonus")
        try:
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("select * from mode_bonus ORDER BY id DESC LIMIT 1")
            self.data = cur.fetchone()
            conn.close()
        except KeyError as err:
            print(err)
            pass

        
        self.pourcentage_textfield = TextField(label="Pourcentage",value=str(self.data[1]))
        self.statut_dropdown = Dropdown(
                key="calcul_bns",
                label="Choix de calcule de Bonus",
                hint_text="Sélectionnez le mode de calcule de bonus",
                options=[
                    dropdown.Option("Pourcentage"),
                    dropdown.Option("Tarif"),
                ],
                value=self.data[2],
                autofocus=True,
            )
        
                

        self.action_buttons = Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: self.update_mode_calcule_bonus(e,""),
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.LOCAL_ACTIVITY,
                        size=14,
                    ),
                    Text(
                        'Appliquer',
                        size=15,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=42,
            width=150,
        )
    )
        
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Row(
                        controls=[
                            Container(
                                height=100,
                                width=1030,
                                bgcolor=colors.GREEN_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=8,
                                content=Column(
                                    #expand=True,
                                    spacing=1,
                                    controls=[
                                        Text("Determination de bonus Mobile Money",size=16,weight='bold'),
                                        Container(
                                            height=90,
                                            width=1030,
                                            bgcolor=colors.GREEN_200,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            expand=True,
                                            
                                            content=Row(
                                                spacing=5,
                                                controls=[
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.pourcentage_textfield ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.statut_dropdown ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.action_buttons
                                                        ]
                                                    ),
                                                ]
                                            )
                                        )
                                    ]
                                )
                            )]
                    ),
                    Row(
                        scroll='auto',
                        controls=[
                            
                            Container(
                                
                                height=500,
                                width=1030,
                                bgcolor=colors.GREEN_100,
                              
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=4,
                                content=Column(
                                    #expand=True,
                                    
                                    controls=[
                                        
                                        Container(
                                            #expand=True,
                                            content=Row(
                                            scroll='auto',
                                            controls=[
                                                Container(
                                                    
                                                    height=450,
                                                    width=480,
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=4,
                                                    bgcolor=colors.ORANGE,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Orange", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('om','orange')
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('om',colors.ORANGE),]
                                                        )
                                                        )
                                                        ]
                                                    )
                                                ),
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.YELLOW,
                                                    height=450,
                                                    width=480,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Telma", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('mvola',colors.YELLOW)
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('mvola',colors.YELLOW),]
                                                            )
                                                        )
                                                    ]
                                                )
                                                )
                                                ,
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.RED,
                                                    height=450,
                                                    width=480,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Airtel", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('am',colors.RED)
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('am',colors.RED),]
                                                            )
                                                        )
                                                    ]
                                                )
                                                )
                                        ]
                                    )
                                ),
                                        
                                    ]
                                )
                            ),
                        ]
                    )
                    
                    
                ]
            )
        
        )
        print("self.page")
        self.ctn_pg.update()
        self.page.update()
        print(self.content_column_setting)
        #      key='ctn_pg')
                
    def formulaire_bonus_Credit(self, e):

        print("update_mode_calcule_bonus")
        try:
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("select * from mode_bonus_crd ORDER BY id DESC LIMIT 1")
            self.data = cur.fetchone()
            conn.close()
        except KeyError as err:
            print(err)
            pass

        
        self.pourcentage_textfield = TextField(label="Pourcentage",value=str(self.data[1]))
        self.statut_dropdown = Dropdown(
                key="calcul_bns",
                label="Choix de calcule de Bonus",
                hint_text="Sélectionnez le mode de calcule de bonus",
                options=[
                    dropdown.Option("Pourcentage"),
                    dropdown.Option("Tarif"),
                ],
                value=self.data[2],
                autofocus=True,
            )
        
                

        self.action_buttons = Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: self.update_mode_calcule_bonus(e,'_crd'),
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.LOCAL_ACTIVITY,
                        size=14,
                    ),
                    Text(
                        'Appliquer',
                        size=15,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=42,
            width=150,
        )
    )
        
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Row(
                        controls=[
                            Container(
                                height=100,
                                width=1030,
                                bgcolor=colors.GREEN_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=8,
                                content=Column(
                                    #expand=True,
                                    spacing=1,
                                    controls=[
                                        Text("Determination de bonus de Credit",size=16,weight='bold'),
                                        Container(
                                            height=90,
                                            width=1030,
                                            bgcolor=colors.GREEN_200,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=8,
                                            expand=True,
                                            
                                            content=Row(
                                                spacing=5,
                                                controls=[
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.pourcentage_textfield ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.statut_dropdown ,
                                                        ]
                                                    ),
                                                    Column(
                                                        spacing=6,
                                                        controls=[
                                                        self.action_buttons
                                                        ]
                                                    ),
                                                ]
                                            )
                                        )
                                    ]
                                )
                            )]
                    ),
                    Row(
                        scroll='auto',
                        controls=[
                            
                            Container(
                                
                                height=500,
                                width=1030,
                                bgcolor=colors.GREEN_100,
                              
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=4,
                                content=Column(
                                    #expand=True,
                                    
                                    controls=[
                                        
                                        Container(
                                            #expand=True,
                                            content=Row(
                                            scroll='auto',
                                            controls=[
                                                Container(
                                                    
                                                    height=450,
                                                    width=480,
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=4,
                                                    bgcolor=colors.ORANGE,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Credit Orange", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('crd_orange','orange')
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('crd_orange',colors.ORANGE),]
                                                        )
                                                        )
                                                        ]
                                                    )
                                                ),
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.YELLOW,
                                                    height=450,
                                                    width=480,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Credit Telma", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('crd_telma',colors.YELLOW)
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('crd_telma',colors.YELLOW),]
                                                            )
                                                        )
                                                    ]
                                                )
                                                )
                                                ,
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.RED,
                                                    height=450,
                                                    width=480,
                                                    content=Column(
                                                        controls=[
                                                        Container(
                                                            
                                                            padding=0,
                                                            content=Row(
                                                                alignment=MainAxisAlignment.CENTER,
                                                                controls=[Text("Liste de Tarif des Bonus Credit Airtel", size=16,weight='bold'),
                                                                          self.ajouteTarif_buttons('crd_airtel',colors.RED)
                                                                          ]
                                                            )
                                                        ),
                                                        Container(
                                                            expand=True,
                                                            content=Column(
                                                            scroll='auto',
                                                            controls=[AppDataTableBonus('crd_airtel',colors.RED),]
                                                            )
                                                        )
                                                    ]
                                                )
                                                )
                                        ]
                                    )
                                ),
                                        
                                    ]
                                )
                            ),
                        ]
                    )
                    
                    
                ]
            )
        
        )
        print("self.page")
        self.ctn_pg.update()
        self.page.update()
        print(self.content_column_setting)
        #      key='ctn_pg')


    def def_ctn_pg(self):
        # Ensure the container is ad
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
        
        Column(expand=True,
        controls=[
                AppDataTableLogin(colors.GREY_100)
                ])
        )
        
    def save_data_new_compte(self, e):
  
        # Récupérez les valeurs des composants
        identifiant =  self.identifiant_textfield.value
        mdp = self.mdp_textfield.value
        mdp1 = self.mdp_textfield1.value
        nom = self.nom_textfield.value
        statut = self.statut_dropdown.value
        print(identifiant,mdp)
        if identifiant and mdp and nom and statut:
            if mdp==mdp1:
                try:
                    # Charger les données existantes pour l'enregistrement à modifier
                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()
                    cur.execute("SELECT * FROM loginTb WHERE identifiant = ? ", (identifiant,))
                    self.data = cur.fetchone()
                    conn.close()
                except KeyError as err:
                    print(err)
                    pass
                if self.data:
                    self.error_message.value = "Oops! Cette Identifiant déja existe..."
                    self.error_message.update()
                else:
                    try:

                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()

                        cur.execute("""INSERT INTO loginTb (identifiant,mdp, nom, statut,actif)
                                    VALUES (?,?,?,?,?)""", (identifiant,mdp,nom,statut,'oui')
                        )
                        conn.commit()
                        conn.close()

                        self.error_message.value = "La création de compte succée..."
                        self.error_message.color = colors.GREEN
                        self.set_vide_text_login()
                        self.error_message.update()
                        if 'AppDataTableLogin' in control_map:
                            control_map['AppDataTableLogin'].refresh_data()
                        

                    except KeyError as err:
                                
                        self.error_message.value = err
                        self.error_message.update()
                        
                        print(err)
                        
                    finally:
                        pass
                    return
            else:
                #dialog_erreur(self, "Oops!Mot de passe incorrecte...")
                self.error_message.color = colors.RED
                self.error_message.value = "Oops!Mot de passe incorrecte..."
                self.error_message.update()
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message.color = colors.RED
            self.error_message.value = "Il faut remplir tous les champ!"
            self.error_message.update()
            return

    def formulaire_partage_bonus(self, e):

        print("update_mode_calcule_bonus")
        try:
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("select * from mode_partage_bonus ORDER BY id DESC LIMIT 1")
            self.data = cur.fetchone()
            conn.close()
        except KeyError as err:
            print(err)
            pass

        self.ratio_actuel = TextField(text_size=20,label="Ratio de partage de bonus Actuel",disabled=True,value=str(self.data[2]))
        self.pourcentage_textfield = TextField(text_size=20,label="Changer le Ratio de partage de bonus",value=str(self.data[2]))
        
        

        self.action_buttons = Container(
        alignment=alignment.center,
        content=ElevatedButton(
            on_click=lambda e: self.update_ratio_partage_bonus(e),
            bgcolor='#081d33',
            color='white',
            content=Row(
                controls=[
                    Icon(
                        name=icons.LOCAL_ACTIVITY,
                        size=14,
                    ),
                    Text(
                        'Appliquer',
                        size=15,
                        weight='bold',
                    )
                ]
            ),
            style=ButtonStyle(
                shape={
                    "": RoundedRectangleBorder(radius=6),
                },
                color={
                    "": "white",
                },
            ),
            height=42,
            width=150,
        )
    )
        
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Column(
                        controls=[
                            Container(
                                height=600,
                                width=1030,
                                bgcolor=colors.GREEN_100,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=8,
                                content=Column(
                                    #expand=True,
                                    spacing=10,
                                    controls=[
                                        Column(
                                            spacing=6,
                                            controls=[
                                            Text(f"Paramètre de patage de bonus(Ratio actuel : {self.data[2]})",size=16,weight='bold'),
                                            ]
                                        ),
                                        Column(
                                            spacing=6,
                                            controls=[
                                            #self.ratio_actuel ,
                                            ]
                                        ),
                                        Column(
                                            spacing=6,
                                            controls=[
                                            self.pourcentage_textfield ,
                                            ]
                                        ),
                                        Column(
                                            spacing=6,
                                            controls=[
                                            self.action_buttons
                                            ]
                                        ),
                                    
                                    ]
                                )
                            )]
                    ),
                ]
            )
        
        )
        print("self.page")
        self.ctn_pg.update()
        self.page.update()
        print(self.content_column_setting)
        #      key='ctn_pg')

    def option_btn(self):
        return Container(
            width=240,  # Augmenté pour un meilleur espacement
            padding=10,  # Ajout de padding pour une meilleure apparence
            content=Column(
                alignment=MainAxisAlignment.START,
                expand=True,
                controls=[
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.MONEY_SHARP, color='#081d33', size=24),
                                Text("Tarif des Opérations", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Orange", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=lambda e: self.formulaire_tarif(e,'om')),
                            PopupMenuItem(text="Telma", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=lambda e: self.formulaire_tarif(e,'mvola')),
                            PopupMenuItem(text="Airtel", icon=icons.PHONELINK_SETUP_ROUNDED, on_click=lambda e: self.formulaire_tarif(e,'am'))
                        ],
                    ),
                    Divider(),  # Ajout d'un séparateur pour une meilleure distinction visuelle
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.GROUP_ADD, color='#081d33', size=24),
                                Text("Gestion des Utulisateurs", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Gérer L'Utilisateur", icon=icons.GROUP_ADD_OUTLINED, on_click=self.formulaire_creat_compte),
                            PopupMenuItem(text="Liste de Personnel", icon=icons.LIST_ALT, on_click=self.formulaire_creat_compte),
                        ],
                    ),
                    Divider(),  # Ajout d'un séparateur pour une meilleure distinction visuelle
                    #TextButton("Parametrage Bonus",icon=icons.SETTINGS_BACKUP_RESTORE,size=16, color='#081d33', weight="bold", on_click=self.formulaire_bonus),
                    PopupMenuButton(
                        content=Row(
                            [
                                Icon(icons.PRICE_CHANGE, color='#081d33', size=24),
                                Text("Paramètre Bonus", size=16, color='#081d33', weight="bold")
                            ],
                            alignment=MainAxisAlignment.START,
                            vertical_alignment=CrossAxisAlignment.CENTER  # Centrer verticalement
                        ),
                        items=[
                            PopupMenuItem(text="Bonus Mobile Money", icon=icons.INSTALL_MOBILE_OUTLINED, on_click=self.formulaire_bonus),
                            PopupMenuItem(text="Bonus Credit", icon=icons.CREDIT_CARD, on_click=self.formulaire_bonus_Credit),
                            PopupMenuItem(text="Paramètre Partage Bonus", icon=icons.MONEY_OFF_OUTLINED, on_click=self.formulaire_partage_bonus),
                        ],
                    ),
                ]
            )
        )
    
    def build(self):
        self.app_form_input_instance()
        
        self.def_ctn_pg()
        return Container(
            expand=True,
            height=600,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=10,
            content=Column(
                controls=[
                    Row(
                        spacing=0,
                        controls=[
                            Container(
                                height=600,
                                width=270,
                                bgcolor=colors.GREY,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=15,
                                content=Column(
                                    expand=True,
                                    controls=[
                                        Row(
                                            controls=[self.option_btn()],
                                        ),
                                    ]
                                )
                            ),
                            self.ctn_pg,
                        ]
                    )
                ]
            )
        
        )