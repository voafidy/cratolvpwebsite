import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from caisse_form import CaisseForm
from data_table import AppDataTable
from form import AppForm
from form_cyber import AppCyber
from form_setting import AppSetting
from stat_form import StatForm
from login_form import LoginForm

control_map = return_controle_reference()
from datetime import datetime
current_date = datetime.now().strftime("%Y-%m-%d")
class AppHeader(UserControl):
    def __init__(self, page, content_column, username,nom,statut, on_logout):
        super().__init__()
        self.page = page
        self.content_column = content_column
        self.username = username
        self.nom = nom
        self.statut = statut
        self.on_logout = on_logout

    def app_header_insatance(self):
        add_to_control_reference('AppHeader', self)

    def app_header_brand(self):
        return Container(
            
            content=Text("Performance Plus - Management System", size=15, color=colors.GREY),
            
            )
            


    def app_header_avatar(self):
        return Container(
            content=PopupMenuButton(
                items=[
                    PopupMenuItem(icon=icons.PERSON,text=f" Connecté en tant que {self.username} - {self.statut}"),
                    PopupMenuItem(icon=icons.PASSWORD,text=f"Changer le mot de passe",on_click=self.change_mdp),
                    PopupMenuItem(text="Se déconnecter",icon=icons.LOGOUT_ROUNDED, on_click=self.handle_logout)
                ],
                icon=icons.PERSON,
            ),
        )

    def handle_logout(self, e):
        self.on_logout()


    def load_data_login(self, identifiant):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute("SELECT identifiant, mdp, nom, statut, actif FROM loginTb WHERE identifiant = ?", (identifiant,))
        self.data = cur.fetchone()
        conn.close()


    def close_dialog(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()

    def save_data_change_mdp(self, e):
        # Récupérez les valeurs des composants
        identifiant =  self.page.dialog.content.controls[0].value
        mdp = self.page.dialog.content.controls[1].value
        mdp1 = self.page.dialog.content.controls[2].value
        nom = self.page.dialog.content.controls[3].value
        statut = self.page.dialog.content.controls[4].value
        print(identifiant,mdp)
        if identifiant and mdp and nom and statut:
            if mdp==mdp1:
            
                try:
                    conn = sqlite3.connect('BDD/database.db')
                    cur = conn.cursor()
                    cur.execute("""UPDATE loginTb SET mdp = ? WHERE identifiant = ?""",
                                (mdp,identifiant))
                    conn.commit()
                    conn.close()

                    # Fermer le popup et rafraîchir la table après la mise à jour
                    self.close_dialog(e)
                    self.page.update()
                    
                    

                except KeyError as err:
                            
                    self.error_message.value = err
                    self.error_message.update()
                    
                    print(err)
                    
                finally:
                    pass
                return
            else:
                #dialog_erreur(self, "Oops!Mot de passe incorrecte...")
                self.error_message.color = colors.RED
                self.error_message.value = "Oops!Mot de passe incorrecte..."
                self.error_message.update()
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message.color = colors.RED
            self.error_message.value = "Il faut remplir tous les champ!"
            self.error_message.update()
            return

    def change_mdp(self,e):
        self.load_data_login(self.username)
        self.identifiant_textfield = TextField(label="Identifiant",value=self.data[0],disabled=True)
        self.mdp_textfield = TextField(label="Mot-de-passe", password=True,can_reveal_password=True,value=self.data[1])
        self.mdp_textfield1 = TextField(label="Confimer-le-Mot-de-passe",can_reveal_password=True, password=True)
        self.nom_textfield = TextField(label="Nom et Prénom",value=self.data[2],disabled=True)
        self.statut_dropdown = Dropdown(
                key="Statut",
                label="Statut",
                hint_text="Sélectionnez le Statut",
                options=[
                    dropdown.Option("Admin"),
                    dropdown.Option("Staff"),
                ],
                value=self.data[3],
                disabled=True,
            )
        self.error_message = Text("", color=colors.RED,size=13,weight='bold',)
        
                

        self.action_buttons = Row(
            controls=[
                TextButton("Modifier", on_click=lambda e: self.save_data_change_mdp(e)),
                TextButton("Annuler", on_click=self.close_dialog)
            ],
            alignment=MainAxisAlignment.END,
            
            spacing=40
        )

        self.dialog = AlertDialog(
            modal=True,
            title=Text("Changer Le mot de passe"),
            content=Column(
                controls=[
                    self.identifiant_textfield,
                    self.mdp_textfield,
                    self.mdp_textfield1,
                    self.nom_textfield,
                    self.statut_dropdown,
                    self.error_message,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
 








    def filtre_acces_admin(self):
        if self.statut =="Admin":
                    
            return [
            NavigationBarDestination(
                icon=icons.INSERT_DRIVE_FILE,
                selected_icon=icons.DESCRIPTION,
                label="Journal"
            ),
            NavigationBarDestination(
                icon=icons.PAYMENT,
                selected_icon=icons.MONEY,
                label="Caisse"
            ),
            NavigationBarDestination(
                icon=icons.QUERY_STATS,
                label="Statistique"
            ),
            NavigationBarDestination(
                icon=icons.SETTINGS,
                label="Paramètres"
            ),
            NavigationBarDestination(
                icon=icons.PRINT,
                label="Cyber"
            ),
            ]
        else:
            return [
            NavigationBarDestination(
                icon=icons.INSERT_DRIVE_FILE,
                selected_icon=icons.DESCRIPTION,
                label="Journal"
            ),
            NavigationBarDestination(
                icon=icons.PAYMENT,
                selected_icon=icons.MONEY,
                label="Caisse"
            ),
            ]
        
    
    def app_boutton_menu(self):
        return Container(
            width=420,
            bgcolor="#081d33",
            border_radius=6,
            opacity=1,
            animate_opacity=320,
            padding=8,
            content=CupertinoNavigationBar(
                bgcolor="#081d33",
                inactive_color=colors.GREY,
                active_color="#144B82",
                on_change=lambda e: self.handle_navigation_change(e),
                
                destinations=self.filtre_acces_admin()
            )
        )

    def handle_navigation_change(self, e):
        if e.control.selected_index == 0:
            self.content_column.controls.clear()
            self.content_column.controls.append(
                Column(
                expand=True,
                controls=[
                    AppForm(self.username),
                    Column(
                        scroll='auto',
                        expand=True,
                        controls=[
                            AppDataTable(self.username,current_date,current_date)
                        ]
                    )
                ]
            )
            )
            self.page.update()
        elif e.control.selected_index == 1:
            self.content_column.controls.clear()
            self.content_column.controls.append(CaisseForm(self.page,self.username))
            self.page.update()
        elif e.control.selected_index == 2:
            self.content_column.controls.clear()
            self.content_column.controls.append(StatForm(self.page,self.username))
            self.page.update()
        elif e.control.selected_index == 3:
            
            self.content_column.controls.clear()
            self.content_column.controls.append(
                AppSetting(self.page)
                )
            self.page.update()
        elif e.control.selected_index == 4:
            self.content_column.controls.clear()
            self.content_column.controls.append(AppCyber(self.page,self.username))
            self.page.update()
            print(self.page.update())
        else:
            self.content_column.controls.clear()
            self.content_column.controls.append(
                Column(
                expand=True,
                controls=[
                    AppForm(self.username),
                    Column(
                        scroll='auto',
                        expand=True,
                        controls=[
                            AppDataTable(self.username)
                        ]
                    )
                ]
            )
            )
            self.page.update()

    def build(self):
        self.app_header_insatance()
        return Container(
            padding=0,
            height=60,
            bgcolor="#081d33",
            border_radius=border_radius.only(top_left=15, top_right=15),
            content=Row(
                expand=True,
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    self.app_header_brand(),
                    self.app_boutton_menu(),
                    self.app_header_avatar(),
                ],
            )
        )
