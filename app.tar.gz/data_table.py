import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from modify_form import ModifyForm
from btn import algo_traitement_data, dialog_erreur, set_vide_text

control_map = return_controle_reference()

class AppDataTable(UserControl):
    def __init__(self,username,date1,date2):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.username=username
        self.date1=date1
        self.date2=date2
        
    def app_data_table_instance(self):
        add_to_control_reference('AppDataTable', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute(f"SELECT id, date, time, nom_otm, types_mvt, montant,frais_payer_client, bonus_otm, solde, caisse FROM jounalierTb  where date BETWEEN '{self.date1}' and '{self.date2}' ORDER BY id DESC")
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[0:]
                ]
                
            ) for row in data
        ]
        for i in rows:
            rownum = i.cells[0].content.value
            if int(rownum) %2 == 0 :
                i.color = colors.GREY_100
            else:
                i.color = colors.GREY_200

        # Mettre à jour la table avec les nouvelles données
        self.controls[0].controls[0].rows = rows
        self.update()

    def modify_data(self, e, id):
        modify_form = ModifyForm(id)
        modify_form.open(self.page)
        print(f"Modifier l'enregistrement avec l'ID {id}")

    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()

    def load_data(self, id):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute("SELECT nom_otm, types_mvt, types_transfert, montant,commentaire_modif FROM jounalierTb WHERE id = ?", (id,))
        self.data = cur.fetchone()
        conn.close()



    def update_auto(self,e,id ):
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        data = cur.execute(f"select  id, nom_otm , user , types_mvt , types_transfert , montant from jounalierTb where id >'{id}'   ORDER BY id asc ").fetchall()
        conn.close()
        for row in data:
            # Supposons que votre table a 3 colonnes: id, nom, et montant
            id = row[0]
            nom_otm = row[1]
            user = row[2]
            types_mvt = row[3]
            types_transfert = row[4]
            montant = row[5]
            print(f"ID: {id}, Nom: {nom_otm}, Montant: {montant}")
            result = algo_traitement_data(self.username,nom_otm, types_mvt, types_transfert, montant,None,id)

            try:
                # Enregistrez les modifications dans la base de données
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                cur.execute("""UPDATE jounalierTb SET nom_otm = ?, user = ?, types_mvt = ?, types_transfert = ?, montant = ?, 
                                bonus_otm = ?, bonus_user = ?, bonus_proprietaire = ?, frais_payer_client = ?, 
                                frais_retirer_otm = ?, solde = ?, solde_net_bs_user = ? 
                                ,date_modification=?,heure_modification=?,commentaire_modif=?,caisse=? WHERE id = ?""",
                            ( result["nom_otm"], result["nom_user"], result["types_mvt"], result["types_transfert"], float(result["montant"]),
                            float(result["bonus_otm"]), float(result["bonus_user"]),float(result["bonus_proprietaire"]), 
                            float(result["frais_payer_client"]), float(result["frais_retirer_otm"]), float(result["solde"]), 
                            float(result["solde_net_bs_user"]),result["current_date"], result["current_time"],result["commentaire"],result["caisse"], id))
                conn.commit()
                conn.close()
                print(f"Mise à jour id : {id} montant {montant} succée")
            except KeyError as e:
                print(e)
            
        
    def save_data(self, e, id):
        # Accédez aux composants individuels par clé
        operateur_dropdown = self.page.dialog.content.controls[0].content
        type_operation_dropdown = self.page.dialog.content.controls[1].content
        type_transfere_dropdown = self.page.dialog.content.controls[2].content
        montant_textfield = self.page.dialog.content.controls[3].content
        commentaire_textfield = self.page.dialog.content.controls[4].content

        # Récupérez les valeurs des composants
        operateur = operateur_dropdown.value
        type_operation = type_operation_dropdown.value
        type_transfere = type_transfere_dropdown.value
        montant = montant_textfield.value
        commentaire = commentaire_textfield.value
        
        try:
            montant = float(montant)
            if montant > 0:
                result = algo_traitement_data(self.username,operateur, type_operation, type_transfere, montant,commentaire,id)
                
                if float(result["caisse"])>=0:
                    if float(result["solde"])>=0:
                        try:
                            # Enregistrez les modifications dans la base de données
                            conn = sqlite3.connect('BDD/database.db')
                            cur = conn.cursor()
                            cur.execute("""UPDATE jounalierTb SET nom_otm = ?, user = ?, types_mvt = ?, types_transfert = ?, montant = ?, 
                                            bonus_otm = ?, bonus_user = ?, bonus_proprietaire = ?, frais_payer_client = ?, 
                                            frais_retirer_otm = ?, solde = ?, solde_net_bs_user = ? 
                                            ,date_modification=?,heure_modification=?,commentaire_modif=?,caisse=? WHERE id = ?""",
                                        ( result["nom_otm"], result["nom_user"], result["types_mvt"], result["types_transfert"], float(result["montant"]),
                                        float(result["bonus_otm"]), float(result["bonus_user"]),float(result["bonus_proprietaire"]), 
                                        float(result["frais_payer_client"]), float(result["frais_retirer_otm"]), float(result["solde"]), 
                                        float(result["solde_net_bs_user"]),result["current_date"], result["current_time"],result["commentaire"],result["caisse"], id))
                            conn.commit()
                            conn.close()
                            print('lancement regule auto')
                            
                            #self.update_auto(e,id)
                            print('Fin regule auto')
                            # Fermer le popup et rafraîchir la table après la mise à jour
                            self.close_dialog_modif(e)
                            self.page.update()
                            self.set_vide_text()
                            if 'AppDataTable' in control_map:
                                control_map['AppDataTable'].refresh_data()

                        except KeyError as e:
                            print(e)
                        finally:
                            pass
                        return 
                    else:
                        dialog_erreur(self, "Solde insuffisante. S'il vous plaît, Veuillez Ravitailler votre solde!")
                else:
                    dialog_erreur(self, "Espèce insuffisante. S'il vous plaît, Veuillez Ravitailler votre caisse!")
            else:
                print("Le montant doit être un nombre positif.")
                dialog_erreur(self, "Le montant doit être un nombre positif. Veuillez réessayer, s'il vous plaît.")
                return
        except ValueError:
            
                print("Le montant doit être un nombre.")
                
                dialog_erreur(self, "Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return


    def dialog_modif(self, e, id):
        self.load_data(id)
        
        # Créez des conteneurs pour chaque champ avec une marge
        operator_dropdown = Container(
            content=Dropdown(
                key="operateur",
                label="Nom d'opérateur",
                hint_text="Sélectionnez l'Opérateur",
                options=[
                    dropdown.Option("Orange"),
                    dropdown.Option("Telma"),
                    dropdown.Option("Airtel")
                ],
                autofocus=True,
                value=self.data[0],
            ),
            margin=10
        )
        
        type_operation_dropdown = Container(
            content=Dropdown(
                key="type_operation",
                label="Type d'opération",
                hint_text="Sélectionnez le Type d'opération",
                options=[
                    dropdown.Option("Transfère"),
                    dropdown.Option("Retrait"),
                    dropdown.Option("Credit")
                ],
                value=self.data[1],
            ),
            margin=10
        )
        
        type_transfere_dropdown = Container(
            content=Dropdown(
                key="type_transfere",
                label="Type de transfère",
                hint_text="Sélectionnez le type de transfère",
                options=[
                    dropdown.Option("Sans Telephone"),
                    dropdown.Option("Avec Telephone"),
                ],
                value=self.data[2],
            ),
            margin=10
        )
        
        montant_textfield = Container(
            content=TextField(value=str(self.data[3]), label="Montant"),
            margin=10
        )
        commentaire_textfield = Container(
            content=TextField(value=str(self.data[4]), label="Commentaire"),
            margin=10
        )
        
        # Créez une ligne pour les boutons Modifier et Annuler
        action_buttons = Row(
            controls=[
                
                TextButton("Modifier", on_click=lambda e: self.update_auto(e,220)),
                #TextButton("Modifier", on_click=lambda e: self.save_data(e, id)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Modifier l'enregistrement"),
            content=Column(
                controls=[
                    operator_dropdown,
                    type_operation_dropdown,
                    type_transfere_dropdown,
                    montant_textfield,
                    commentaire_textfield
                ]
            ),
            actions=[action_buttons],
            actions_alignment=MainAxisAlignment.END
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def confirm_delete(self, e, id):
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Confirmer la suppression"),
            content=Text("Voulez-vous vraiment supprimer cet enregistrement ?"),
            actions=[
                TextButton("Oui", on_click=lambda e: self.delete_data(e, id)),
                TextButton("Non", on_click=self.close_dialog)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def delete_data(self, e, id):
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("DELETE FROM jounalierTb WHERE id = ?", (id,))
            conn.commit()
            conn.close()
            
            # Rafraîchir la table après la suppression
            self.refresh_data()
            self.set_vide_text()
            # Fermer le dialogue
            self.close_dialog(e)
        except Exception as ex:
            print(f"Erreur lors de la suppression : {ex}")

    def close_dialog(self, e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
        
    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[0:]
                ] 
            ) for row in data 
        ]
        dtb=DataTable(
                    expand=True,
                    border_radius=8,
                    border=border.all(2, '#ebebeb'),
                    horizontal_lines=border.BorderSide(1, '#ebebeb'),
                    columns=[
                        DataColumn(Container(Text('ID', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Date', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Heure', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Libellé', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Type OP°', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Montant', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Frais', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('BonusOTM', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Solde', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Caisse', size=12, color='black', weight='bold'))),
                        #DataColumn(Container(Text('Actions', size=12, color='black', weight='bold'))),
                    ],
                    
                    rows=rows,
                )
        for i in dtb.rows:
            rownum = i.cells[0].content.value
            if int(rownum) %2 == 0 :
                i.color = colors.GREY_100
            else:
                i.color = colors.GREY_200
        return Row(
            expand=True,
            controls=[
                dtb
            ]
        )
    

    

    
          
