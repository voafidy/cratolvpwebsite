import flet as ft

def main(page: ft.Page):
    # Conteneur interne avec un texte initial
    inner_container = ft.Container(
        content=ft.Text("Initial Value"),
        padding=10
    )
    
    # Conteneur externe qui contient le conteneur interne
    outer_container = ft.Container(
        content=inner_container,
        padding=20
    )
    
    # Ajouter un bouton pour mettre à jour le conteneur interne
    def update_inner_container(e):
        inner_container.content.value = "Updated Value"
        inner_container.update()  # Met à jour le conteneur interne
    
    update_button = ft.ElevatedButton(
        text="Update Inner Container",
        on_click=update_inner_container
    )
    
    # Ajouter les conteneurs et le bouton à la page
    page.add(
        outer_container,
        update_button
    )

# Lancer l'application Flet
ft.app(target=main)
