import sqlite3


conn = sqlite3.connect('BDD/database.db')
cur = conn.cursor()
data = cur.execute(f"select  id, nom_otm , user , types_mvt , types_transfert , montant from jounalierTb where id >='220'   ORDER BY id DESC ").fetchall()
conn.close()
for row in data:
    # Supposons que votre table a 3 colonnes: id, nom, et montant
    id = row[0]
    nom_otm = row[1]
    user = row[2]
    types_mvt = row[3]
    types_transfert = row[4]
    montant = row[5]

    # Faites quelque chose avec les données récupérées
    print(f"ID: {id}, Nom: {nom_otm}, Montant: {montant}")