import os
from InvoiceGenerator.pdf import SimpleInvoice
from tempfile import NamedTemporaryFile
from InvoiceGenerator.api import Invoice, Item, Client, Provider, Creator
import random
import string
from flet import *

def main(page: Page):
    # SCROLL PAGE
    page.scroll = "auto"

    # GENERATE RANDOM INVOICE NUMBER WITH FORMAT EXAMPLE INV-090A
    def random_invoice_number(prefix):
        letters = string.ascii_uppercase
        # GENERATE NUMBER 1 - 10 
        numbers = ''.join(str(i) for i in range(10))
        # GENERATE RANDOM STRING
        random_string = ''.join(random.choice(letters + numbers) for _ in range(2))
        return prefix + random_string

    # TextFields for client and company
    txt_client_name = TextField(label="Client Name")
    txt_company = TextField(label="Company Name")

    # Input fields for items
    item_name = TextField(label="Item Name")
    item_unit = TextField(label="Unit")
    item_price = TextField(label="Price")

    # Initialize list of items to display
    listitem = Column()

    def additem(e):
        # Ensure values are not empty
        if item_name.value and item_unit.value and item_price.value:
            # Create an Item and add to the invoice
            new_item = Item(
                count=float(item_unit.value),
                price=float(item_price.value),
                description=item_name.value
            )
            invoice.add_item(new_item)

            # Append to list for display
            listitem.controls.append(
                Row([
                    Text(f"Item Name: {item_name.value}"),
                    Text(f"Unit: {item_unit.value}"),
                    Text(f"Price: {item_price.value}")
                ])
            )

            # Clear input fields and update page
            item_name.value = ""
            item_unit.value = ""
            item_price.value = ""
            item_name.update()
            item_unit.update()
            item_price.update()
            page.update()

    def generatenow(e):
        # Initialize PDF with dynamic client and provider information
        client = Client(txt_client_name.value)
        provider = Provider(txt_company.value, bank_account="23123", bank_code="2023")
        creator = Creator(txt_client_name.value)

        # Initialize invoice
        invoice = Invoice(client, provider, creator)
        prefix = "INV-"
        invoice.number = random_invoice_number(prefix)
        os.environ['INVOICE_LANG'] = "en"
        invoice.currency_locale = 'en_US.UTF-8'
        invoice.currency = "$"

        # Generate PDF invoice
        pdf = SimpleInvoice(invoice)
        pdf.gen("invoice.pdf", generate_qr_code=True)

    # Main UI layout
    page.add(
        Column([
            Text("Invoice App", size=30, weight="bold"),
            Container(
                content=Column([
                    txt_client_name,
                    txt_company,
                    Divider(),
                    Text("Insert Item Data", size=30, weight="bold"),
                    item_name,
                    item_unit,
                    item_price,
                    ElevatedButton("Add Item to List", bgcolor="blue", color="white", on_click=additem),
                    listitem,
                    ElevatedButton("Generate Now", bgcolor="orange", color="white", on_click=generatenow)
                ])
            )
        ])
    )

app(target=main)
