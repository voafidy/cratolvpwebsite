import os
import webbrowser  # Ajout du module pour ouvrir automatiquement le PDF
from InvoiceGenerator.pdf import SimpleInvoice
from tempfile import NamedTemporaryFile
from InvoiceGenerator.api import Invoice, Item, Client, Provider, Creator
import random
import string
from flet import *


def main(page: Page):
    # SCROLL PAGE
    page.scroll = "auto"

    # GENERATE RANDOM INVOICE NUMBER WITH FORMAT EXAMPLE
    # INV-090A LIKE THIS
    def random_invoice_number(prefix):
        letters = string.ascii_uppercase
        # GENERATE NUMBER 1 - 10
        numbers = ''.join(str(i) for i in range(10))
        # GENERATE RANDOM STRING
        random_string = ''.join(random.choice(letters + numbers) for _ in range(2))
        return prefix + random_string

    # INITIALIZE PDF
    client = Client('FLet corp')
    txt_client_name = TextField(label="client name")
    txt_company = TextField(label="company name")

    provider = Provider(txt_company.value, bank_account="23123", bank_code="2023")
    creator = Creator(txt_client_name.value)
    invoice = Invoice(client, provider, creator)
    prefix = "inv-"
    invoice.number = random_invoice_number(prefix)
    os.environ['INVOICE_LANG'] = "en"
    invoice.currency_locale = 'en_US.UTF-8'
    # AND SET YOU CURRENCY COUNTRY
    invoice.currency = "$"

    # INPUT DATA ===========================================
    ItemData = Column([
        # INPUT NAME PRICE COUNT
        TextField(label="item name"),
        TextField(label="Unit"),
        TextField(label="Price one"),

    ])

    listitem = Column()

    def additem(e):
        item = Item(
            # GET value of name unit and price and push
            # to LIST
            ItemData.controls[2].value,
            ItemData.controls[1].value,
            ItemData.controls[0].value,

        )
        invoice.add_item(item)
        listitem.controls.append(
            # SHOW YOU LIST ITEM IN FLET SCREEN
            Row([
                Text(f"item name : {ItemData.controls[2].value}"),
                Text(f"Unit : {ItemData.controls[1].value}"),
                Text(f"Price one : {ItemData.controls[0].value}"),

            ])
        )
        # AND CLEAR INPUT AFTER SUCCESS ADD TO LIST
        ItemData.controls[0].value = ""
        ItemData.controls[1].value = ""
        ItemData.controls[2].value = ""
        page.update()

    def generatenow(e):
        # GENERATE THE RESULT NOW
        pdf = SimpleInvoice(invoice)
        pdf_filename = "fac.pdf"
        pdf.gen(pdf_filename, generate_qr_code=True)
        
        # Open the generated PDF automatically
        webbrowser.open(f"file://{os.path.realpath(pdf_filename)}")

    inputcon = Container(
        content=Column([
            txt_client_name,
            txt_company,
            Divider(),
            Text("Insert item data", size=30, weight="bold"),
            ItemData,
            Divider(),
            ElevatedButton("Add item to list",
                           bgcolor="blue", color="white",
                           on_click=additem
                           ),
            listitem,
            ElevatedButton("Generate Now",
                           bgcolor="orange", color="white",
                           on_click=generatenow
                           ),
        ])
    )

    page.add(
        Column([
            Text("Invoice App", size=30, weight="bold"),
            inputcon

        ])

    )


app(target=main)
