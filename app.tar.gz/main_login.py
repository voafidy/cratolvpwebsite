import flet
from flet import *
from header import AppHeader
from form import AppForm
from data_table import AppDataTable
from caisse_form import CaisseForm
from login_form import LoginForm  # Import the LoginForm
from screeninfo import get_monitors

def main(page: Page):
    page.title = "Performance Plus-CSI(Cratol Service Informatique)"
    page.bgcolor ='#fdfdfd'# "#fdfdfd"
    page.padding = 20
    page.window_width = 500  # Set initial window width
    page.window_height = 300  # Set initial window height
    page.window.bgcolor = colors.TRANSPARENT
    #page.bgcolor =colors.TRANSPARENT
    #page.window.title_bar_hidden = True
    page.window.frameless = True
    # Get screen dimensions
    screen = get_monitors()[0]
    screen_width = screen.width
    screen_height = screen.height
    page.window_left = (screen_width - page.window_width) // 2
    page.window_top = (screen_height - page.window_height) // 2

    content_column = Column()

    def on_login_success(username):
        page.controls.clear()  # Remove all controls including the login form
        content_column.controls.clear()
        content_column.controls.append(
            Column(
                controls=[
                    AppForm(username),
                    Column(
                        scroll='hidden',
                        expand=True,
                        controls=[
                            AppDataTable(username)
                        ]
                    )
                ]
            )
        )
        page.add(
            Column(
                expand=True,
                controls=[
                    AppHeader(page, content_column, username, on_logout),
                    Divider(height=2, color="transparent"),
                    content_column
                ]
            )
        )
        page.window_maximized = True  # Maximize the window on successful login
        page.update()

    def on_logout():
        page.controls.clear()
        login_form = LoginForm(on_login_success)
        page.add(login_form)
        page.window_maximized = False  # Reset window size on logout
        page.window_width = 500  # Set initial window width
        page.window_height = 400  # Set initial window height
        page.window.bgcolor = colors.TRANSPARENT
        #page.bgcolor =colors.TRANSPARENT
        #page.window.title_bar_hidden = True
        page.window.frameless = True
        # Recalculate the center position
        page.window_left = (screen_width - page.window_width) // 2
        page.window_top = (screen_height - page.window_height) // 2
        page.update()

    login_form = LoginForm(on_login_success)

    page.add(login_form)
    page.update()

if __name__ == "__main__":
    flet.app(target=main)
