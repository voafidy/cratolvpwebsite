import datetime
import sqlite3
from flet import *
from datetime import *

from btn import save_add_solde
from controls import add_to_control_reference, return_controle_reference
from data_table_caisse import AppDataTableCaisse, AppDataTableCaisseParJour, AppDataTableMvtCaisse
from data_table_login import AppDataTableLogin
import locale
control_map = return_controle_reference()
class CaisseForm(UserControl):
    def __init__(self,page,username):
        super().__init__()
        self.page=page
        self.username=username
        self.selected_date1 = datetime.today().strftime('%Y-%m-%d')
        self.selected_date2 = datetime.today().strftime('%Y-%m-%d')
        self.yr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').year
        self.ms2=datetime.strptime(self.selected_date1,'%Y-%m-%d').month
        self.jr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').day
        
        # Obtenez la date d'aujourd'hui
        self.aujourdhui = datetime.now()
        self. m_0 = self.aujourdhui
        self.m_1 = self.aujourdhui - timedelta(days=self.aujourdhui.day-1)
        self.m_2 = self.m_1 - timedelta(days=self.m_1.day)
        self.m_3 = self.m_2 - timedelta(days=self.m_2.day)
        self.m_4 = self.m_3 - timedelta(days=self.m_3.day)
        # Définir la locale en français
        locale.setlocale(locale.LC_TIME, 'fr_FR')
        self.date_obj_mois_0 = self.m_0.strftime('%B').upper()
        self.date_obj_mois_1 = self.m_1.strftime('%B').upper()
        self.date_obj_mois_2 = self.m_2.strftime('%B').upper()
        self.date_obj_mois_3 = self.m_3.strftime('%B').upper()
        #print(mois_3,mois_2,mois_1)

        #aujourdhui = self.datetime.today().strftime('%Y-%m-%d')#
        self.mois_0 = self. m_0.strftime('%Y-%m-%d')
        self.mois_1 = self. m_1.strftime('%Y-%m-%d')
        self.mois_2 = self.m_2.strftime('%Y-%m-%d')
        self.mois_3 = self.m_3.strftime('%Y-%m-%d')
        self.mois_4 = self.m_4.strftime('%Y-%m-%d')
        self.selected_date3 = self.mois_1
        self.selected_date4 = self.mois_0
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
        
        self.content_column_setting = Column(expand=True)
        self.ctn_pg=Container(
            key='ctn_pg',height=560,width=850,bgcolor=colors.GREY_200,border=border.all(1, "#ebebeb"),border_radius=8,padding=2,
            content=Column(
                #scroll='auto',
                controls=[
                    self.content_column_setting,
                ],
            ),
        )
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        date_min = cur.execute(f"select min(date) as date_min from jounalierTb").fetchone()[0]
        print(date_min)
        if date_min:
            min_date_obj=datetime.strptime(date_min,'%Y-%m-%d')+timedelta(days=1)
            yr=min_date_obj.year
            ms=min_date_obj.month
            jr=min_date_obj.day
        
        conn.close()    
        
        self.button_date1=ElevatedButton(
            f"{self.selected_date1} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date2=ElevatedButton(
            f"{self.selected_date2} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr2, month=self.ms2, day=self.jr2),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change2,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        
        self.button_date3=ElevatedButton(
            f"{self.selected_date3} Debut",
            
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=yr, month=ms, day=jr),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change3,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        self.button_date4=ElevatedButton(
            f"{self.selected_date4} Fin",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=self.yr4, month=self.ms4, day=self.jr4),
                    last_date=datetime(year=datetime.today().year, month=datetime.today().month, day=datetime.today().day),
                    on_change=self.handle_change4,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
        
        self.ctn_pg=Container(
            key='ctn_pg',height=560,width=850,bgcolor=colors.GREY_200,border=border.all(1, "#ebebeb"),border_radius=8,padding=2,
            content=Column(
                #scroll='auto',
                controls=[
                    self.content_column_setting,
                ],
            ),
        )
        self.content_column_list_etat_caisse = Column(expand=True)
        self.list_etat_caisse = Container(
            height=510,
            width=600,
            content=Row(
                controls=[
                    self.content_column_list_etat_caisse,
                    
                ]
            )
        )

    def app_form_input_instance(self):
        add_to_control_reference('CaisseForm', self)
    """
    def def_ctn_pg(self):
        # Ensure the container is ad
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
        
        Column(expand=True,
        controls=[
                self.formulaire_etat_caisse()
                ])
        )
   """
   
    def def_solde_initial_final(self,type_solde, solde_caisse,date_debut,date_fin):
        from datetime import datetime
        now = datetime.now()
        self.current_date = now.strftime("%Y-%m-%d")
        print(self.current_date)
        print(solde_caisse)
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        if solde_caisse == 'caisse':
            if type_solde=='si':
                self.data_id = cur.execute(f"select * from jounalierTb WHERE date < '{date_debut}'  ORDER BY id DESC LIMIT 1").fetchone()
            else:
                self.data_id = cur.execute(f"select * from jounalierTb WHERE date <= '{date_fin}'  ORDER BY id DESC LIMIT 1").fetchone()
                
            conn.close()
            # Charger les données existantes pour l'enregistrement à modifier
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            if type_solde=='si' or type_solde=='sf':
                cur.execute(f"SELECT {solde_caisse} FROM jounalierTb WHERE id = ?", (self.data_id[0],))
                self.data = cur.fetchone()[0]
            elif type_solde=='dc':
                self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt in ('Retrait' ,'Enlever')and date BETWEEN '{date_debut}' and '{date_fin}' ").fetchone()[0]
                
            elif type_solde=='ec':
                self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt in('Transfère','Credit','Ajouter') and date BETWEEN '{date_debut}' and '{date_fin}'").fetchone()[0]
                
            conn.close()
        
        elif solde_caisse == 'solde':
            if type_solde == 'sf':
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                self.dataOrange=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date <= '{date_fin}' and nom_otm = 'Orange')").fetchone()[0]
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()    
                self.dataTelma=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date <= '{date_fin}' and nom_otm = 'Telma')").fetchone()[0]
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                self.dataAirtel=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date <= '{date_fin}' and nom_otm = 'Airtel')").fetchone()[0]
                self.data=float(self.dataOrange)+float(self.dataTelma)+float(self.dataAirtel)      
            else:
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                self.dataOrange=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date < '{date_debut}' and nom_otm = 'Orange')").fetchone()[0]
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()    
                self.dataTelma=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date < '{date_debut}' and nom_otm = 'Telma')").fetchone()[0]
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                self.dataAirtel=cur.execute(f"select solde from jounalierTb WHERE id = (select MAX(id) from jounalierTb WHERE date < '{date_debut}' and nom_otm = 'Airtel')").fetchone()[0]
                self.data=float(self.dataOrange)+float(self.dataTelma)+float(self.dataAirtel) 
                
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            if type_solde=='dc':
                self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt in ('Retrait' ,'Retrait')and date BETWEEN '{date_debut}' and '{date_fin}' ").fetchone()[0]
                
            elif type_solde=='ec':
                self.data = cur.execute(f"select sum(montant) from jounalierTb WHERE types_mvt in('Transfère','Credit','Credit') and date BETWEEN '{date_debut}' and '{date_fin}'").fetchone()[0]
                
            conn.close()
        if  None==self.data:
                self.data =0.0
        print(self.data)
        print('ec   self.data')
        return self.data
    
    def def_etats_liste(self,date3,date4 ):
        self.content_column_list_etat_caisse.controls.clear()
        self.content_column_list_etat_caisse.controls.append(
            Container(
                expand=True,
                bgcolor=colors.BROWN_100,
                height=510,
                width=600,
                content=Column(
                    scroll='auto',
                    controls=[
                        AppDataTableCaisseParJour(date3,date4)
                    ]
                )
            )
        )
        
    def def_ctn_pg(self,date_debut,date_fin):
        print('date_debut',date_debut,'date_fin',date_fin)
        self.content_column_setting.controls.clear()
        self.content_column_setting.controls.append(
            Column(
                expand=True,
                controls=[
                    Row(
                        controls=[
                            Container(
                                height=115,
                                width=420,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=0,
                                content=Column(
                                    spacing=0,
                                    
                                    controls=[
                                        
                                        Container(
                                            padding=4,
                                            
                                            content=Column(
                                                expand=True,
                                                spacing=0,
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Container(
                                                        bgcolor=colors.GREY_200,
                                                        height=25,
                                                        content=Row(
                                                            controls = [
                                                                Container(
                                                                    width=120,
                                                                    content=Row(
                                                                        alignment=MainAxisAlignment.START,
                                                                        controls=[Text("Caisse Initiale : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                    )
                                                                ),
                                                                Container(
                                                                    width=250,
                                                                    content=Row(
                                                                        alignment=MainAxisAlignment.END,
                                                                        controls=[
                                                                            Text("{:,}".format(self.def_solde_initial_final('si','caisse',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                            ]
                                                                    )
                                                                ),
                                                            ]
                                                        ),
                                                    ),
                                                    Container(
                                                        bgcolor=colors.GREY_300,
                                                        height=25,
                                                        content=Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(+) Encaissement  : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('ec','caisse',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        
                                                        ]
                                                    ),
                                                    ),
                                                    Container(
                                                        bgcolor=colors.GREY_200,
                                                        height=25,
                                                        content=Row(
                                                        
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(-) Decaissement : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('dc','caisse',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        ]
                                                    ),),
                                                    
                                                    Container(
                                                        bgcolor=colors.GREY_300,
                                                        height=25,
                                                        content=Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("Caisse Final : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('sf','caisse',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        ]
                                                    ),),
                                                    
                                                ]
                                            )
                                        ),
                                        ]
                                )
                            ),
                            Container(
                                height=115,
                                width=420,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=2,
                                
                                content=Column(
                                    #expand=True,
                                    alignment=MainAxisAlignment.CENTER,
                                    spacing=1,
                                    controls=[
                                        
                                        Container(
                                            content=Column(
                                                spacing=0,
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Container(
                                                        bgcolor=colors.GREY_200,
                                                        height=25,
                                                        content=Row(
                                                        
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("Solde Initiale : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('si','solde',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                            
                                                            
                                                        ]
                                                    ),),
                                                    Container(
                                                        bgcolor=colors.GREY_300,
                                                        height=25,
                                                        content=Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(+) Retrait  : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('ec','solde',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        
                                                        ]
                                                    ),),
                                                    Container(
                                                        bgcolor=colors.GREY_200,
                                                        height=25,
                                                        content=Row(
                                                        
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("(-) Dépôt/Credit : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('dc','solde',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        ]
                                                    ),),
                                                    Container(
                                                        bgcolor=colors.GREY_300,
                                                        height=25,
                                                        content=Row(
                                                        controls = [
                                                            Container(
                                                                width=120,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.START,
                                                                    controls=[Text("Solde Final : ", size=15, weight=FontWeight.W_900, selectable=True),]
                                                                )
                                                            ),
                                                             Container(
                                                                width=250,
                                                                
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.END,
                                                                    controls=[
                                                                        Text("{:,}".format(self.def_solde_initial_final('sf','solde',date_debut,date_fin)).replace(",", " ")+' Ar', size=15, weight=FontWeight.W_900, selectable=True),
                                                                        ]
                                                                )
                                                            ),
                                                        ]
                                                    ),),
                                                    
                                                ]
                                            )
                                        ),
                                        ]
                                )
                            ),
                        ]
                    ),
                    Row(
                        
                        scroll='auto',
                        controls=[
                            
                            Container(
                                
                                height=430,
                                width=850,
                                bgcolor=colors.GREY_200,
                              
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=0,
                                content=Column(
                                    #expand=True,
                                    
                                    controls=[
                                        
                                        Container(
                                            expand=True,
                                            content=Row(
                                            spacing=1,
                                            controls=[
                                                Container(
                                                    
                                                    height=430,
                                                    width=420,
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.GREEN_100,
                                                    content=Column(
                                                        controls=[
                                                            Container(
                                                            bgcolor=colors.GREEN_200,
                                                            padding=0,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.CENTER,
                                                                    controls=[Text("ENCAISSEMENTS", size=16,weight='bold'),]
                                                                ),
                                                            ),
                                                            Container(
                                                                expand=True,
                                                                content=Column(
                                                                scroll='auto',
                                                                controls=[AppDataTableCaisse('encaissement','colors.GREY',date_debut,date_fin),]
                                                                )
                                                            )
                                                        ]
                                                    )
                                                ),
                                                Container(
                                                    border=border.all(1, "#ebebeb"),
                                                    border_radius=8,
                                                    padding=2,
                                                    bgcolor=colors.RED_100,
                                                    height=430,
                                                    width=420,
                                                    content=Column(
                                                        controls=[
                                                            Container(
                                                            bgcolor=colors.RED_200,
                                                            padding=0,
                                                                content=Row(
                                                                    alignment=MainAxisAlignment.CENTER,
                                                                    controls=[Text("DECAISSEMENTS", size=16,weight='bold'),]
                                                                ),
                                                            ),
                                                        
                                                            Container(
                                                                expand=True,
                                                                content=Column(
                                                                scroll='auto',
                                                                controls=[AppDataTableCaisse('decaissements','colors.GREY',date_debut,date_fin),]
                                                                )
                                                            )
                                                        ]
                                                    )
                                                )
                                                ,
                                        ]
                                    )
                                ),
                                        
                                    ]
                                )
                            ),
                        ]
                    )
                ]
            )
        )

    def handle_change1(self, e):
        # Update the button label when a new date is selected
        self.selected_date1 = e.control.value.strftime('%Y-%m-%d')
        self.button_date1.text = f"{self.selected_date1} Debut"
        self.yr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').year
        self.ms2=datetime.strptime(self.selected_date1,'%Y-%m-%d').month
        self.jr2=datetime.strptime(self.selected_date1,'%Y-%m-%d').day
        self.button_date1.update()
        self.recherche_btn(self.selected_date1,self.selected_date2)
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))
    def handle_change2(self, e):
        # Update the button label when a new date is selected
        self.selected_date2 = e.control.value.strftime('%Y-%m-%d')
        self.button_date2.text = f"{self.selected_date2} Fin"
        self.button_date2.update()
        self.recherche_btn(self.selected_date1,self.selected_date2)
        #(Text(f"Date changed: {e.control.value.strftime('%Y-%m-%d')}"))


    def handle_change3(self, e):
        # Update the button label when a new date is selected
        self.selected_date3 = e.control.value.strftime('%Y-%m-%d')
        self.button_date3.text = f"{self.selected_date3} Debut"
        self.yr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').year
        self.ms4=datetime.strptime(self.selected_date3,'%Y-%m-%d').month
        self.jr4=datetime.strptime(self.selected_date3,'%Y-%m-%d').day
        self.button_date3.update()
        self.def_etats_liste(self.selected_date3,self.selected_date4 )
        self.list_etat_caisse.update()
    def handle_change4(self, e):
        # Update the button label when a new date is selected
        self.selected_date4 = e.control.value.strftime('%Y-%m-%d')
        self.button_date4.text = f"{self.selected_date4} Fin"
        self.button_date4.update()
        self.def_etats_liste(self.selected_date3,self.selected_date4 )
        self.list_etat_caisse.update()

    def handle_dismissal(self,e):
        (Text(f"DatePicker dismissed"))
        pass
    
    def recherche_btn(self,date_debut,date_fin):
        self.def_ctn_pg(date_debut,date_fin)
        self.ctn_pg.update()
        return
    
    def dialog_ajoute_enlever_espece(self, e,aj_en):
        self.montant = TextField(label=f"Montant {aj_en}",)
        self.motif = TextField(label="Motif",)
        self.error_message_caisse = Text("", color=colors.RED,size=13,weight='bold',)
        
        # Créez une ligne pour les boutons Modifier et Annuler
        self.action_buttons = Row(
            controls=[
                TextButton(f"{aj_en}", on_click=lambda e: self.add_espece(e,aj_en)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        self.dialog = AlertDialog(
            #modal=True,
            title=Text(f"{aj_en} un nombre d'espèce"),
            content=Column(
                width=150,
                height=180,
                controls=[
                    self.montant,
                    self.motif,
                    self.error_message_caisse,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
    def add_solde(self):
        return Container(
            content=PopupMenuButton(
            content=Column(
                [
                    Icon(name=icons.ADD, size=20),
                    Text("Ajouter Solde", size=12),
                ],
                spacing=0,
                alignment="center",
                horizontal_alignment="center",
                ),
                items=[
                    PopupMenuItem(icon=icons.ADD,text=f"Orange",on_click=lambda e: self.dialog_add_solde(e,"Orange")),
                    PopupMenuItem(icon=icons.ADD,text=f"Telma",on_click=lambda e: self.dialog_add_solde(e,"Telma")),
                    PopupMenuItem(icon=icons.ADD,text="Airtel ",on_click=lambda e: self.dialog_add_solde(e,"Airtel"))
                ],
            ),
        )
    

  
    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
    def dialog_add_solde(self,e, otm):
        self.montant = TextField(label=f"Montant ",)
        self.motif = TextField(label="Motif",)
        self.error_message_caisse = Text("", color=colors.RED,size=13,weight='bold',)
        
        # Créez une ligne pour les boutons Modifier et Annuler
        self.action_buttons = Row(
            controls=[
                TextButton(f"Ajouter Solde {otm}", on_click=lambda e: save_add_solde(self,e,otm)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        self.dialog = AlertDialog(
            #modal=True,
            title=Text(f"Ajouter solde {otm}"),
            content=Column(
                width=150,
                height=180,
                controls=[
                    self.montant,
                    self.motif,
                    self.error_message_caisse,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()


    def add_espece(self,e,aj_en):
        # Récupérez les valeurs des composants
        montant=(self.page.dialog.content.controls[0].value)
        motif=self.page.dialog.content.controls[1].value
        
        if montant and  motif:
            
            try :
                montant= float(montant)
                # Charger les données existantes pour l'enregistrement à modifier
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                self.data_id = cur.execute(f"select * from jounalierTb   ORDER BY id DESC LIMIT 1").fetchone()
                conn.close()
                # Charger les données existantes pour l'enregistrement à modifier
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                caisse_disponible =float(cur.execute(f"SELECT caisse FROM jounalierTb WHERE id = ?", (self.data_id[0],)).fetchone()[0])
                conn.close()
                # Charger les données existantes pour l'enregistrement à modifier
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                solde =float(cur.execute(f"SELECT solde FROM jounalierTb WHERE id = ?", (self.data_id[0],)).fetchone()[0])
                conn.close()
                # Charger les données existantes pour l'enregistrement à modifier
                conn = sqlite3.connect('BDD/database.db')
                cur = conn.cursor()
                solde_net_bs_user =float(cur.execute(f"SELECT solde_net_bs_user FROM jounalierTb WHERE id = ?", (self.data_id[0],)).fetchone()[0])
                conn.close()
                
                
                if aj_en=='Ajouter':
                    caisse_apres=(caisse_disponible) + (montant)
                elif aj_en == 'Enlever':
                    caisse_apres=(caisse_disponible)-(montant)
                    print(aj_en)
                if caisse_apres < 0 and aj_en == 'Enlever' :
                    #dialog_erreur(self, "Oops! Le montant min doit etre strictement inferieur au montant max!")
                    self.error_message_caisse.color = colors.RED
                    self.error_message_caisse.value = f"Oops! Caisse Insuffisante..., Votre Caisse est egale à {caisse_disponible}"
                    self.error_message_caisse.update()
                    return
                else:
                    try:
                        current_date = datetime.now().strftime("%Y-%m-%d")  # Formater la date comme 'YYYY-MM-DD'
                        current_time = datetime.now().strftime("%H:%M:%S")  # Formater l'heure comme 'HH:MM:SS'
                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()
                        cur.execute("""INSERT INTO jounalierTb (date, time, montant,caisse,motif,mvt_caisse,solde,
                                    solde_net_bs_user,user,nom_otm,types_mvt,bonus_otm, bonus_user, bonus_proprietaire,
                            frais_payer_client, frais_retirer_otm) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                        (current_date, current_time,montant, caisse_apres,motif, aj_en,solde,solde_net_bs_user,self.username,motif, aj_en,0,0,0,0,0)
                            )
                        conn.commit()
                        conn.close()
                        self.error_message_caisse.color = colors.GREEN
                        self.error_message_caisse.value = f"{aj_en} avec succés"
                        self.error_message_caisse.update()
                        # Fermer le popup et rafraîchir la table après la mise à jour
                        self.close_dialog_modif(e)
                        self.recherche_btn(self.selected_date1,self.selected_date2)
                        if 'AppDataTableMvtCaisse' in control_map:
                            control_map['AppDataTableMvtCaisse'].refresh_data()
                        self.page.update()  

                    except ValueError:
                        print(ValueError)
                        
                    finally:
                        pass
                    return
                    
                    
                        
                    
                        
            
            except ValueError :
                print(ValueError) 
                self.error_message_caisse.color = colors.RED
                self.error_message_caisse.value = "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît."
                self.error_message_caisse.update()
                #dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message_caisse.color = colors.RED
            self.error_message_caisse.value = "Il faut remplir tous les champ!"
            self.error_message_caisse.update()
            #dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
            return
        
    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()
            
    def build(self):
        self.app_form_input_instance()
        
        
        self.def_ctn_pg(self.selected_date1,self.selected_date1)
        self.def_etats_liste(self.selected_date3,self.selected_date4 )
        return Container(
            expand=True,
            bgcolor= colors.GREEN_100,
            height=610,
            border=border.all(1, "#ebebeb"),
            border_radius=8,
            padding=0,
            content=Column(
                controls=[
                    Row(
                        spacing=0,
                        controls=[
                            Container(
                                height=610,
                                bgcolor=colors.GREY_200,
                                content=Column(
                                    spacing=0,
                                    controls=[
                                        Container(
                                            height=50,
                                            width=850,
                                            bgcolor=colors.GREY_200,
                                            border=border.all(1, "#ebebeb"),
                                            border_radius=8,
                                            padding=0,
                                            content=Row(
                                                #alignment=MainAxisAlignment.CENTER,
                                                controls=[
                                                    Container(
                                                        height=50,
                                                        width=415,
                                                        #bgcolor=colors.GREEN_100,
                                                        content=Row(
                                                            alignment=MainAxisAlignment.START,
                                                            controls=[
                                                                self.button_date1,
                                                                self.button_date2,
                                                                TextButton(
                                                                    on_click=lambda e: self.recherche_btn(self.selected_date1,self.selected_date2),
                                                                    icon= icons.SEARCH
                                                                ),
                                                                
                                                            ]
                                                        )
                                                    ),
                                                    Container(
                                                        height=50,
                                                        width=425,
                                                        bgcolor=colors.GREEN_100,
                                                        content=Row(
                                                            #expand=True,
                                                            alignment=MainAxisAlignment.SPACE_BETWEEN,
                                                            controls=[
                                                                TextButton(
                                                                    
                                                                    content=Column(
                                                                    [
                                                                        Icon(name=icons.ADD, size=20),
                                                                        Text(f"Ajouter Espèce", size=12),
                                                                    ],
                                                                    spacing=0,
                                                                    alignment="center",
                                                                    horizontal_alignment="center",
                                                                    ),
                                                                    on_click=lambda e: self. dialog_ajoute_enlever_espece(e,'Ajouter'),
                                                                ),
                                                                TextButton(
                                                                    content=Column(
                                                                    [
                                                                        Icon(name=icons.EXIT_TO_APP, size=20),
                                                                        Text("Enlever Espèce", size=12),
                                                                    ],
                                                                    spacing=0,
                                                                    alignment="center",
                                                                    horizontal_alignment="center",
                                                                    ),
                                                                    on_click=lambda e: self. dialog_ajoute_enlever_espece(e,'Enlever'),
                                                                ),
                                                                self.add_solde(),
                                                        ]
                                                        )
                                                    ),
                                                ]
                                            )
                                        ),
                                        self.ctn_pg,
                                    ]
                                )
                            ),
                    
                            Container(
                                height=610,
                                width=700,
                                bgcolor=colors.GREY_200,
                                border=border.all(1, "#ebebeb"),
                                border_radius=8,
                                padding=2,
                                expand=True,
                                content=Column(
                                    spacing=1,
                                    
                                    controls=[
                                        Container(
                                            height=50,
                                            width=500,
                                            bgcolor=colors.GREY_100,
                                            content=Row(
                                            controls=[
                                                self.button_date3,
                                                self.button_date4,
                                            ]
                                        )),
                                        Container(
                                            height=50,
                                            width=500,
                                            bgcolor=colors.GREY_200,
                                            content=Row(
                                            controls=[
                                                Text("Etat de Caisse par Jour", size=15, weight=FontWeight.W_900, selectable=True),
                                            ]
                                        )
                                        ),
                                        Container(
                                            expand=True,
                                            height=500,
                                            width=700,
                                            content=Row(
                                                scroll='auto',
                                                controls=[
                                                self.list_etat_caisse,
                                                ]
                                            )
                                        )
                                        
                                    ]
                                )
                            )
                        ]
                    )
                ]
            )
        
        )
    
    

    def on_achat_click(self, e):
        print("Achat button clicked")

    def on_vente_click(self, e):
        print("Vente button clicked")




        """
            return Column(
            controls=[
                Text("Caisse Form", size=20, weight="bold"),
                ElevatedButton(
                    text="Achat",
                    on_click=self.on_achat_click
                ),
                ElevatedButton(
                    text="Vente",
                    on_click=self.on_vente_click
                ),
                ElevatedButton(
            "Pick date",
            icon=icons.CALENDAR_MONTH,
            on_click=lambda e: self.page.open(
                DatePicker(
                    first_date=datetime(year=2023, month=10, day=1),
                    last_date=datetime(year=2024, month=10, day=1),
                    on_change=self.handle_change1,
                    on_dismiss=self.handle_dismissal,
                )
            ),
        )
                
            ]
        )
        """
        