import flet as ft


def main(page):
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def close_banner(e):
        page.close(banner)
        page.add(ft.Text("Action clicked: " + e.control.text))

    action_button_style = ft.ButtonStyle(color=ft.colors.BLUE)
    banner = ft.Banner(
        bgcolor=ft.colors.AMBER_100,
        leading=ft.Icon(ft.icons.WARNING_AMBER_ROUNDED, color=ft.colors.AMBER, size=40),
        content=ft.Text(
            value="Oops, there were some errors while trying to delete the file. What would you like me to do?",
            color=ft.colors.BLACK,
        ),
        actions=[
            ft.TextButton(text="Retry", style=action_button_style, on_click=close_banner),
            ft.TextButton(text="Ignore", style=action_button_style, on_click=close_banner),
            ft.TextButton(text="Cancel", style=action_button_style, on_click=close_banner),
        ],
    )

    page.add(ft.ElevatedButton("Show Banner", on_click=lambda e: page.open(banner)))


ft.app(main)

"""import flet as ft


def main(page: ft.Page):
    page.title = "AlertDialog examples"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER



    def handle_close(e):
        page.close(dlg_modal)
        page.add(ft.Text(f"Modal dialog closed with action: {e.control.text}"))

    dlg_modal = ft.AlertDialog(
        modal=True,
        title=ft.Text("Please confirm"),
        content=ft.Text("Do you really want to delete all those files?"),
        actions=[
            ft.TextButton("Yes", on_click=handle_close),
            ft.TextButton("No", on_click=handle_close),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
        on_dismiss=lambda e: page.add(
            ft.Text("Modal dialog dismissed"),
        ),
    )

    page.add(
        ft.ElevatedButton("Open modal dialog", on_click=lambda e: page.open(dlg_modal)),
    )


ft.app(target=main)

"""
"""
Dropdown(
options=[
    dropdown.Option("Sélectionnez une option", disabled=True),
    dropdown.Option("Option 1"),
    dropdown.Option("Option 2"),
    dropdown.Option("Option 3")
],
value="Sélectionnez une option"  # Placeholder
),



import sqlite3
import flet as ft
from flet import DataTable, DataColumn, DataRow, DataCell, Text, Row, border, Column, ElevatedButton, TextField

class AppDataTable(ft.UserControl):
    def __init__(self):
        super().__init__()
        self.conn = None
        self.cursor = None

    def app_data_table_instance(self):
        self.conn = sqlite3.connect('database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute("SELECT ref, user, types_mvt, montant, bonus, solde, nom_otm FROM jounalierTb")
        return self.cursor.fetchall()

    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(cells=[
                DataCell(Text(str(cell))) for cell in row
            ]) for row in data
        ]
        
        ref_input = TextField(label="Reference")
        user_input = TextField(label="User")
        types_mvt_input = TextField(label="Type Movement")
        montant_input = TextField(label="Amount")
        bonus_input = TextField(label="Bonus")
        solde_input = TextField(label="Balance")
        nom_otm_input = TextField(label="OTM Name")
        
        def on_insert(e):
            self.insert_data(
                ref_input.value, user_input.value, types_mvt_input.value, 
                float(montant_input.value), float(bonus_input.value), 
                float(solde_input.value), nom_otm_input.value
            )
            ref_input.value = ""
            user_input.value = ""
            types_mvt_input.value = ""
            montant_input.value = ""
            bonus_input.value = ""
            solde_input.value = ""
            nom_otm_input.value = ""
            self.update()
        
        insert_button = ElevatedButton("Insert Data", on_click=on_insert)

        return Column(
            controls=[
                Row(
                    controls=[ref_input, user_input, types_mvt_input, montant_input, bonus_input, solde_input, nom_otm_input, insert_button]
                ),
                DataTable(
                    expand=True,
                    border_radius=8,
                    border=border.all(2, '#ebebeb'),
                    horizontal_lines=border.BorderSide(1, '#ebebeb'),
                    columns=[
                        DataColumn(Text('Reference', size=12, color='black', weight='bold')),
                        DataColumn(Text('User', size=12, color='black', weight='bold')),
                        DataColumn(Text('Type Movement', size=12, color='black', weight='bold')),
                        DataColumn(Text('Amount', size=12, color='black', weight='bold')),
                        DataColumn(Text('Bonus', size=12, color='black', weight='bold')),
                        DataColumn(Text('Balance', size=12, color='black', weight='bold')),
                        DataColumn(Text('OTM Name', size=12, color='black', weight='bold')),
                    ],
                    rows=rows,
                )
            ]
        )

def main(page: ft.Page):
    page.title = "Application de Suivi de Caisse"
    page.theme_mode = "light"
    page.horizontal_alignment = "center"
    page.vertical_alignment = 'center'
    page.scroll = "always"

    data_table = AppDataTable()
    page.add(data_table)

# Lancer l'application Flet
ft.app(target=main)
"""

'''
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("First name")),
                ft.DataColumn(ft.Text("Last name")),
                ft.DataColumn(ft.Text("Age"), numeric=True),
            ],
            rows=[
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text("John")),
                        ft.DataCell(ft.Text("Smith")),
                        ft.DataCell(ft.Text("43")),
                    ],
                ),
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text("Jack")),
                        ft.DataCell(ft.Text("Brown")),
                        ft.DataCell(ft.Text("19")),
                    ],
                ),
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text("Alice")),
                        ft.DataCell(ft.Text("Wong")),
                        ft.DataCell(ft.Text("25")),
                    ],
                ),
                
            ],
        ),
    )

ft.app(target=main)
'''

'''

import flet as ft

def main(page: ft.Page):
    page.add(
        ft.DataTable(
            width=700,
            bgcolor="yellow",
            border=ft.border.all(2, "red"),
            border_radius=10,
            vertical_lines=ft.BorderSide(3, "blue"),
            horizontal_lines=ft.BorderSide(1, "green"),
            sort_column_index=0,
            sort_ascending=True,
            heading_row_color=ft.colors.BLACK12,
            heading_row_height=100,
            data_row_color={"hovered": "0x30FF0000"},
            show_checkbox_column=True,
            divider_thickness=0,
            column_spacing=200,
            columns=[
                ft.DataColumn(
                    ft.Text("Column 1"),
                    on_sort=lambda e: print(f"{e.column_index}, {e.ascending}"),
                ),
                ft.DataColumn(
                    ft.Text("Column 2"),
                    tooltip="This is a second column",
                    numeric=True,
                    on_sort=lambda e: print(f"{e.column_index}, {e.ascending}"),
                ),
            ],
            rows=[
                ft.DataRow(
                    [ft.DataCell(ft.Text("A")), ft.DataCell(ft.Text("1"))],
                    selected=True,
                    on_select_changed=lambda e: print(f"row select changed: {e.data}"),
                ),
                ft.DataRow([ft.DataCell(ft.Text("B")), ft.DataCell(ft.Text("2"))]),
            ],
        ),
    )

ft.app(target=main)
'''

"""
import flet as ft

def main(page):

    def close_anchor(e):
        text = f"Color {e.control.data}"
        print(f"closing view from {text}")
        anchor.close_view(text)

    def handle_change(e):
        print(f"handle_change e.data: {e.data}")

    def handle_submit(e):
        print(f"handle_submit e.data: {e.data}")

    def handle_tap(e):
        print(f"handle_tap")

    anchor = ft.SearchBar(
        view_elevation=4,
        divider_color=ft.colors.AMBER,
        bar_hint_text="Search colors...",
        view_hint_text="Choose a color from the suggestions...",
        on_change=handle_change,
        on_submit=handle_submit,
        on_tap=handle_tap,
        controls=[
            ft.ListTile(title=ft.Text(f"Color {i}"), on_click=close_anchor, data=i)
            for i in range(10)
        ],
    )

    page.add(
        ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                ft.OutlinedButton(
                    "Open Search View",
                    on_click=lambda _: anchor.open_view(),
                ),
            ],
        ),
        anchor,
    )


ft.app(target=main)
"""


'''import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Dropdown(
            label="Color",
            hint_text="Choose your favourite color?",
            options=[
                ft.dropdown.Option("Red"),
                ft.dropdown.Option("Green"),
                ft.dropdown.Option("Blue"),
            ],
            autofocus=True,
        )
    )

ft.app(target=main)

'''
"""import flet as ft

def main(page: ft.Page):
    def button_clicked(e):
        t.value = f"Dropdown value is:  {dd.value}"
        page.update()

    t = ft.Text()
    b = ft.ElevatedButton(text="Submit", on_click=button_clicked)
    dd = ft.Dropdown(
        width=100,
        options=[
            ft.dropdown.Option("Red"),
            ft.dropdown.Option("Green"),
            ft.dropdown.Option("Blue"),
        ],
    )
    page.add(dd, b, t)

ft.app(target=main)"""