import sqlite3
from flet import *
from controls import add_to_control_reference
from modify_form import ModifyForm

class AppDataTable(UserControl):
    def __init__(self):
        super().__init__()

    def app_data_table_instance(self):
        add_to_control_reference('AppDataTable', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute("SELECT id, date, time, nom_otm, types_mvt, montant, bonus_otm, bonus_proprietaire, bonus_user, solde FROM jounalierTb ORDER BY id DESC")
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.modify_data(e, id),
                                    bgcolor='white',
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape={
                                            "": RoundedRectangleBorder(radius=6),
                                        },
                                        color={
                                            "": "white",
                                        },
                                    ),
                                    height=42,
                                    width=50,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete(e, id),
                                    bgcolor='white',
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape={
                                            "": RoundedRectangleBorder(radius=6),
                                        },
                                        color={
                                            "": "white",
                                        },
                                    ),
                                    height=42,
                                    width=50,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        self.controls[0].controls[0].rows = rows
        self.update()

    def modify_data(self, e, id):
        modify_form = ModifyForm(id)
        modify_form.open(self.page)
        print(f"Modifier l'enregistrement avec l'ID {id}")

    def confirm_delete(self, e, id):
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Confirmer la suppression"),
            content=Text("Voulez-vous vraiment supprimer cet enregistrement ?"),
            actions=[
                TextButton("Oui", on_click=lambda e: self.delete_data(e, id)),
                TextButton("Non", on_click=self.close_dialog)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def delete_data(self, e, id):
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute("DELETE FROM jounalierTb WHERE id = ?", (id,))
            conn.commit()
            conn.close()
            
            # Rafraîchir la table après la suppression
            self.refresh_data()

            # Fermer le dialogue
            self.close_dialog(e)
        except Exception as ex:
            print(f"Erreur lors de la suppression : {ex}")

    def close_dialog(self, e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()

    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        column_widths = [100, 80, 100, 120, 150, 80, 100, 150, 80]
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell))) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.modify_data(e, id),
                                    bgcolor='white',
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape={
                                            "": RoundedRectangleBorder(radius=6),
                                        },
                                        color={
                                            "": "white",
                                        },
                                    ),
                                    height=42,
                                    width=50,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete(e, id),
                                    bgcolor='white',
                                    color='#d9534f',
                                    style=ButtonStyle(
                                        shape={
                                            "": RoundedRectangleBorder(radius=6),
                                        },
                                        color={
                                            "": "white",
                                        },
                                    ),
                                    height=42,
                                    width=50,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        return Row(
            expand=True,
            controls=[
                DataTable(
                    expand=True,
                    border_radius=8,
                    border=border.all(2, '#ebebeb'),
                    horizontal_lines=border.BorderSide(1, '#ebebeb'),
                    columns=[
                        DataColumn(Container(Text('Date', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Heure', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Opérateur', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Type OP°', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Montant', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('BonusOTM', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('BonusPro', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('BonusUser', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Solde', size=12, color='black', weight='bold'))),
                        DataColumn(Container(Text('Actions', size=12, color='black', weight='bold'))),
                    ],
                    rows=rows,
                )
            ]
        )
