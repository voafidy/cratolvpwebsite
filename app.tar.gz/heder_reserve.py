from flet import *
from controls import add_to_control_reference, return_controle_reference
from caisse_form import CaisseForm
from data_table import AppDataTable
from form import AppForm
from stat_form import SuiviForm
from login_form import LoginForm

control_map = return_controle_reference()

class AppHeader(UserControl):
    def __init__(self, page, content_column, username,nom,status, on_logout):
        super().__init__()
        self.page = page
        self.content_column = content_column
        self.username = username
        self.nom = nom
        self.status = status
        self.on_logout = on_logout

    def app_header_insatance(self):
        add_to_control_reference('AppHeader', self)

    def app_header_brand(self):
        return Container(
            
            content=Text("Performence Plus - Management System", size=15, color="white"),
            
            )
            


    def app_header_avatar(self):
        return Container(
            content=PopupMenuButton(
                items=[
                    PopupMenuItem(text=f"Connecté en tant que {self.status}"),
                    PopupMenuItem(text=f"{self.nom}"),
                    PopupMenuItem(text="Se déconnecter",icon=icons.LOGOUT_ROUNDED, on_click=self.handle_logout)
                ],
                icon=icons.PERSON,
            ),
        )

    def handle_logout(self, e):
        self.on_logout()

    def app_boutton_menu(self):
        return Container(
            width=420,
            bgcolor="#081d33",
            border_radius=6,
            opacity=1,
            animate_opacity=320,
            padding=8,
            content=CupertinoNavigationBar(
                bgcolor="#081d33",
                inactive_color=colors.GREY,
                active_color="#144B82",
                on_change=lambda e: self.handle_navigation_change(e),
                destinations=[
                    NavigationBarDestination(
                        icon=icons.INSERT_DRIVE_FILE,
                        selected_icon=icons.DESCRIPTION,
                        label="Journal"
                    ),
                    NavigationBarDestination(
                        icon=icons.PAYMENT,
                        selected_icon=icons.MONEY,
                        label="Caisse"
                    ),
                    NavigationBarDestination(
                        icon=icons.QUERY_STATS,
                        label="Suivi"
                    ),
                ]
            )
        )

    def handle_navigation_change(self, e):
        if e.control.selected_index == 1:
            self.content_column.controls.clear()
            self.content_column.controls.append(CaisseForm())
            self.page.update()
        elif e.control.selected_index == 2:
            self.content_column.controls.clear()
            self.content_column.controls.append(SuiviForm())
            self.page.update()
        else:
            self.content_column.controls.clear()
            self.content_column.controls.append(
                Column(
                    controls=[
                        AppForm(),
                        Column(
                            scroll='hidden',
                            expand=True,
                            controls=[
                                AppDataTable()
                            ]
                        )
                    ]
                )
            )
            self.page.update()

    def build(self):
        self.app_header_insatance()
        return Container(
            padding=0,
            height=60,
            bgcolor="#081d33",
            border_radius=border_radius.only(top_left=15, top_right=15),
            content=Row(
                expand=True,
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    self.app_header_brand(),
                    self.app_boutton_menu(),
                    self.app_header_avatar(),
                ],
            )
        )
