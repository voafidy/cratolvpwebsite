import sqlite3
from flet import *
from controls import add_to_control_reference, return_controle_reference
from modify_form import ModifyForm
from btn import algo_traitement_data, dialog_erreur
control_map = return_controle_reference()

class AppDataTableBonus(UserControl):
    def __init__(self, otm,color_icon):
        super().__init__()
        self.conn = None
        self.cursor = None
        self.otm= otm
        self.color_icon=color_icon

    def app_data_table_instance(self):
        add_to_control_reference(f'AppDataTableBonus_{self.otm}', self)
        self.conn = sqlite3.connect('BDD/database.db')
        self.cursor = self.conn.cursor()

    def fetch_data(self):
        self.cursor.execute(f"SELECT * FROM tranche_bonus_{self.otm} ORDER BY montant_min asc")
        return self.cursor.fetchall()

    def refresh_data(self):
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_bonus(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete_bonus(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        # Mettre à jour la table avec les nouvelles données
        
        self.controls[0].content.controls[0].rows = rows
        self.update()


    def close_dialog_modif(self,e):
        if hasattr(self, 'dialog'):
            self.dialog.open = False
            self.page.update()



    def save_edit_bonus(self, e, id):
        # Récupérez les valeurs des composants
        montant_min=self.page.dialog.content.controls[0].value
        montant_max=self.page.dialog.content.controls[1].value
        bonus=self.page.dialog.content.controls[2].value
        
        if montant_min and montant_max and bonus:
            
            try :
                testFlozt= float(montant_min)+float(montant_max)+float(bonus)
                if float(montant_min) < float(montant_max):
                    try:
                        conn = sqlite3.connect('BDD/database.db')
                        cur = conn.cursor()
                        cur.execute(f"""UPDATE tranche_bonus_{self.otm}  SET montant_min=?,montant_max=?, bonus=? WHERE id_bn_{self.otm} = ?""",
                        (montant_min,montant_max,bonus,id)
                        )
                        conn.commit()
                        conn.close()

                        # Fermer le popup et rafraîchir la table après la mise à jour
                        self.close_dialog_modif(e)
                        self.page.update()
                        if f'AppDataTableBonus_{self.otm}' in control_map:
                            control_map[f'AppDataTableBonus_{self.otm}'].refresh_data()
                        

                    except ValueError:
                                
                        #dialog_erreur(self, ValueError)
                        
                        print(ValueError)
                        
                    finally:
                        pass
                    return
                else:
                    #dialog_erreur(self, "Oops! Le montant min doit etre strictement inferieur au montant max!")
                    self.error_message_bonus.color = colors.RED
                    self.error_message_bonus.value = "Oops! Le montant min doit être strictement inferieur au montant max!"
                    self.error_message_bonus.update()
                    return
            
            except ValueError :
                print(ValueError) 
                self.error_message_bonus.color = colors.RED
                self.error_message_bonus.value = "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît."
                self.error_message_bonus.update()
                #dialog_erreur(self, "Oops! Le montant saisi doit être un nombre. Veuillez réessayer, s'il vous plaît.")
                return
                
        else :
            print("Il faut remplir tous les champ!")
            self.error_message_bonus.color = colors.RED
            self.error_message_bonus.value = "Il faut remplir tous les champ!"
            self.error_message_bonus.update()
            #dialog_erreur(self, "Oops! Il faut remplir tous les champ!")
            return



    def confirm_delete_bonus(self, e, id):
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Confirmer la suppression"),
            content=Text("Voulez-vous vraiment supprimer cet enregistrement ?"),
            actions=[
                TextButton("Oui", on_click=lambda e: self.delete_data(e, id)),
                TextButton("Non", on_click=self.close_dialog_modif)
            ],
            actions_alignment=MainAxisAlignment.END
        )
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()

    def delete_data(self, e, id):
        print(f"print id : {id}")
        try:
            conn = sqlite3.connect('BDD/database.db')
            cur = conn.cursor()
            cur.execute(f"DELETE FROM tranche_bonus_{self.otm} WHERE id_bn_{self.otm} = ?", (id,))
            conn.commit()
            conn.close()
            
            # Rafraîchir la table après la suppression
            self.refresh_data()

            # Fermer le dialogue
            self.close_dialog_modif(e)
        except Exception as ex:
            print(f"Erreur lors de la suppression : {ex}")


    def load_data(self, id):
        # Charger les données existantes pour l'enregistrement à modifier
        conn = sqlite3.connect('BDD/database.db')
        cur = conn.cursor()
        cur.execute(f"SELECT montant_min,montant_max,bonus FROM tranche_bonus_{self.otm}  WHERE id_bn_{self.otm} = ?", (id,))
        self.data = cur.fetchone()
        conn.close()
        

    
    
        
        
    def dialog_modif_bonus(self, e, id):
        self.load_data(id)
        self.montant_minTextField = TextField(value=str(self.data[0]),label="Montant Min",)
        self.montant_maxTextField = TextField(value=str(self.data[1]),label="Montant Max",)
        self.dep_avec_telTextField = TextField(value=str(self.data[2]),label="Bonus",)
        self.error_message_bonus = Text("", color=colors.RED,size=13,weight='bold',)
        
        
        # Créez une ligne pour les boutons Modifier et Annuler
        self.action_buttons = Row(
            controls=[
                TextButton("Modifier", on_click=lambda e: self.save_edit_bonus(e, id)),
                TextButton("Annuler", on_click=self.close_dialog_modif)
            ],
            alignment=MainAxisAlignment.END,
            spacing=10  # Espacement entre les boutons
        )
        self.dialog = AlertDialog(
            modal=True,
            title=Text("Modifier le Tarif"),
            content=Column(
                width=150,
                height=500,
                controls=[
                    self.montant_minTextField,
                    self.montant_maxTextField,
                    self.dep_avec_telTextField,
                    self.error_message_bonus,
                    self.action_buttons,
                ]
            ),
        )
        
        self.page.dialog = self.dialog
        self.dialog.open = True
        self.page.update()
        
                
    def build(self):
        self.app_data_table_instance()
        data = self.fetch_data()
        
        rows = [
            DataRow(
                cells=[
                    DataCell(Text(str(cell), size=12)) for cell in row[1:]
                ] + [
                    DataCell(
                        Row(
                            controls=[
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.EDIT,  # Icône de modification
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.dialog_modif_bonus(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                ),
                                ElevatedButton(
                                    content=Container(
                                        content=Icon(
                                            name=icons.DELETE,  # Icône de suppression
                                            size=20,
                                        ),
                                        alignment=alignment.center,
                                    ),
                                    on_click=lambda e, id=row[0]: self.confirm_delete_bonus(e, id),
                                    bgcolor=self.color_icon,
                                    color='#081d33',
                                    style=ButtonStyle(
                                        shape=RoundedRectangleBorder(radius=4),
                                        color="white",
                                    ),
                                    height=30,
                                    width=40,
                                )
                            ],
                            alignment=alignment.center
                        )
                    )
                ]
            ) for row in data
        ]
        
        return Container(
            
            width=1100,
            content=Row(
                expand=True,
                controls=[
                    DataTable(
                        expand=True,
                        border_radius=8,
                        border=border.all(2, '#ebebeb'),
                        horizontal_lines=border.BorderSide(1, '#ebebeb'),
                        columns=[
                            
                            DataColumn(Container(Text('Montant Min', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Montant Max', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Bonus', size=12, color='black', weight='bold'))),
                            DataColumn(Container(Text('Action', size=12, color='black', weight='bold'))),
                        ],
                        rows=rows,
                    )
                ]
            )
        )
        

    
